﻿namespace QL_RapChieuPhim.Views
{
	partial class DatPhim
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DatPhim));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_tongtien = new System.Windows.Forms.TextBox();
            this.txt_giave = new System.Windows.Forms.TextBox();
            this.lbl_ghe = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.bunifuShadowPanel2 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.ptb_anhPhim = new System.Windows.Forms.PictureBox();
            this.lbl_tenPhim = new System.Windows.Forms.Label();
            this.lbl_PhongChieu = new System.Windows.Forms.Label();
            this.lbl_SuatChieu = new System.Windows.Forms.Label();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn_close = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.rjButton80 = new CustomControls.RJControls.RJButton();
            this.rjButton60 = new CustomControls.RJControls.RJButton();
            this.rjButton79 = new CustomControls.RJControls.RJButton();
            this.rjButton48 = new CustomControls.RJControls.RJButton();
            this.rjButton59 = new CustomControls.RJControls.RJButton();
            this.rjButton24 = new CustomControls.RJControls.RJButton();
            this.rjButton78 = new CustomControls.RJControls.RJButton();
            this.rjButton47 = new CustomControls.RJControls.RJButton();
            this.rjButton18 = new CustomControls.RJControls.RJButton();
            this.rjButton77 = new CustomControls.RJControls.RJButton();
            this.rjButton46 = new CustomControls.RJControls.RJButton();
            this.rjButton12 = new CustomControls.RJControls.RJButton();
            this.rjButton76 = new CustomControls.RJControls.RJButton();
            this.rjButton45 = new CustomControls.RJControls.RJButton();
            this.rjButton6 = new CustomControls.RJControls.RJButton();
            this.rjButton75 = new CustomControls.RJControls.RJButton();
            this.rjButton58 = new CustomControls.RJControls.RJButton();
            this.rjButton74 = new CustomControls.RJControls.RJButton();
            this.rjButton44 = new CustomControls.RJControls.RJButton();
            this.rjButton57 = new CustomControls.RJControls.RJButton();
            this.rjButton23 = new CustomControls.RJControls.RJButton();
            this.rjButton73 = new CustomControls.RJControls.RJButton();
            this.rjButton43 = new CustomControls.RJControls.RJButton();
            this.rjButton17 = new CustomControls.RJControls.RJButton();
            this.rjButton72 = new CustomControls.RJControls.RJButton();
            this.rjButton42 = new CustomControls.RJControls.RJButton();
            this.rjButton11 = new CustomControls.RJControls.RJButton();
            this.rjButton71 = new CustomControls.RJControls.RJButton();
            this.rjButton41 = new CustomControls.RJControls.RJButton();
            this.rjButton3 = new CustomControls.RJControls.RJButton();
            this.rjButton70 = new CustomControls.RJControls.RJButton();
            this.rjButton56 = new CustomControls.RJControls.RJButton();
            this.rjButton69 = new CustomControls.RJControls.RJButton();
            this.rjButton40 = new CustomControls.RJControls.RJButton();
            this.rjButton55 = new CustomControls.RJControls.RJButton();
            this.rjButton68 = new CustomControls.RJControls.RJButton();
            this.rjButton22 = new CustomControls.RJControls.RJButton();
            this.rjButton67 = new CustomControls.RJControls.RJButton();
            this.rjButton54 = new CustomControls.RJControls.RJButton();
            this.rjButton66 = new CustomControls.RJControls.RJButton();
            this.rjButton39 = new CustomControls.RJControls.RJButton();
            this.rjButton38 = new CustomControls.RJControls.RJButton();
            this.rjButton53 = new CustomControls.RJControls.RJButton();
            this.rjButton65 = new CustomControls.RJControls.RJButton();
            this.rjButton21 = new CustomControls.RJControls.RJButton();
            this.rjButton37 = new CustomControls.RJControls.RJButton();
            this.rjButton64 = new CustomControls.RJControls.RJButton();
            this.rjButton16 = new CustomControls.RJControls.RJButton();
            this.rjButton36 = new CustomControls.RJControls.RJButton();
            this.rjButton15 = new CustomControls.RJControls.RJButton();
            this.rjButton52 = new CustomControls.RJControls.RJButton();
            this.rjButton35 = new CustomControls.RJControls.RJButton();
            this.rjButton10 = new CustomControls.RJControls.RJButton();
            this.rjButton63 = new CustomControls.RJControls.RJButton();
            this.rjButton51 = new CustomControls.RJControls.RJButton();
            this.rjButton34 = new CustomControls.RJControls.RJButton();
            this.rjButton20 = new CustomControls.RJControls.RJButton();
            this.rjButton33 = new CustomControls.RJControls.RJButton();
            this.rjButton62 = new CustomControls.RJControls.RJButton();
            this.rjButton9 = new CustomControls.RJControls.RJButton();
            this.rjButton32 = new CustomControls.RJControls.RJButton();
            this.rjButton50 = new CustomControls.RJControls.RJButton();
            this.rjButton14 = new CustomControls.RJControls.RJButton();
            this.rjButton31 = new CustomControls.RJControls.RJButton();
            this.rjButton5 = new CustomControls.RJControls.RJButton();
            this.rjButton49 = new CustomControls.RJControls.RJButton();
            this.rjButton30 = new CustomControls.RJControls.RJButton();
            this.rjButton19 = new CustomControls.RJControls.RJButton();
            this.rjButton29 = new CustomControls.RJControls.RJButton();
            this.rjButton61 = new CustomControls.RJControls.RJButton();
            this.rjButton8 = new CustomControls.RJControls.RJButton();
            this.rjButton28 = new CustomControls.RJControls.RJButton();
            this.rjButton13 = new CustomControls.RJControls.RJButton();
            this.rjButton27 = new CustomControls.RJControls.RJButton();
            this.rjButton2 = new CustomControls.RJControls.RJButton();
            this.rjButton26 = new CustomControls.RJControls.RJButton();
            this.rjButton7 = new CustomControls.RJControls.RJButton();
            this.rjButton25 = new CustomControls.RJControls.RJButton();
            this.rjButton4 = new CustomControls.RJControls.RJButton();
            this.rjButton1 = new CustomControls.RJControls.RJButton();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.bunifuShadowPanel1.SuspendLayout();
            this.bunifuShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_anhPhim)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(633, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 614);
            this.panel1.TabIndex = 1;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(8, 91);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(8, 8);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(58, 563);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(522, 40);
            this.panel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(137, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "MÀN HÌNH CHIẾU";
            // 
            // txt_tongtien
            // 
            this.txt_tongtien.BackColor = System.Drawing.Color.White;
            this.txt_tongtien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_tongtien.Enabled = false;
            this.txt_tongtien.Location = new System.Drawing.Point(178, 472);
            this.txt_tongtien.Name = "txt_tongtien";
            this.txt_tongtien.Size = new System.Drawing.Size(100, 15);
            this.txt_tongtien.TabIndex = 10;
            // 
            // txt_giave
            // 
            this.txt_giave.BackColor = System.Drawing.Color.White;
            this.txt_giave.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_giave.Enabled = false;
            this.txt_giave.Location = new System.Drawing.Point(178, 391);
            this.txt_giave.Name = "txt_giave";
            this.txt_giave.Size = new System.Drawing.Size(100, 15);
            this.txt_giave.TabIndex = 10;
            // 
            // lbl_ghe
            // 
            this.lbl_ghe.AutoSize = true;
            this.lbl_ghe.Location = new System.Drawing.Point(90, 352);
            this.lbl_ghe.Name = "lbl_ghe";
            this.lbl_ghe.Size = new System.Drawing.Size(0, 16);
            this.lbl_ghe.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Ghế";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 471);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 16);
            this.label7.TabIndex = 8;
            this.label7.Text = "Tổng tiền;";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 390);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Giá vé";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(6, 455);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(320, 1);
            this.panel5.TabIndex = 7;
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel1.BorderRadius = 10;
            this.bunifuShadowPanel1.BorderThickness = 1;
            this.bunifuShadowPanel1.Controls.Add(this.bunifuShadowPanel2);
            this.bunifuShadowPanel1.Controls.Add(this.txt_tongtien);
            this.bunifuShadowPanel1.Controls.Add(this.txt_giave);
            this.bunifuShadowPanel1.Controls.Add(this.panel5);
            this.bunifuShadowPanel1.Controls.Add(this.lbl_ghe);
            this.bunifuShadowPanel1.Controls.Add(this.lbl_tenPhim);
            this.bunifuShadowPanel1.Controls.Add(this.lbl_PhongChieu);
            this.bunifuShadowPanel1.Controls.Add(this.lbl_SuatChieu);
            this.bunifuShadowPanel1.Controls.Add(this.label5);
            this.bunifuShadowPanel1.Controls.Add(this.label6);
            this.bunifuShadowPanel1.Controls.Add(this.label7);
            this.bunifuShadowPanel1.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel1.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(649, 36);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.White;
            this.bunifuShadowPanel1.PanelColor2 = System.Drawing.Color.White;
            this.bunifuShadowPanel1.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowDepth = 5;
            this.bunifuShadowPanel1.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(333, 509);
            this.bunifuShadowPanel1.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel1.TabIndex = 7;
            // 
            // bunifuShadowPanel2
            // 
            this.bunifuShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel2.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel2.BorderRadius = 1;
            this.bunifuShadowPanel2.BorderThickness = 1;
            this.bunifuShadowPanel2.Controls.Add(this.ptb_anhPhim);
            this.bunifuShadowPanel2.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel2.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel2.Location = new System.Drawing.Point(72, 20);
            this.bunifuShadowPanel2.Name = "bunifuShadowPanel2";
            this.bunifuShadowPanel2.PanelColor = System.Drawing.Color.White;
            this.bunifuShadowPanel2.PanelColor2 = System.Drawing.Color.White;
            this.bunifuShadowPanel2.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel2.ShadowDept = 2;
            this.bunifuShadowPanel2.ShadowDepth = 5;
            this.bunifuShadowPanel2.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel2.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel2.Size = new System.Drawing.Size(187, 221);
            this.bunifuShadowPanel2.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel2.TabIndex = 8;
            // 
            // ptb_anhPhim
            // 
            this.ptb_anhPhim.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ptb_anhPhim.Location = new System.Drawing.Point(0, 0);
            this.ptb_anhPhim.Name = "ptb_anhPhim";
            this.ptb_anhPhim.Size = new System.Drawing.Size(187, 221);
            this.ptb_anhPhim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptb_anhPhim.TabIndex = 0;
            this.ptb_anhPhim.TabStop = false;
            // 
            // lbl_tenPhim
            // 
            this.lbl_tenPhim.AutoSize = true;
            this.lbl_tenPhim.Location = new System.Drawing.Point(16, 253);
            this.lbl_tenPhim.Name = "lbl_tenPhim";
            this.lbl_tenPhim.Size = new System.Drawing.Size(66, 16);
            this.lbl_tenPhim.TabIndex = 8;
            this.lbl_tenPhim.Text = "Tên phim:";
            // 
            // lbl_PhongChieu
            // 
            this.lbl_PhongChieu.AutoSize = true;
            this.lbl_PhongChieu.Location = new System.Drawing.Point(16, 321);
            this.lbl_PhongChieu.Name = "lbl_PhongChieu";
            this.lbl_PhongChieu.Size = new System.Drawing.Size(86, 16);
            this.lbl_PhongChieu.TabIndex = 8;
            this.lbl_PhongChieu.Text = "Phòng Chiếu:";
            // 
            // lbl_SuatChieu
            // 
            this.lbl_SuatChieu.AutoSize = true;
            this.lbl_SuatChieu.Location = new System.Drawing.Point(16, 283);
            this.lbl_SuatChieu.Name = "lbl_SuatChieu";
            this.lbl_SuatChieu.Size = new System.Drawing.Size(74, 16);
            this.lbl_SuatChieu.TabIndex = 8;
            this.lbl_SuatChieu.Text = "Suất Chiếu:";
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowAnimations = true;
            this.bunifuButton1.AllowMouseEffects = true;
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = false;
            this.bunifuButton1.AutoRoundBorders = false;
            this.bunifuButton1.AutoSizeLeftIcon = true;
            this.bunifuButton1.AutoSizeRightIcon = true;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "Tiếp theo";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges1;
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.bunifuButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton1.IconSize = 25;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.IdleBorderRadius = 30;
            this.bunifuButton1.IdleBorderThickness = 1;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.IdleIconLeftImage = null;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(757, 552);
            this.bunifuButton1.Name = "bunifuButton1";
            this.bunifuButton1.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton1.OnDisabledState.BorderRadius = 30;
            this.bunifuButton1.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnDisabledState.BorderThickness = 1;
            this.bunifuButton1.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.OnDisabledState.IconLeftImage = null;
            this.bunifuButton1.OnDisabledState.IconRightImage = null;
            this.bunifuButton1.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton1.onHoverState.BorderRadius = 30;
            this.bunifuButton1.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.onHoverState.BorderThickness = 1;
            this.bunifuButton1.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton1.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.onHoverState.IconLeftImage = null;
            this.bunifuButton1.onHoverState.IconRightImage = null;
            this.bunifuButton1.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.OnIdleState.BorderRadius = 30;
            this.bunifuButton1.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnIdleState.BorderThickness = 1;
            this.bunifuButton1.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton1.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.OnIdleState.IconLeftImage = null;
            this.bunifuButton1.OnIdleState.IconRightImage = null;
            this.bunifuButton1.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton1.OnPressedState.BorderRadius = 30;
            this.bunifuButton1.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnPressedState.BorderThickness = 1;
            this.bunifuButton1.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton1.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.OnPressedState.IconLeftImage = null;
            this.bunifuButton1.OnPressedState.IconRightImage = null;
            this.bunifuButton1.Size = new System.Drawing.Size(128, 51);
            this.bunifuButton1.TabIndex = 6;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuButton1.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton1.UseDefaultRadiusAndThickness = true;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // btn_close
            // 
            this.btn_close.AllowAnimations = true;
            this.btn_close.AllowMouseEffects = true;
            this.btn_close.AllowToggling = false;
            this.btn_close.AnimationSpeed = 200;
            this.btn_close.AutoGenerateColors = false;
            this.btn_close.AutoRoundBorders = false;
            this.btn_close.AutoSizeLeftIcon = true;
            this.btn_close.AutoSizeRightIcon = true;
            this.btn_close.BackColor = System.Drawing.Color.Transparent;
            this.btn_close.BackColor1 = System.Drawing.SystemColors.Control;
            this.btn_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_close.BackgroundImage")));
            this.btn_close.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_close.ButtonText = "X";
            this.btn_close.ButtonTextMarginLeft = 0;
            this.btn_close.ColorContrastOnClick = 45;
            this.btn_close.ColorContrastOnHover = 45;
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btn_close.CustomizableEdges = borderEdges2;
            this.btn_close.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_close.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btn_close.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_close.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn_close.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btn_close.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.ForeColor = System.Drawing.Color.Black;
            this.btn_close.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_close.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_close.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btn_close.IconMarginLeft = 11;
            this.btn_close.IconPadding = 10;
            this.btn_close.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_close.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_close.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btn_close.IconSize = 25;
            this.btn_close.IdleBorderColor = System.Drawing.SystemColors.Control;
            this.btn_close.IdleBorderRadius = 24;
            this.btn_close.IdleBorderThickness = 1;
            this.btn_close.IdleFillColor = System.Drawing.SystemColors.Control;
            this.btn_close.IdleIconLeftImage = null;
            this.btn_close.IdleIconRightImage = null;
            this.btn_close.IndicateFocus = false;
            this.btn_close.Location = new System.Drawing.Point(958, 12);
            this.btn_close.Name = "btn_close";
            this.btn_close.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btn_close.OnDisabledState.BorderRadius = 24;
            this.btn_close.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_close.OnDisabledState.BorderThickness = 1;
            this.btn_close.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_close.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn_close.OnDisabledState.IconLeftImage = null;
            this.btn_close.OnDisabledState.IconRightImage = null;
            this.btn_close.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn_close.onHoverState.BorderRadius = 24;
            this.btn_close.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_close.onHoverState.BorderThickness = 1;
            this.btn_close.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn_close.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btn_close.onHoverState.IconLeftImage = null;
            this.btn_close.onHoverState.IconRightImage = null;
            this.btn_close.OnIdleState.BorderColor = System.Drawing.SystemColors.Control;
            this.btn_close.OnIdleState.BorderRadius = 24;
            this.btn_close.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_close.OnIdleState.BorderThickness = 1;
            this.btn_close.OnIdleState.FillColor = System.Drawing.SystemColors.Control;
            this.btn_close.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.btn_close.OnIdleState.IconLeftImage = null;
            this.btn_close.OnIdleState.IconRightImage = null;
            this.btn_close.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btn_close.OnPressedState.BorderRadius = 24;
            this.btn_close.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_close.OnPressedState.BorderThickness = 1;
            this.btn_close.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btn_close.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btn_close.OnPressedState.IconLeftImage = null;
            this.btn_close.OnPressedState.IconRightImage = null;
            this.btn_close.Size = new System.Drawing.Size(30, 30);
            this.btn_close.TabIndex = 5;
            this.btn_close.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_close.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_close.TextMarginLeft = 0;
            this.btn_close.TextPadding = new System.Windows.Forms.Padding(0);
            this.btn_close.UseDefaultRadiusAndThickness = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // rjButton80
            // 
            this.rjButton80.BackColor = System.Drawing.Color.White;
            this.rjButton80.BackgroundColor = System.Drawing.Color.White;
            this.rjButton80.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton80.BorderRadius = 4;
            this.rjButton80.BorderSize = 2;
            this.rjButton80.FlatAppearance.BorderSize = 0;
            this.rjButton80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton80.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton80.ForeColor = System.Drawing.Color.Black;
            this.rjButton80.Location = new System.Drawing.Point(542, 458);
            this.rjButton80.Name = "rjButton80";
            this.rjButton80.Size = new System.Drawing.Size(41, 41);
            this.rjButton80.TabIndex = 0;
            this.rjButton80.Text = "A8";
            this.rjButton80.TextColor = System.Drawing.Color.Black;
            this.rjButton80.UseVisualStyleBackColor = false;
            this.rjButton80.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton60
            // 
            this.rjButton60.BackColor = System.Drawing.Color.White;
            this.rjButton60.BackgroundColor = System.Drawing.Color.White;
            this.rjButton60.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton60.BorderRadius = 4;
            this.rjButton60.BorderSize = 2;
            this.rjButton60.FlatAppearance.BorderSize = 0;
            this.rjButton60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton60.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton60.ForeColor = System.Drawing.Color.Black;
            this.rjButton60.Location = new System.Drawing.Point(356, 458);
            this.rjButton60.Name = "rjButton60";
            this.rjButton60.Size = new System.Drawing.Size(41, 41);
            this.rjButton60.TabIndex = 0;
            this.rjButton60.Text = "A6";
            this.rjButton60.TextColor = System.Drawing.Color.Black;
            this.rjButton60.UseVisualStyleBackColor = false;
            this.rjButton60.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton79
            // 
            this.rjButton79.BackColor = System.Drawing.Color.White;
            this.rjButton79.BackgroundColor = System.Drawing.Color.White;
            this.rjButton79.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton79.BorderRadius = 4;
            this.rjButton79.BorderSize = 2;
            this.rjButton79.FlatAppearance.BorderSize = 0;
            this.rjButton79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton79.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton79.ForeColor = System.Drawing.Color.Black;
            this.rjButton79.Location = new System.Drawing.Point(542, 363);
            this.rjButton79.Name = "rjButton79";
            this.rjButton79.Size = new System.Drawing.Size(41, 41);
            this.rjButton79.TabIndex = 0;
            this.rjButton79.Text = "C8";
            this.rjButton79.TextColor = System.Drawing.Color.Black;
            this.rjButton79.UseVisualStyleBackColor = false;
            this.rjButton79.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton48
            // 
            this.rjButton48.BackColor = System.Drawing.Color.White;
            this.rjButton48.BackgroundColor = System.Drawing.Color.White;
            this.rjButton48.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton48.BorderRadius = 4;
            this.rjButton48.BorderSize = 2;
            this.rjButton48.FlatAppearance.BorderSize = 0;
            this.rjButton48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton48.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton48.ForeColor = System.Drawing.Color.Black;
            this.rjButton48.Location = new System.Drawing.Point(356, 363);
            this.rjButton48.Name = "rjButton48";
            this.rjButton48.Size = new System.Drawing.Size(41, 41);
            this.rjButton48.TabIndex = 0;
            this.rjButton48.Text = "C6";
            this.rjButton48.TextColor = System.Drawing.Color.Black;
            this.rjButton48.UseVisualStyleBackColor = false;
            this.rjButton48.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton59
            // 
            this.rjButton59.BackColor = System.Drawing.Color.White;
            this.rjButton59.BackgroundColor = System.Drawing.Color.White;
            this.rjButton59.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton59.BorderRadius = 4;
            this.rjButton59.BorderSize = 2;
            this.rjButton59.FlatAppearance.BorderSize = 0;
            this.rjButton59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton59.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton59.ForeColor = System.Drawing.Color.Black;
            this.rjButton59.Location = new System.Drawing.Point(176, 458);
            this.rjButton59.Name = "rjButton59";
            this.rjButton59.Size = new System.Drawing.Size(41, 41);
            this.rjButton59.TabIndex = 0;
            this.rjButton59.Text = "A3";
            this.rjButton59.TextColor = System.Drawing.Color.Black;
            this.rjButton59.UseVisualStyleBackColor = false;
            this.rjButton59.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton24
            // 
            this.rjButton24.BackColor = System.Drawing.Color.White;
            this.rjButton24.BackgroundColor = System.Drawing.Color.White;
            this.rjButton24.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton24.BorderRadius = 4;
            this.rjButton24.BorderSize = 2;
            this.rjButton24.FlatAppearance.BorderSize = 0;
            this.rjButton24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton24.ForeColor = System.Drawing.Color.Black;
            this.rjButton24.Location = new System.Drawing.Point(176, 363);
            this.rjButton24.Name = "rjButton24";
            this.rjButton24.Size = new System.Drawing.Size(41, 41);
            this.rjButton24.TabIndex = 0;
            this.rjButton24.Text = "C3";
            this.rjButton24.TextColor = System.Drawing.Color.Black;
            this.rjButton24.UseVisualStyleBackColor = false;
            this.rjButton24.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton78
            // 
            this.rjButton78.BackColor = System.Drawing.Color.White;
            this.rjButton78.BackgroundColor = System.Drawing.Color.White;
            this.rjButton78.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton78.BorderRadius = 4;
            this.rjButton78.BorderSize = 2;
            this.rjButton78.FlatAppearance.BorderSize = 0;
            this.rjButton78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton78.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton78.ForeColor = System.Drawing.Color.Black;
            this.rjButton78.Location = new System.Drawing.Point(542, 269);
            this.rjButton78.Name = "rjButton78";
            this.rjButton78.Size = new System.Drawing.Size(41, 41);
            this.rjButton78.TabIndex = 0;
            this.rjButton78.Text = "E8";
            this.rjButton78.TextColor = System.Drawing.Color.Black;
            this.rjButton78.UseVisualStyleBackColor = false;
            this.rjButton78.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton47
            // 
            this.rjButton47.BackColor = System.Drawing.Color.White;
            this.rjButton47.BackgroundColor = System.Drawing.Color.White;
            this.rjButton47.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton47.BorderRadius = 4;
            this.rjButton47.BorderSize = 2;
            this.rjButton47.FlatAppearance.BorderSize = 0;
            this.rjButton47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton47.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton47.ForeColor = System.Drawing.Color.Black;
            this.rjButton47.Location = new System.Drawing.Point(356, 269);
            this.rjButton47.Name = "rjButton47";
            this.rjButton47.Size = new System.Drawing.Size(41, 41);
            this.rjButton47.TabIndex = 0;
            this.rjButton47.Text = "E6";
            this.rjButton47.TextColor = System.Drawing.Color.Black;
            this.rjButton47.UseVisualStyleBackColor = false;
            this.rjButton47.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton18
            // 
            this.rjButton18.BackColor = System.Drawing.Color.White;
            this.rjButton18.BackgroundColor = System.Drawing.Color.White;
            this.rjButton18.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton18.BorderRadius = 4;
            this.rjButton18.BorderSize = 2;
            this.rjButton18.FlatAppearance.BorderSize = 0;
            this.rjButton18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton18.ForeColor = System.Drawing.Color.Black;
            this.rjButton18.Location = new System.Drawing.Point(176, 269);
            this.rjButton18.Name = "rjButton18";
            this.rjButton18.Size = new System.Drawing.Size(41, 41);
            this.rjButton18.TabIndex = 0;
            this.rjButton18.Text = "E3";
            this.rjButton18.TextColor = System.Drawing.Color.Black;
            this.rjButton18.UseVisualStyleBackColor = false;
            this.rjButton18.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton77
            // 
            this.rjButton77.BackColor = System.Drawing.Color.White;
            this.rjButton77.BackgroundColor = System.Drawing.Color.White;
            this.rjButton77.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton77.BorderRadius = 4;
            this.rjButton77.BorderSize = 2;
            this.rjButton77.FlatAppearance.BorderSize = 0;
            this.rjButton77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton77.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton77.ForeColor = System.Drawing.Color.Black;
            this.rjButton77.Location = new System.Drawing.Point(542, 223);
            this.rjButton77.Name = "rjButton77";
            this.rjButton77.Size = new System.Drawing.Size(41, 41);
            this.rjButton77.TabIndex = 0;
            this.rjButton77.Text = "F8";
            this.rjButton77.TextColor = System.Drawing.Color.Black;
            this.rjButton77.UseVisualStyleBackColor = false;
            this.rjButton77.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton46
            // 
            this.rjButton46.BackColor = System.Drawing.Color.White;
            this.rjButton46.BackgroundColor = System.Drawing.Color.White;
            this.rjButton46.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton46.BorderRadius = 4;
            this.rjButton46.BorderSize = 2;
            this.rjButton46.FlatAppearance.BorderSize = 0;
            this.rjButton46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton46.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton46.ForeColor = System.Drawing.Color.Black;
            this.rjButton46.Location = new System.Drawing.Point(356, 223);
            this.rjButton46.Name = "rjButton46";
            this.rjButton46.Size = new System.Drawing.Size(41, 41);
            this.rjButton46.TabIndex = 0;
            this.rjButton46.Text = "F6";
            this.rjButton46.TextColor = System.Drawing.Color.Black;
            this.rjButton46.UseVisualStyleBackColor = false;
            this.rjButton46.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton12
            // 
            this.rjButton12.BackColor = System.Drawing.Color.White;
            this.rjButton12.BackgroundColor = System.Drawing.Color.White;
            this.rjButton12.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton12.BorderRadius = 4;
            this.rjButton12.BorderSize = 2;
            this.rjButton12.FlatAppearance.BorderSize = 0;
            this.rjButton12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton12.ForeColor = System.Drawing.Color.Black;
            this.rjButton12.Location = new System.Drawing.Point(176, 223);
            this.rjButton12.Name = "rjButton12";
            this.rjButton12.Size = new System.Drawing.Size(41, 41);
            this.rjButton12.TabIndex = 0;
            this.rjButton12.Text = "F3";
            this.rjButton12.TextColor = System.Drawing.Color.Black;
            this.rjButton12.UseVisualStyleBackColor = false;
            this.rjButton12.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton76
            // 
            this.rjButton76.BackColor = System.Drawing.Color.White;
            this.rjButton76.BackgroundColor = System.Drawing.Color.White;
            this.rjButton76.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton76.BorderRadius = 4;
            this.rjButton76.BorderSize = 2;
            this.rjButton76.FlatAppearance.BorderSize = 0;
            this.rjButton76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton76.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton76.ForeColor = System.Drawing.Color.Black;
            this.rjButton76.Location = new System.Drawing.Point(542, 127);
            this.rjButton76.Name = "rjButton76";
            this.rjButton76.Size = new System.Drawing.Size(41, 41);
            this.rjButton76.TabIndex = 0;
            this.rjButton76.Text = "H8";
            this.rjButton76.TextColor = System.Drawing.Color.Black;
            this.rjButton76.UseVisualStyleBackColor = false;
            this.rjButton76.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton45
            // 
            this.rjButton45.BackColor = System.Drawing.Color.White;
            this.rjButton45.BackgroundColor = System.Drawing.Color.White;
            this.rjButton45.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton45.BorderRadius = 4;
            this.rjButton45.BorderSize = 2;
            this.rjButton45.FlatAppearance.BorderSize = 0;
            this.rjButton45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton45.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton45.ForeColor = System.Drawing.Color.Black;
            this.rjButton45.Location = new System.Drawing.Point(356, 127);
            this.rjButton45.Name = "rjButton45";
            this.rjButton45.Size = new System.Drawing.Size(41, 41);
            this.rjButton45.TabIndex = 0;
            this.rjButton45.Text = "H6";
            this.rjButton45.TextColor = System.Drawing.Color.Black;
            this.rjButton45.UseVisualStyleBackColor = false;
            this.rjButton45.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton6
            // 
            this.rjButton6.BackColor = System.Drawing.Color.White;
            this.rjButton6.BackgroundColor = System.Drawing.Color.White;
            this.rjButton6.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton6.BorderRadius = 4;
            this.rjButton6.BorderSize = 2;
            this.rjButton6.FlatAppearance.BorderSize = 0;
            this.rjButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton6.ForeColor = System.Drawing.Color.Black;
            this.rjButton6.Location = new System.Drawing.Point(176, 127);
            this.rjButton6.Name = "rjButton6";
            this.rjButton6.Size = new System.Drawing.Size(41, 41);
            this.rjButton6.TabIndex = 0;
            this.rjButton6.Text = "H3";
            this.rjButton6.TextColor = System.Drawing.Color.Black;
            this.rjButton6.UseVisualStyleBackColor = false;
            this.rjButton6.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton75
            // 
            this.rjButton75.BackColor = System.Drawing.Color.White;
            this.rjButton75.BackgroundColor = System.Drawing.Color.White;
            this.rjButton75.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton75.BorderRadius = 4;
            this.rjButton75.BorderSize = 2;
            this.rjButton75.FlatAppearance.BorderSize = 0;
            this.rjButton75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton75.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton75.ForeColor = System.Drawing.Color.Black;
            this.rjButton75.Location = new System.Drawing.Point(542, 412);
            this.rjButton75.Name = "rjButton75";
            this.rjButton75.Size = new System.Drawing.Size(41, 41);
            this.rjButton75.TabIndex = 0;
            this.rjButton75.Text = "B8";
            this.rjButton75.TextColor = System.Drawing.Color.Black;
            this.rjButton75.UseVisualStyleBackColor = false;
            this.rjButton75.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton58
            // 
            this.rjButton58.BackColor = System.Drawing.Color.White;
            this.rjButton58.BackgroundColor = System.Drawing.Color.White;
            this.rjButton58.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton58.BorderRadius = 4;
            this.rjButton58.BorderSize = 2;
            this.rjButton58.FlatAppearance.BorderSize = 0;
            this.rjButton58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton58.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton58.ForeColor = System.Drawing.Color.Black;
            this.rjButton58.Location = new System.Drawing.Point(356, 412);
            this.rjButton58.Name = "rjButton58";
            this.rjButton58.Size = new System.Drawing.Size(41, 41);
            this.rjButton58.TabIndex = 0;
            this.rjButton58.Text = "B6";
            this.rjButton58.TextColor = System.Drawing.Color.Black;
            this.rjButton58.UseVisualStyleBackColor = false;
            this.rjButton58.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton74
            // 
            this.rjButton74.BackColor = System.Drawing.Color.White;
            this.rjButton74.BackgroundColor = System.Drawing.Color.White;
            this.rjButton74.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton74.BorderRadius = 4;
            this.rjButton74.BorderSize = 2;
            this.rjButton74.FlatAppearance.BorderSize = 0;
            this.rjButton74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton74.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton74.ForeColor = System.Drawing.Color.Black;
            this.rjButton74.Location = new System.Drawing.Point(542, 317);
            this.rjButton74.Name = "rjButton74";
            this.rjButton74.Size = new System.Drawing.Size(41, 41);
            this.rjButton74.TabIndex = 0;
            this.rjButton74.Text = "D8";
            this.rjButton74.TextColor = System.Drawing.Color.Black;
            this.rjButton74.UseVisualStyleBackColor = false;
            this.rjButton74.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton44
            // 
            this.rjButton44.BackColor = System.Drawing.Color.White;
            this.rjButton44.BackgroundColor = System.Drawing.Color.White;
            this.rjButton44.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton44.BorderRadius = 4;
            this.rjButton44.BorderSize = 2;
            this.rjButton44.FlatAppearance.BorderSize = 0;
            this.rjButton44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton44.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton44.ForeColor = System.Drawing.Color.Black;
            this.rjButton44.Location = new System.Drawing.Point(356, 317);
            this.rjButton44.Name = "rjButton44";
            this.rjButton44.Size = new System.Drawing.Size(41, 41);
            this.rjButton44.TabIndex = 0;
            this.rjButton44.Text = "D6";
            this.rjButton44.TextColor = System.Drawing.Color.Black;
            this.rjButton44.UseVisualStyleBackColor = false;
            this.rjButton44.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton57
            // 
            this.rjButton57.BackColor = System.Drawing.Color.White;
            this.rjButton57.BackgroundColor = System.Drawing.Color.White;
            this.rjButton57.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton57.BorderRadius = 4;
            this.rjButton57.BorderSize = 2;
            this.rjButton57.FlatAppearance.BorderSize = 0;
            this.rjButton57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton57.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton57.ForeColor = System.Drawing.Color.Black;
            this.rjButton57.Location = new System.Drawing.Point(176, 412);
            this.rjButton57.Name = "rjButton57";
            this.rjButton57.Size = new System.Drawing.Size(41, 41);
            this.rjButton57.TabIndex = 0;
            this.rjButton57.Text = "B3";
            this.rjButton57.TextColor = System.Drawing.Color.Black;
            this.rjButton57.UseVisualStyleBackColor = false;
            this.rjButton57.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton23
            // 
            this.rjButton23.BackColor = System.Drawing.Color.White;
            this.rjButton23.BackgroundColor = System.Drawing.Color.White;
            this.rjButton23.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton23.BorderRadius = 4;
            this.rjButton23.BorderSize = 2;
            this.rjButton23.FlatAppearance.BorderSize = 0;
            this.rjButton23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton23.ForeColor = System.Drawing.Color.Black;
            this.rjButton23.Location = new System.Drawing.Point(176, 317);
            this.rjButton23.Name = "rjButton23";
            this.rjButton23.Size = new System.Drawing.Size(41, 41);
            this.rjButton23.TabIndex = 0;
            this.rjButton23.Text = "D3";
            this.rjButton23.TextColor = System.Drawing.Color.Black;
            this.rjButton23.UseVisualStyleBackColor = false;
            this.rjButton23.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton73
            // 
            this.rjButton73.BackColor = System.Drawing.Color.White;
            this.rjButton73.BackgroundColor = System.Drawing.Color.White;
            this.rjButton73.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton73.BorderRadius = 4;
            this.rjButton73.BorderSize = 2;
            this.rjButton73.FlatAppearance.BorderSize = 0;
            this.rjButton73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton73.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton73.ForeColor = System.Drawing.Color.Black;
            this.rjButton73.Location = new System.Drawing.Point(542, 223);
            this.rjButton73.Name = "rjButton73";
            this.rjButton73.Size = new System.Drawing.Size(41, 41);
            this.rjButton73.TabIndex = 0;
            this.rjButton73.Text = "A1";
            this.rjButton73.TextColor = System.Drawing.Color.Black;
            this.rjButton73.UseVisualStyleBackColor = false;
            this.rjButton73.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton43
            // 
            this.rjButton43.BackColor = System.Drawing.Color.White;
            this.rjButton43.BackgroundColor = System.Drawing.Color.White;
            this.rjButton43.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton43.BorderRadius = 4;
            this.rjButton43.BorderSize = 2;
            this.rjButton43.FlatAppearance.BorderSize = 0;
            this.rjButton43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton43.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton43.ForeColor = System.Drawing.Color.Black;
            this.rjButton43.Location = new System.Drawing.Point(356, 223);
            this.rjButton43.Name = "rjButton43";
            this.rjButton43.Size = new System.Drawing.Size(41, 41);
            this.rjButton43.TabIndex = 0;
            this.rjButton43.Text = "A1";
            this.rjButton43.TextColor = System.Drawing.Color.Black;
            this.rjButton43.UseVisualStyleBackColor = false;
            this.rjButton43.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton17
            // 
            this.rjButton17.BackColor = System.Drawing.Color.White;
            this.rjButton17.BackgroundColor = System.Drawing.Color.White;
            this.rjButton17.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton17.BorderRadius = 4;
            this.rjButton17.BorderSize = 2;
            this.rjButton17.FlatAppearance.BorderSize = 0;
            this.rjButton17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton17.ForeColor = System.Drawing.Color.Black;
            this.rjButton17.Location = new System.Drawing.Point(176, 223);
            this.rjButton17.Name = "rjButton17";
            this.rjButton17.Size = new System.Drawing.Size(41, 41);
            this.rjButton17.TabIndex = 0;
            this.rjButton17.Text = "A1";
            this.rjButton17.TextColor = System.Drawing.Color.Black;
            this.rjButton17.UseVisualStyleBackColor = false;
            this.rjButton17.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton72
            // 
            this.rjButton72.BackColor = System.Drawing.Color.White;
            this.rjButton72.BackgroundColor = System.Drawing.Color.White;
            this.rjButton72.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton72.BorderRadius = 4;
            this.rjButton72.BorderSize = 2;
            this.rjButton72.FlatAppearance.BorderSize = 0;
            this.rjButton72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton72.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton72.ForeColor = System.Drawing.Color.Black;
            this.rjButton72.Location = new System.Drawing.Point(542, 177);
            this.rjButton72.Name = "rjButton72";
            this.rjButton72.Size = new System.Drawing.Size(41, 41);
            this.rjButton72.TabIndex = 0;
            this.rjButton72.Text = "G8";
            this.rjButton72.TextColor = System.Drawing.Color.Black;
            this.rjButton72.UseVisualStyleBackColor = false;
            this.rjButton72.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton42
            // 
            this.rjButton42.BackColor = System.Drawing.Color.White;
            this.rjButton42.BackgroundColor = System.Drawing.Color.White;
            this.rjButton42.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton42.BorderRadius = 4;
            this.rjButton42.BorderSize = 2;
            this.rjButton42.FlatAppearance.BorderSize = 0;
            this.rjButton42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton42.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton42.ForeColor = System.Drawing.Color.Black;
            this.rjButton42.Location = new System.Drawing.Point(356, 177);
            this.rjButton42.Name = "rjButton42";
            this.rjButton42.Size = new System.Drawing.Size(41, 41);
            this.rjButton42.TabIndex = 0;
            this.rjButton42.Text = "G6";
            this.rjButton42.TextColor = System.Drawing.Color.Black;
            this.rjButton42.UseVisualStyleBackColor = false;
            this.rjButton42.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton11
            // 
            this.rjButton11.BackColor = System.Drawing.Color.White;
            this.rjButton11.BackgroundColor = System.Drawing.Color.White;
            this.rjButton11.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton11.BorderRadius = 4;
            this.rjButton11.BorderSize = 2;
            this.rjButton11.FlatAppearance.BorderSize = 0;
            this.rjButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton11.ForeColor = System.Drawing.Color.Black;
            this.rjButton11.Location = new System.Drawing.Point(176, 177);
            this.rjButton11.Name = "rjButton11";
            this.rjButton11.Size = new System.Drawing.Size(41, 41);
            this.rjButton11.TabIndex = 0;
            this.rjButton11.Text = "G3";
            this.rjButton11.TextColor = System.Drawing.Color.Black;
            this.rjButton11.UseVisualStyleBackColor = false;
            this.rjButton11.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton71
            // 
            this.rjButton71.BackColor = System.Drawing.Color.White;
            this.rjButton71.BackgroundColor = System.Drawing.Color.White;
            this.rjButton71.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton71.BorderRadius = 4;
            this.rjButton71.BorderSize = 2;
            this.rjButton71.FlatAppearance.BorderSize = 0;
            this.rjButton71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton71.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton71.ForeColor = System.Drawing.Color.Black;
            this.rjButton71.Location = new System.Drawing.Point(542, 81);
            this.rjButton71.Name = "rjButton71";
            this.rjButton71.Size = new System.Drawing.Size(41, 41);
            this.rjButton71.TabIndex = 0;
            this.rjButton71.Text = "J8";
            this.rjButton71.TextColor = System.Drawing.Color.Black;
            this.rjButton71.UseVisualStyleBackColor = false;
            this.rjButton71.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton41
            // 
            this.rjButton41.BackColor = System.Drawing.Color.White;
            this.rjButton41.BackgroundColor = System.Drawing.Color.White;
            this.rjButton41.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton41.BorderRadius = 4;
            this.rjButton41.BorderSize = 2;
            this.rjButton41.FlatAppearance.BorderSize = 0;
            this.rjButton41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton41.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton41.ForeColor = System.Drawing.Color.Black;
            this.rjButton41.Location = new System.Drawing.Point(356, 81);
            this.rjButton41.Name = "rjButton41";
            this.rjButton41.Size = new System.Drawing.Size(41, 41);
            this.rjButton41.TabIndex = 0;
            this.rjButton41.Text = "J6";
            this.rjButton41.TextColor = System.Drawing.Color.Black;
            this.rjButton41.UseVisualStyleBackColor = false;
            this.rjButton41.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton3
            // 
            this.rjButton3.BackColor = System.Drawing.Color.White;
            this.rjButton3.BackgroundColor = System.Drawing.Color.White;
            this.rjButton3.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton3.BorderRadius = 4;
            this.rjButton3.BorderSize = 2;
            this.rjButton3.FlatAppearance.BorderSize = 0;
            this.rjButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton3.ForeColor = System.Drawing.Color.Black;
            this.rjButton3.Location = new System.Drawing.Point(176, 81);
            this.rjButton3.Name = "rjButton3";
            this.rjButton3.Size = new System.Drawing.Size(41, 41);
            this.rjButton3.TabIndex = 0;
            this.rjButton3.Text = "J3";
            this.rjButton3.TextColor = System.Drawing.Color.Black;
            this.rjButton3.UseVisualStyleBackColor = false;
            this.rjButton3.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton70
            // 
            this.rjButton70.BackColor = System.Drawing.Color.White;
            this.rjButton70.BackgroundColor = System.Drawing.Color.White;
            this.rjButton70.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton70.BorderRadius = 4;
            this.rjButton70.BorderSize = 2;
            this.rjButton70.FlatAppearance.BorderSize = 0;
            this.rjButton70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton70.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton70.ForeColor = System.Drawing.Color.Black;
            this.rjButton70.Location = new System.Drawing.Point(484, 458);
            this.rjButton70.Name = "rjButton70";
            this.rjButton70.Size = new System.Drawing.Size(41, 41);
            this.rjButton70.TabIndex = 0;
            this.rjButton70.Text = "A7";
            this.rjButton70.TextColor = System.Drawing.Color.Black;
            this.rjButton70.UseVisualStyleBackColor = false;
            this.rjButton70.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton56
            // 
            this.rjButton56.BackColor = System.Drawing.Color.White;
            this.rjButton56.BackgroundColor = System.Drawing.Color.White;
            this.rjButton56.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton56.BorderRadius = 4;
            this.rjButton56.BorderSize = 2;
            this.rjButton56.FlatAppearance.BorderSize = 0;
            this.rjButton56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton56.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton56.ForeColor = System.Drawing.Color.Black;
            this.rjButton56.Location = new System.Drawing.Point(298, 458);
            this.rjButton56.Name = "rjButton56";
            this.rjButton56.Size = new System.Drawing.Size(41, 41);
            this.rjButton56.TabIndex = 0;
            this.rjButton56.Text = "A5";
            this.rjButton56.TextColor = System.Drawing.Color.Black;
            this.rjButton56.UseVisualStyleBackColor = false;
            this.rjButton56.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton69
            // 
            this.rjButton69.BackColor = System.Drawing.Color.White;
            this.rjButton69.BackgroundColor = System.Drawing.Color.White;
            this.rjButton69.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton69.BorderRadius = 4;
            this.rjButton69.BorderSize = 2;
            this.rjButton69.FlatAppearance.BorderSize = 0;
            this.rjButton69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton69.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton69.ForeColor = System.Drawing.Color.Black;
            this.rjButton69.Location = new System.Drawing.Point(484, 363);
            this.rjButton69.Name = "rjButton69";
            this.rjButton69.Size = new System.Drawing.Size(41, 41);
            this.rjButton69.TabIndex = 0;
            this.rjButton69.Text = "C7";
            this.rjButton69.TextColor = System.Drawing.Color.Black;
            this.rjButton69.UseVisualStyleBackColor = false;
            this.rjButton69.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton40
            // 
            this.rjButton40.BackColor = System.Drawing.Color.White;
            this.rjButton40.BackgroundColor = System.Drawing.Color.White;
            this.rjButton40.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton40.BorderRadius = 4;
            this.rjButton40.BorderSize = 2;
            this.rjButton40.FlatAppearance.BorderSize = 0;
            this.rjButton40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton40.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton40.ForeColor = System.Drawing.Color.Black;
            this.rjButton40.Location = new System.Drawing.Point(298, 363);
            this.rjButton40.Name = "rjButton40";
            this.rjButton40.Size = new System.Drawing.Size(41, 41);
            this.rjButton40.TabIndex = 0;
            this.rjButton40.Text = "C5";
            this.rjButton40.TextColor = System.Drawing.Color.Black;
            this.rjButton40.UseVisualStyleBackColor = false;
            this.rjButton40.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton55
            // 
            this.rjButton55.BackColor = System.Drawing.Color.White;
            this.rjButton55.BackgroundColor = System.Drawing.Color.White;
            this.rjButton55.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton55.BorderRadius = 4;
            this.rjButton55.BorderSize = 2;
            this.rjButton55.FlatAppearance.BorderSize = 0;
            this.rjButton55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton55.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton55.ForeColor = System.Drawing.Color.Black;
            this.rjButton55.Location = new System.Drawing.Point(118, 458);
            this.rjButton55.Name = "rjButton55";
            this.rjButton55.Size = new System.Drawing.Size(41, 41);
            this.rjButton55.TabIndex = 0;
            this.rjButton55.Text = "A2";
            this.rjButton55.TextColor = System.Drawing.Color.Black;
            this.rjButton55.UseVisualStyleBackColor = false;
            this.rjButton55.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton68
            // 
            this.rjButton68.BackColor = System.Drawing.Color.White;
            this.rjButton68.BackgroundColor = System.Drawing.Color.White;
            this.rjButton68.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton68.BorderRadius = 4;
            this.rjButton68.BorderSize = 2;
            this.rjButton68.FlatAppearance.BorderSize = 0;
            this.rjButton68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton68.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton68.ForeColor = System.Drawing.Color.Black;
            this.rjButton68.Location = new System.Drawing.Point(484, 412);
            this.rjButton68.Name = "rjButton68";
            this.rjButton68.Size = new System.Drawing.Size(41, 41);
            this.rjButton68.TabIndex = 0;
            this.rjButton68.Text = "B7";
            this.rjButton68.TextColor = System.Drawing.Color.Black;
            this.rjButton68.UseVisualStyleBackColor = false;
            this.rjButton68.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton22
            // 
            this.rjButton22.BackColor = System.Drawing.Color.White;
            this.rjButton22.BackgroundColor = System.Drawing.Color.White;
            this.rjButton22.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton22.BorderRadius = 4;
            this.rjButton22.BorderSize = 2;
            this.rjButton22.FlatAppearance.BorderSize = 0;
            this.rjButton22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton22.ForeColor = System.Drawing.Color.Black;
            this.rjButton22.Location = new System.Drawing.Point(118, 363);
            this.rjButton22.Name = "rjButton22";
            this.rjButton22.Size = new System.Drawing.Size(41, 41);
            this.rjButton22.TabIndex = 0;
            this.rjButton22.Text = "C2";
            this.rjButton22.TextColor = System.Drawing.Color.Black;
            this.rjButton22.UseVisualStyleBackColor = false;
            this.rjButton22.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton67
            // 
            this.rjButton67.BackColor = System.Drawing.Color.White;
            this.rjButton67.BackgroundColor = System.Drawing.Color.White;
            this.rjButton67.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton67.BorderRadius = 4;
            this.rjButton67.BorderSize = 2;
            this.rjButton67.FlatAppearance.BorderSize = 0;
            this.rjButton67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton67.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton67.ForeColor = System.Drawing.Color.Black;
            this.rjButton67.Location = new System.Drawing.Point(484, 317);
            this.rjButton67.Name = "rjButton67";
            this.rjButton67.Size = new System.Drawing.Size(41, 41);
            this.rjButton67.TabIndex = 0;
            this.rjButton67.Text = "D7";
            this.rjButton67.TextColor = System.Drawing.Color.Black;
            this.rjButton67.UseVisualStyleBackColor = false;
            this.rjButton67.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton54
            // 
            this.rjButton54.BackColor = System.Drawing.Color.White;
            this.rjButton54.BackgroundColor = System.Drawing.Color.White;
            this.rjButton54.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton54.BorderRadius = 4;
            this.rjButton54.BorderSize = 2;
            this.rjButton54.FlatAppearance.BorderSize = 0;
            this.rjButton54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton54.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton54.ForeColor = System.Drawing.Color.Black;
            this.rjButton54.Location = new System.Drawing.Point(298, 412);
            this.rjButton54.Name = "rjButton54";
            this.rjButton54.Size = new System.Drawing.Size(41, 41);
            this.rjButton54.TabIndex = 0;
            this.rjButton54.Text = "B5";
            this.rjButton54.TextColor = System.Drawing.Color.Black;
            this.rjButton54.UseVisualStyleBackColor = false;
            this.rjButton54.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton66
            // 
            this.rjButton66.BackColor = System.Drawing.Color.White;
            this.rjButton66.BackgroundColor = System.Drawing.Color.White;
            this.rjButton66.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton66.BorderRadius = 4;
            this.rjButton66.BorderSize = 2;
            this.rjButton66.FlatAppearance.BorderSize = 0;
            this.rjButton66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton66.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton66.ForeColor = System.Drawing.Color.Black;
            this.rjButton66.Location = new System.Drawing.Point(484, 269);
            this.rjButton66.Name = "rjButton66";
            this.rjButton66.Size = new System.Drawing.Size(41, 41);
            this.rjButton66.TabIndex = 0;
            this.rjButton66.Text = "E7";
            this.rjButton66.TextColor = System.Drawing.Color.Black;
            this.rjButton66.UseVisualStyleBackColor = false;
            this.rjButton66.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton39
            // 
            this.rjButton39.BackColor = System.Drawing.Color.White;
            this.rjButton39.BackgroundColor = System.Drawing.Color.White;
            this.rjButton39.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton39.BorderRadius = 4;
            this.rjButton39.BorderSize = 2;
            this.rjButton39.FlatAppearance.BorderSize = 0;
            this.rjButton39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton39.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton39.ForeColor = System.Drawing.Color.Black;
            this.rjButton39.Location = new System.Drawing.Point(298, 317);
            this.rjButton39.Name = "rjButton39";
            this.rjButton39.Size = new System.Drawing.Size(41, 41);
            this.rjButton39.TabIndex = 0;
            this.rjButton39.Text = "D5";
            this.rjButton39.TextColor = System.Drawing.Color.Black;
            this.rjButton39.UseVisualStyleBackColor = false;
            this.rjButton39.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton38
            // 
            this.rjButton38.BackColor = System.Drawing.Color.White;
            this.rjButton38.BackgroundColor = System.Drawing.Color.White;
            this.rjButton38.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton38.BorderRadius = 4;
            this.rjButton38.BorderSize = 2;
            this.rjButton38.FlatAppearance.BorderSize = 0;
            this.rjButton38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton38.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton38.ForeColor = System.Drawing.Color.Black;
            this.rjButton38.Location = new System.Drawing.Point(298, 269);
            this.rjButton38.Name = "rjButton38";
            this.rjButton38.Size = new System.Drawing.Size(41, 41);
            this.rjButton38.TabIndex = 0;
            this.rjButton38.Text = "E5";
            this.rjButton38.TextColor = System.Drawing.Color.Black;
            this.rjButton38.UseVisualStyleBackColor = false;
            this.rjButton38.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton53
            // 
            this.rjButton53.BackColor = System.Drawing.Color.White;
            this.rjButton53.BackgroundColor = System.Drawing.Color.White;
            this.rjButton53.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton53.BorderRadius = 4;
            this.rjButton53.BorderSize = 2;
            this.rjButton53.FlatAppearance.BorderSize = 0;
            this.rjButton53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton53.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton53.ForeColor = System.Drawing.Color.Black;
            this.rjButton53.Location = new System.Drawing.Point(118, 412);
            this.rjButton53.Name = "rjButton53";
            this.rjButton53.Size = new System.Drawing.Size(41, 41);
            this.rjButton53.TabIndex = 0;
            this.rjButton53.Text = "B2";
            this.rjButton53.TextColor = System.Drawing.Color.Black;
            this.rjButton53.UseVisualStyleBackColor = false;
            this.rjButton53.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton65
            // 
            this.rjButton65.BackColor = System.Drawing.Color.White;
            this.rjButton65.BackgroundColor = System.Drawing.Color.White;
            this.rjButton65.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton65.BorderRadius = 4;
            this.rjButton65.BorderSize = 2;
            this.rjButton65.FlatAppearance.BorderSize = 0;
            this.rjButton65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton65.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton65.ForeColor = System.Drawing.Color.Black;
            this.rjButton65.Location = new System.Drawing.Point(484, 223);
            this.rjButton65.Name = "rjButton65";
            this.rjButton65.Size = new System.Drawing.Size(41, 41);
            this.rjButton65.TabIndex = 0;
            this.rjButton65.Text = "F7";
            this.rjButton65.TextColor = System.Drawing.Color.Black;
            this.rjButton65.UseVisualStyleBackColor = false;
            this.rjButton65.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton21
            // 
            this.rjButton21.BackColor = System.Drawing.Color.White;
            this.rjButton21.BackgroundColor = System.Drawing.Color.White;
            this.rjButton21.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton21.BorderRadius = 4;
            this.rjButton21.BorderSize = 2;
            this.rjButton21.FlatAppearance.BorderSize = 0;
            this.rjButton21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton21.ForeColor = System.Drawing.Color.Black;
            this.rjButton21.Location = new System.Drawing.Point(118, 317);
            this.rjButton21.Name = "rjButton21";
            this.rjButton21.Size = new System.Drawing.Size(41, 41);
            this.rjButton21.TabIndex = 0;
            this.rjButton21.Text = "D2";
            this.rjButton21.TextColor = System.Drawing.Color.Black;
            this.rjButton21.UseVisualStyleBackColor = false;
            this.rjButton21.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton37
            // 
            this.rjButton37.BackColor = System.Drawing.Color.White;
            this.rjButton37.BackgroundColor = System.Drawing.Color.White;
            this.rjButton37.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton37.BorderRadius = 4;
            this.rjButton37.BorderSize = 2;
            this.rjButton37.FlatAppearance.BorderSize = 0;
            this.rjButton37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton37.ForeColor = System.Drawing.Color.Black;
            this.rjButton37.Location = new System.Drawing.Point(298, 223);
            this.rjButton37.Name = "rjButton37";
            this.rjButton37.Size = new System.Drawing.Size(41, 41);
            this.rjButton37.TabIndex = 0;
            this.rjButton37.Text = "F5";
            this.rjButton37.TextColor = System.Drawing.Color.Black;
            this.rjButton37.UseVisualStyleBackColor = false;
            this.rjButton37.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton64
            // 
            this.rjButton64.BackColor = System.Drawing.Color.White;
            this.rjButton64.BackgroundColor = System.Drawing.Color.White;
            this.rjButton64.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton64.BorderRadius = 4;
            this.rjButton64.BorderSize = 2;
            this.rjButton64.FlatAppearance.BorderSize = 0;
            this.rjButton64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton64.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton64.ForeColor = System.Drawing.Color.Black;
            this.rjButton64.Location = new System.Drawing.Point(484, 223);
            this.rjButton64.Name = "rjButton64";
            this.rjButton64.Size = new System.Drawing.Size(41, 41);
            this.rjButton64.TabIndex = 0;
            this.rjButton64.Text = "A1";
            this.rjButton64.TextColor = System.Drawing.Color.Black;
            this.rjButton64.UseVisualStyleBackColor = false;
            this.rjButton64.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton16
            // 
            this.rjButton16.BackColor = System.Drawing.Color.White;
            this.rjButton16.BackgroundColor = System.Drawing.Color.White;
            this.rjButton16.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton16.BorderRadius = 4;
            this.rjButton16.BorderSize = 2;
            this.rjButton16.FlatAppearance.BorderSize = 0;
            this.rjButton16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton16.ForeColor = System.Drawing.Color.Black;
            this.rjButton16.Location = new System.Drawing.Point(118, 269);
            this.rjButton16.Name = "rjButton16";
            this.rjButton16.Size = new System.Drawing.Size(41, 41);
            this.rjButton16.TabIndex = 0;
            this.rjButton16.Text = "E2";
            this.rjButton16.TextColor = System.Drawing.Color.Black;
            this.rjButton16.UseVisualStyleBackColor = false;
            this.rjButton16.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton36
            // 
            this.rjButton36.BackColor = System.Drawing.Color.White;
            this.rjButton36.BackgroundColor = System.Drawing.Color.White;
            this.rjButton36.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton36.BorderRadius = 4;
            this.rjButton36.BorderSize = 2;
            this.rjButton36.FlatAppearance.BorderSize = 0;
            this.rjButton36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton36.ForeColor = System.Drawing.Color.Black;
            this.rjButton36.Location = new System.Drawing.Point(298, 223);
            this.rjButton36.Name = "rjButton36";
            this.rjButton36.Size = new System.Drawing.Size(41, 41);
            this.rjButton36.TabIndex = 0;
            this.rjButton36.Text = "A1";
            this.rjButton36.TextColor = System.Drawing.Color.Black;
            this.rjButton36.UseVisualStyleBackColor = false;
            this.rjButton36.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton15
            // 
            this.rjButton15.BackColor = System.Drawing.Color.White;
            this.rjButton15.BackgroundColor = System.Drawing.Color.White;
            this.rjButton15.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton15.BorderRadius = 4;
            this.rjButton15.BorderSize = 2;
            this.rjButton15.FlatAppearance.BorderSize = 0;
            this.rjButton15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton15.ForeColor = System.Drawing.Color.Black;
            this.rjButton15.Location = new System.Drawing.Point(118, 223);
            this.rjButton15.Name = "rjButton15";
            this.rjButton15.Size = new System.Drawing.Size(41, 41);
            this.rjButton15.TabIndex = 0;
            this.rjButton15.Text = "F2";
            this.rjButton15.TextColor = System.Drawing.Color.Black;
            this.rjButton15.UseVisualStyleBackColor = false;
            this.rjButton15.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton52
            // 
            this.rjButton52.BackColor = System.Drawing.Color.White;
            this.rjButton52.BackgroundColor = System.Drawing.Color.White;
            this.rjButton52.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton52.BorderRadius = 4;
            this.rjButton52.BorderSize = 2;
            this.rjButton52.FlatAppearance.BorderSize = 0;
            this.rjButton52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton52.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton52.ForeColor = System.Drawing.Color.Black;
            this.rjButton52.Location = new System.Drawing.Point(240, 458);
            this.rjButton52.Name = "rjButton52";
            this.rjButton52.Size = new System.Drawing.Size(41, 41);
            this.rjButton52.TabIndex = 0;
            this.rjButton52.Text = "A4";
            this.rjButton52.TextColor = System.Drawing.Color.Black;
            this.rjButton52.UseVisualStyleBackColor = false;
            this.rjButton52.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton35
            // 
            this.rjButton35.BackColor = System.Drawing.Color.White;
            this.rjButton35.BackgroundColor = System.Drawing.Color.White;
            this.rjButton35.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton35.BorderRadius = 4;
            this.rjButton35.BorderSize = 2;
            this.rjButton35.FlatAppearance.BorderSize = 0;
            this.rjButton35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton35.ForeColor = System.Drawing.Color.Black;
            this.rjButton35.Location = new System.Drawing.Point(240, 363);
            this.rjButton35.Name = "rjButton35";
            this.rjButton35.Size = new System.Drawing.Size(41, 41);
            this.rjButton35.TabIndex = 0;
            this.rjButton35.Text = "C4";
            this.rjButton35.TextColor = System.Drawing.Color.Black;
            this.rjButton35.UseVisualStyleBackColor = false;
            this.rjButton35.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton10
            // 
            this.rjButton10.BackColor = System.Drawing.Color.White;
            this.rjButton10.BackgroundColor = System.Drawing.Color.White;
            this.rjButton10.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton10.BorderRadius = 4;
            this.rjButton10.BorderSize = 2;
            this.rjButton10.FlatAppearance.BorderSize = 0;
            this.rjButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton10.ForeColor = System.Drawing.Color.Black;
            this.rjButton10.Location = new System.Drawing.Point(118, 223);
            this.rjButton10.Name = "rjButton10";
            this.rjButton10.Size = new System.Drawing.Size(41, 41);
            this.rjButton10.TabIndex = 0;
            this.rjButton10.Text = "A1";
            this.rjButton10.TextColor = System.Drawing.Color.Black;
            this.rjButton10.UseVisualStyleBackColor = false;
            this.rjButton10.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton63
            // 
            this.rjButton63.BackColor = System.Drawing.Color.White;
            this.rjButton63.BackgroundColor = System.Drawing.Color.White;
            this.rjButton63.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton63.BorderRadius = 4;
            this.rjButton63.BorderSize = 2;
            this.rjButton63.FlatAppearance.BorderSize = 0;
            this.rjButton63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton63.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton63.ForeColor = System.Drawing.Color.Black;
            this.rjButton63.Location = new System.Drawing.Point(484, 177);
            this.rjButton63.Name = "rjButton63";
            this.rjButton63.Size = new System.Drawing.Size(41, 41);
            this.rjButton63.TabIndex = 0;
            this.rjButton63.Text = "G7";
            this.rjButton63.TextColor = System.Drawing.Color.Black;
            this.rjButton63.UseVisualStyleBackColor = false;
            this.rjButton63.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton51
            // 
            this.rjButton51.BackColor = System.Drawing.Color.White;
            this.rjButton51.BackgroundColor = System.Drawing.Color.White;
            this.rjButton51.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton51.BorderRadius = 4;
            this.rjButton51.BorderSize = 2;
            this.rjButton51.FlatAppearance.BorderSize = 0;
            this.rjButton51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton51.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton51.ForeColor = System.Drawing.Color.Black;
            this.rjButton51.Location = new System.Drawing.Point(60, 458);
            this.rjButton51.Name = "rjButton51";
            this.rjButton51.Size = new System.Drawing.Size(41, 41);
            this.rjButton51.TabIndex = 0;
            this.rjButton51.Text = "A1";
            this.rjButton51.TextColor = System.Drawing.Color.Black;
            this.rjButton51.UseVisualStyleBackColor = false;
            this.rjButton51.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton34
            // 
            this.rjButton34.BackColor = System.Drawing.Color.White;
            this.rjButton34.BackgroundColor = System.Drawing.Color.White;
            this.rjButton34.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton34.BorderRadius = 4;
            this.rjButton34.BorderSize = 2;
            this.rjButton34.FlatAppearance.BorderSize = 0;
            this.rjButton34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton34.ForeColor = System.Drawing.Color.Black;
            this.rjButton34.Location = new System.Drawing.Point(298, 177);
            this.rjButton34.Name = "rjButton34";
            this.rjButton34.Size = new System.Drawing.Size(41, 41);
            this.rjButton34.TabIndex = 0;
            this.rjButton34.Text = "G5";
            this.rjButton34.TextColor = System.Drawing.Color.Black;
            this.rjButton34.UseVisualStyleBackColor = false;
            this.rjButton34.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton20
            // 
            this.rjButton20.BackColor = System.Drawing.Color.White;
            this.rjButton20.BackgroundColor = System.Drawing.Color.White;
            this.rjButton20.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton20.BorderRadius = 4;
            this.rjButton20.BorderSize = 2;
            this.rjButton20.FlatAppearance.BorderSize = 0;
            this.rjButton20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton20.ForeColor = System.Drawing.Color.Black;
            this.rjButton20.Location = new System.Drawing.Point(60, 363);
            this.rjButton20.Name = "rjButton20";
            this.rjButton20.Size = new System.Drawing.Size(41, 41);
            this.rjButton20.TabIndex = 0;
            this.rjButton20.Text = "C1";
            this.rjButton20.TextColor = System.Drawing.Color.Black;
            this.rjButton20.UseVisualStyleBackColor = false;
            this.rjButton20.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton33
            // 
            this.rjButton33.BackColor = System.Drawing.Color.White;
            this.rjButton33.BackgroundColor = System.Drawing.Color.White;
            this.rjButton33.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton33.BorderRadius = 4;
            this.rjButton33.BorderSize = 2;
            this.rjButton33.FlatAppearance.BorderSize = 0;
            this.rjButton33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton33.ForeColor = System.Drawing.Color.Black;
            this.rjButton33.Location = new System.Drawing.Point(240, 269);
            this.rjButton33.Name = "rjButton33";
            this.rjButton33.Size = new System.Drawing.Size(41, 41);
            this.rjButton33.TabIndex = 0;
            this.rjButton33.Text = "E4";
            this.rjButton33.TextColor = System.Drawing.Color.Black;
            this.rjButton33.UseVisualStyleBackColor = false;
            this.rjButton33.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton62
            // 
            this.rjButton62.BackColor = System.Drawing.Color.White;
            this.rjButton62.BackgroundColor = System.Drawing.Color.White;
            this.rjButton62.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton62.BorderRadius = 4;
            this.rjButton62.BorderSize = 2;
            this.rjButton62.FlatAppearance.BorderSize = 0;
            this.rjButton62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton62.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton62.ForeColor = System.Drawing.Color.Black;
            this.rjButton62.Location = new System.Drawing.Point(484, 127);
            this.rjButton62.Name = "rjButton62";
            this.rjButton62.Size = new System.Drawing.Size(41, 41);
            this.rjButton62.TabIndex = 0;
            this.rjButton62.Text = "H7";
            this.rjButton62.TextColor = System.Drawing.Color.Black;
            this.rjButton62.UseVisualStyleBackColor = false;
            this.rjButton62.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton9
            // 
            this.rjButton9.BackColor = System.Drawing.Color.White;
            this.rjButton9.BackgroundColor = System.Drawing.Color.White;
            this.rjButton9.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton9.BorderRadius = 4;
            this.rjButton9.BorderSize = 2;
            this.rjButton9.FlatAppearance.BorderSize = 0;
            this.rjButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton9.ForeColor = System.Drawing.Color.Black;
            this.rjButton9.Location = new System.Drawing.Point(118, 177);
            this.rjButton9.Name = "rjButton9";
            this.rjButton9.Size = new System.Drawing.Size(41, 41);
            this.rjButton9.TabIndex = 0;
            this.rjButton9.Text = "G2";
            this.rjButton9.TextColor = System.Drawing.Color.Black;
            this.rjButton9.UseVisualStyleBackColor = false;
            this.rjButton9.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton32
            // 
            this.rjButton32.BackColor = System.Drawing.Color.White;
            this.rjButton32.BackgroundColor = System.Drawing.Color.White;
            this.rjButton32.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton32.BorderRadius = 4;
            this.rjButton32.BorderSize = 2;
            this.rjButton32.FlatAppearance.BorderSize = 0;
            this.rjButton32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton32.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton32.ForeColor = System.Drawing.Color.Black;
            this.rjButton32.Location = new System.Drawing.Point(298, 127);
            this.rjButton32.Name = "rjButton32";
            this.rjButton32.Size = new System.Drawing.Size(41, 41);
            this.rjButton32.TabIndex = 0;
            this.rjButton32.Text = "H5";
            this.rjButton32.TextColor = System.Drawing.Color.Black;
            this.rjButton32.UseVisualStyleBackColor = false;
            this.rjButton32.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton50
            // 
            this.rjButton50.BackColor = System.Drawing.Color.White;
            this.rjButton50.BackgroundColor = System.Drawing.Color.White;
            this.rjButton50.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton50.BorderRadius = 4;
            this.rjButton50.BorderSize = 2;
            this.rjButton50.FlatAppearance.BorderSize = 0;
            this.rjButton50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton50.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton50.ForeColor = System.Drawing.Color.Black;
            this.rjButton50.Location = new System.Drawing.Point(240, 412);
            this.rjButton50.Name = "rjButton50";
            this.rjButton50.Size = new System.Drawing.Size(41, 41);
            this.rjButton50.TabIndex = 0;
            this.rjButton50.Text = "B4";
            this.rjButton50.TextColor = System.Drawing.Color.Black;
            this.rjButton50.UseVisualStyleBackColor = false;
            this.rjButton50.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton14
            // 
            this.rjButton14.BackColor = System.Drawing.Color.White;
            this.rjButton14.BackgroundColor = System.Drawing.Color.White;
            this.rjButton14.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton14.BorderRadius = 4;
            this.rjButton14.BorderSize = 2;
            this.rjButton14.FlatAppearance.BorderSize = 0;
            this.rjButton14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton14.ForeColor = System.Drawing.Color.Black;
            this.rjButton14.Location = new System.Drawing.Point(60, 269);
            this.rjButton14.Name = "rjButton14";
            this.rjButton14.Size = new System.Drawing.Size(41, 41);
            this.rjButton14.TabIndex = 0;
            this.rjButton14.Text = "E1";
            this.rjButton14.TextColor = System.Drawing.Color.Black;
            this.rjButton14.UseVisualStyleBackColor = false;
            this.rjButton14.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton31
            // 
            this.rjButton31.BackColor = System.Drawing.Color.White;
            this.rjButton31.BackgroundColor = System.Drawing.Color.White;
            this.rjButton31.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton31.BorderRadius = 4;
            this.rjButton31.BorderSize = 2;
            this.rjButton31.FlatAppearance.BorderSize = 0;
            this.rjButton31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton31.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton31.ForeColor = System.Drawing.Color.Black;
            this.rjButton31.Location = new System.Drawing.Point(240, 317);
            this.rjButton31.Name = "rjButton31";
            this.rjButton31.Size = new System.Drawing.Size(41, 41);
            this.rjButton31.TabIndex = 0;
            this.rjButton31.Text = "D4";
            this.rjButton31.TextColor = System.Drawing.Color.Black;
            this.rjButton31.UseVisualStyleBackColor = false;
            this.rjButton31.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton5
            // 
            this.rjButton5.BackColor = System.Drawing.Color.White;
            this.rjButton5.BackgroundColor = System.Drawing.Color.White;
            this.rjButton5.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton5.BorderRadius = 4;
            this.rjButton5.BorderSize = 2;
            this.rjButton5.FlatAppearance.BorderSize = 0;
            this.rjButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton5.ForeColor = System.Drawing.Color.Black;
            this.rjButton5.Location = new System.Drawing.Point(118, 127);
            this.rjButton5.Name = "rjButton5";
            this.rjButton5.Size = new System.Drawing.Size(41, 41);
            this.rjButton5.TabIndex = 0;
            this.rjButton5.Text = "H2";
            this.rjButton5.TextColor = System.Drawing.Color.Black;
            this.rjButton5.UseVisualStyleBackColor = false;
            this.rjButton5.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton49
            // 
            this.rjButton49.BackColor = System.Drawing.Color.White;
            this.rjButton49.BackgroundColor = System.Drawing.Color.White;
            this.rjButton49.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton49.BorderRadius = 4;
            this.rjButton49.BorderSize = 2;
            this.rjButton49.FlatAppearance.BorderSize = 0;
            this.rjButton49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton49.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton49.ForeColor = System.Drawing.Color.Black;
            this.rjButton49.Location = new System.Drawing.Point(60, 412);
            this.rjButton49.Name = "rjButton49";
            this.rjButton49.Size = new System.Drawing.Size(41, 41);
            this.rjButton49.TabIndex = 0;
            this.rjButton49.Text = "B1";
            this.rjButton49.TextColor = System.Drawing.Color.Black;
            this.rjButton49.UseVisualStyleBackColor = false;
            this.rjButton49.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton30
            // 
            this.rjButton30.BackColor = System.Drawing.Color.White;
            this.rjButton30.BackgroundColor = System.Drawing.Color.White;
            this.rjButton30.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton30.BorderRadius = 4;
            this.rjButton30.BorderSize = 2;
            this.rjButton30.FlatAppearance.BorderSize = 0;
            this.rjButton30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton30.ForeColor = System.Drawing.Color.Black;
            this.rjButton30.Location = new System.Drawing.Point(240, 223);
            this.rjButton30.Name = "rjButton30";
            this.rjButton30.Size = new System.Drawing.Size(41, 41);
            this.rjButton30.TabIndex = 0;
            this.rjButton30.Text = "F4";
            this.rjButton30.TextColor = System.Drawing.Color.Black;
            this.rjButton30.UseVisualStyleBackColor = false;
            this.rjButton30.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton19
            // 
            this.rjButton19.BackColor = System.Drawing.Color.White;
            this.rjButton19.BackgroundColor = System.Drawing.Color.White;
            this.rjButton19.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton19.BorderRadius = 4;
            this.rjButton19.BorderSize = 2;
            this.rjButton19.FlatAppearance.BorderSize = 0;
            this.rjButton19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton19.ForeColor = System.Drawing.Color.Black;
            this.rjButton19.Location = new System.Drawing.Point(60, 317);
            this.rjButton19.Name = "rjButton19";
            this.rjButton19.Size = new System.Drawing.Size(41, 41);
            this.rjButton19.TabIndex = 0;
            this.rjButton19.Text = "D1";
            this.rjButton19.TextColor = System.Drawing.Color.Black;
            this.rjButton19.UseVisualStyleBackColor = false;
            this.rjButton19.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton29
            // 
            this.rjButton29.BackColor = System.Drawing.Color.White;
            this.rjButton29.BackgroundColor = System.Drawing.Color.White;
            this.rjButton29.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton29.BorderRadius = 4;
            this.rjButton29.BorderSize = 2;
            this.rjButton29.FlatAppearance.BorderSize = 0;
            this.rjButton29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton29.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton29.ForeColor = System.Drawing.Color.Black;
            this.rjButton29.Location = new System.Drawing.Point(240, 223);
            this.rjButton29.Name = "rjButton29";
            this.rjButton29.Size = new System.Drawing.Size(41, 41);
            this.rjButton29.TabIndex = 0;
            this.rjButton29.Text = "A1";
            this.rjButton29.TextColor = System.Drawing.Color.Black;
            this.rjButton29.UseVisualStyleBackColor = false;
            this.rjButton29.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton61
            // 
            this.rjButton61.BackColor = System.Drawing.Color.White;
            this.rjButton61.BackgroundColor = System.Drawing.Color.White;
            this.rjButton61.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton61.BorderRadius = 4;
            this.rjButton61.BorderSize = 2;
            this.rjButton61.FlatAppearance.BorderSize = 0;
            this.rjButton61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton61.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton61.ForeColor = System.Drawing.Color.Black;
            this.rjButton61.Location = new System.Drawing.Point(484, 81);
            this.rjButton61.Name = "rjButton61";
            this.rjButton61.Size = new System.Drawing.Size(41, 41);
            this.rjButton61.TabIndex = 0;
            this.rjButton61.Text = "J7";
            this.rjButton61.TextColor = System.Drawing.Color.Black;
            this.rjButton61.UseVisualStyleBackColor = false;
            this.rjButton61.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton8
            // 
            this.rjButton8.BackColor = System.Drawing.Color.White;
            this.rjButton8.BackgroundColor = System.Drawing.Color.White;
            this.rjButton8.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton8.BorderRadius = 4;
            this.rjButton8.BorderSize = 2;
            this.rjButton8.FlatAppearance.BorderSize = 0;
            this.rjButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton8.ForeColor = System.Drawing.Color.Black;
            this.rjButton8.Location = new System.Drawing.Point(60, 223);
            this.rjButton8.Name = "rjButton8";
            this.rjButton8.Size = new System.Drawing.Size(41, 41);
            this.rjButton8.TabIndex = 0;
            this.rjButton8.Text = "F1";
            this.rjButton8.TextColor = System.Drawing.Color.Black;
            this.rjButton8.UseVisualStyleBackColor = false;
            this.rjButton8.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton28
            // 
            this.rjButton28.BackColor = System.Drawing.Color.White;
            this.rjButton28.BackgroundColor = System.Drawing.Color.White;
            this.rjButton28.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton28.BorderRadius = 4;
            this.rjButton28.BorderSize = 2;
            this.rjButton28.FlatAppearance.BorderSize = 0;
            this.rjButton28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton28.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton28.ForeColor = System.Drawing.Color.Black;
            this.rjButton28.Location = new System.Drawing.Point(298, 81);
            this.rjButton28.Name = "rjButton28";
            this.rjButton28.Size = new System.Drawing.Size(41, 41);
            this.rjButton28.TabIndex = 0;
            this.rjButton28.Text = "J5";
            this.rjButton28.TextColor = System.Drawing.Color.Black;
            this.rjButton28.UseVisualStyleBackColor = false;
            this.rjButton28.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton13
            // 
            this.rjButton13.BackColor = System.Drawing.Color.White;
            this.rjButton13.BackgroundColor = System.Drawing.Color.White;
            this.rjButton13.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton13.BorderRadius = 4;
            this.rjButton13.BorderSize = 2;
            this.rjButton13.FlatAppearance.BorderSize = 0;
            this.rjButton13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton13.ForeColor = System.Drawing.Color.Black;
            this.rjButton13.Location = new System.Drawing.Point(60, 223);
            this.rjButton13.Name = "rjButton13";
            this.rjButton13.Size = new System.Drawing.Size(40, 40);
            this.rjButton13.TabIndex = 0;
            this.rjButton13.Text = "A1";
            this.rjButton13.TextColor = System.Drawing.Color.Black;
            this.rjButton13.UseVisualStyleBackColor = false;
            this.rjButton13.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton27
            // 
            this.rjButton27.BackColor = System.Drawing.Color.White;
            this.rjButton27.BackgroundColor = System.Drawing.Color.White;
            this.rjButton27.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton27.BorderRadius = 4;
            this.rjButton27.BorderSize = 2;
            this.rjButton27.FlatAppearance.BorderSize = 0;
            this.rjButton27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton27.ForeColor = System.Drawing.Color.Black;
            this.rjButton27.Location = new System.Drawing.Point(240, 177);
            this.rjButton27.Name = "rjButton27";
            this.rjButton27.Size = new System.Drawing.Size(41, 41);
            this.rjButton27.TabIndex = 0;
            this.rjButton27.Text = "G4";
            this.rjButton27.TextColor = System.Drawing.Color.Black;
            this.rjButton27.UseVisualStyleBackColor = false;
            this.rjButton27.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton2
            // 
            this.rjButton2.BackColor = System.Drawing.Color.White;
            this.rjButton2.BackgroundColor = System.Drawing.Color.White;
            this.rjButton2.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton2.BorderRadius = 4;
            this.rjButton2.BorderSize = 2;
            this.rjButton2.FlatAppearance.BorderSize = 0;
            this.rjButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton2.ForeColor = System.Drawing.Color.Black;
            this.rjButton2.Location = new System.Drawing.Point(118, 81);
            this.rjButton2.Name = "rjButton2";
            this.rjButton2.Size = new System.Drawing.Size(41, 41);
            this.rjButton2.TabIndex = 0;
            this.rjButton2.Text = "J2";
            this.rjButton2.TextColor = System.Drawing.Color.Black;
            this.rjButton2.UseVisualStyleBackColor = false;
            this.rjButton2.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton26
            // 
            this.rjButton26.BackColor = System.Drawing.Color.White;
            this.rjButton26.BackgroundColor = System.Drawing.Color.White;
            this.rjButton26.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton26.BorderRadius = 4;
            this.rjButton26.BorderSize = 2;
            this.rjButton26.FlatAppearance.BorderSize = 0;
            this.rjButton26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton26.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton26.ForeColor = System.Drawing.Color.Black;
            this.rjButton26.Location = new System.Drawing.Point(240, 127);
            this.rjButton26.Name = "rjButton26";
            this.rjButton26.Size = new System.Drawing.Size(41, 41);
            this.rjButton26.TabIndex = 0;
            this.rjButton26.Text = "H4";
            this.rjButton26.TextColor = System.Drawing.Color.Black;
            this.rjButton26.UseVisualStyleBackColor = false;
            this.rjButton26.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton7
            // 
            this.rjButton7.BackColor = System.Drawing.Color.White;
            this.rjButton7.BackgroundColor = System.Drawing.Color.White;
            this.rjButton7.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton7.BorderRadius = 4;
            this.rjButton7.BorderSize = 2;
            this.rjButton7.FlatAppearance.BorderSize = 0;
            this.rjButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton7.ForeColor = System.Drawing.Color.Black;
            this.rjButton7.Location = new System.Drawing.Point(60, 177);
            this.rjButton7.Name = "rjButton7";
            this.rjButton7.Size = new System.Drawing.Size(41, 41);
            this.rjButton7.TabIndex = 0;
            this.rjButton7.Text = "G1";
            this.rjButton7.TextColor = System.Drawing.Color.Black;
            this.rjButton7.UseVisualStyleBackColor = false;
            this.rjButton7.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton25
            // 
            this.rjButton25.BackColor = System.Drawing.Color.White;
            this.rjButton25.BackgroundColor = System.Drawing.Color.White;
            this.rjButton25.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton25.BorderRadius = 4;
            this.rjButton25.BorderSize = 2;
            this.rjButton25.FlatAppearance.BorderSize = 0;
            this.rjButton25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton25.ForeColor = System.Drawing.Color.Black;
            this.rjButton25.Location = new System.Drawing.Point(240, 81);
            this.rjButton25.Name = "rjButton25";
            this.rjButton25.Size = new System.Drawing.Size(41, 41);
            this.rjButton25.TabIndex = 0;
            this.rjButton25.Text = "J4";
            this.rjButton25.TextColor = System.Drawing.Color.Black;
            this.rjButton25.UseVisualStyleBackColor = false;
            this.rjButton25.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton4
            // 
            this.rjButton4.BackColor = System.Drawing.Color.White;
            this.rjButton4.BackgroundColor = System.Drawing.Color.White;
            this.rjButton4.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton4.BorderRadius = 4;
            this.rjButton4.BorderSize = 2;
            this.rjButton4.FlatAppearance.BorderSize = 0;
            this.rjButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton4.ForeColor = System.Drawing.Color.Black;
            this.rjButton4.Location = new System.Drawing.Point(60, 127);
            this.rjButton4.Name = "rjButton4";
            this.rjButton4.Size = new System.Drawing.Size(41, 41);
            this.rjButton4.TabIndex = 0;
            this.rjButton4.Text = "H1";
            this.rjButton4.TextColor = System.Drawing.Color.Black;
            this.rjButton4.UseVisualStyleBackColor = false;
            this.rjButton4.Click += new System.EventHandler(this.Button_Click);
            // 
            // rjButton1
            // 
            this.rjButton1.BackColor = System.Drawing.Color.White;
            this.rjButton1.BackgroundColor = System.Drawing.Color.White;
            this.rjButton1.BorderColor = System.Drawing.Color.SpringGreen;
            this.rjButton1.BorderRadius = 4;
            this.rjButton1.BorderSize = 2;
            this.rjButton1.FlatAppearance.BorderSize = 0;
            this.rjButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton1.ForeColor = System.Drawing.Color.Black;
            this.rjButton1.Location = new System.Drawing.Point(60, 81);
            this.rjButton1.Name = "rjButton1";
            this.rjButton1.Size = new System.Drawing.Size(41, 41);
            this.rjButton1.TabIndex = 0;
            this.rjButton1.Text = "J1";
            this.rjButton1.TextColor = System.Drawing.Color.Black;
            this.rjButton1.UseVisualStyleBackColor = false;
            this.rjButton1.Click += new System.EventHandler(this.Button_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 50;
            this.bunifuElipse1.TargetControl = this;
            // 
            // DatPhim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 615);
            this.Controls.Add(this.bunifuShadowPanel1);
            this.Controls.Add(this.bunifuButton1);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.rjButton80);
            this.Controls.Add(this.rjButton60);
            this.Controls.Add(this.rjButton79);
            this.Controls.Add(this.rjButton48);
            this.Controls.Add(this.rjButton59);
            this.Controls.Add(this.rjButton24);
            this.Controls.Add(this.rjButton78);
            this.Controls.Add(this.rjButton47);
            this.Controls.Add(this.rjButton18);
            this.Controls.Add(this.rjButton77);
            this.Controls.Add(this.rjButton46);
            this.Controls.Add(this.rjButton12);
            this.Controls.Add(this.rjButton76);
            this.Controls.Add(this.rjButton45);
            this.Controls.Add(this.rjButton6);
            this.Controls.Add(this.rjButton75);
            this.Controls.Add(this.rjButton58);
            this.Controls.Add(this.rjButton74);
            this.Controls.Add(this.rjButton44);
            this.Controls.Add(this.rjButton57);
            this.Controls.Add(this.rjButton23);
            this.Controls.Add(this.rjButton73);
            this.Controls.Add(this.rjButton43);
            this.Controls.Add(this.rjButton17);
            this.Controls.Add(this.rjButton72);
            this.Controls.Add(this.rjButton42);
            this.Controls.Add(this.rjButton11);
            this.Controls.Add(this.rjButton71);
            this.Controls.Add(this.rjButton41);
            this.Controls.Add(this.rjButton3);
            this.Controls.Add(this.rjButton70);
            this.Controls.Add(this.rjButton56);
            this.Controls.Add(this.rjButton69);
            this.Controls.Add(this.rjButton40);
            this.Controls.Add(this.rjButton55);
            this.Controls.Add(this.rjButton68);
            this.Controls.Add(this.rjButton22);
            this.Controls.Add(this.rjButton67);
            this.Controls.Add(this.rjButton54);
            this.Controls.Add(this.rjButton66);
            this.Controls.Add(this.rjButton39);
            this.Controls.Add(this.rjButton38);
            this.Controls.Add(this.rjButton53);
            this.Controls.Add(this.rjButton65);
            this.Controls.Add(this.rjButton21);
            this.Controls.Add(this.rjButton37);
            this.Controls.Add(this.rjButton64);
            this.Controls.Add(this.rjButton16);
            this.Controls.Add(this.rjButton36);
            this.Controls.Add(this.rjButton15);
            this.Controls.Add(this.rjButton52);
            this.Controls.Add(this.rjButton35);
            this.Controls.Add(this.rjButton10);
            this.Controls.Add(this.rjButton63);
            this.Controls.Add(this.rjButton51);
            this.Controls.Add(this.rjButton34);
            this.Controls.Add(this.rjButton20);
            this.Controls.Add(this.rjButton33);
            this.Controls.Add(this.rjButton62);
            this.Controls.Add(this.rjButton9);
            this.Controls.Add(this.rjButton32);
            this.Controls.Add(this.rjButton50);
            this.Controls.Add(this.rjButton14);
            this.Controls.Add(this.rjButton31);
            this.Controls.Add(this.rjButton5);
            this.Controls.Add(this.rjButton49);
            this.Controls.Add(this.rjButton30);
            this.Controls.Add(this.rjButton19);
            this.Controls.Add(this.rjButton29);
            this.Controls.Add(this.rjButton61);
            this.Controls.Add(this.rjButton8);
            this.Controls.Add(this.rjButton28);
            this.Controls.Add(this.rjButton13);
            this.Controls.Add(this.rjButton27);
            this.Controls.Add(this.rjButton2);
            this.Controls.Add(this.rjButton26);
            this.Controls.Add(this.rjButton7);
            this.Controls.Add(this.rjButton25);
            this.Controls.Add(this.rjButton4);
            this.Controls.Add(this.rjButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DatPhim";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DatPhim";
            this.Load += new System.EventHandler(this.DatPhim_Load);
            this.Click += new System.EventHandler(this.Button_Click);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.bunifuShadowPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_anhPhim)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private CustomControls.RJControls.RJButton rjButton1;
		private CustomControls.RJControls.RJButton rjButton2;
		private CustomControls.RJControls.RJButton rjButton3;
		private CustomControls.RJControls.RJButton rjButton4;
		private CustomControls.RJControls.RJButton rjButton5;
		private CustomControls.RJControls.RJButton rjButton6;
		private CustomControls.RJControls.RJButton rjButton7;
		private CustomControls.RJControls.RJButton rjButton8;
		private CustomControls.RJControls.RJButton rjButton9;
		private CustomControls.RJControls.RJButton rjButton10;
		private CustomControls.RJControls.RJButton rjButton11;
		private CustomControls.RJControls.RJButton rjButton12;
		private CustomControls.RJControls.RJButton rjButton13;
		private CustomControls.RJControls.RJButton rjButton14;
		private CustomControls.RJControls.RJButton rjButton15;
		private CustomControls.RJControls.RJButton rjButton16;
		private CustomControls.RJControls.RJButton rjButton17;
		private CustomControls.RJControls.RJButton rjButton18;
		private CustomControls.RJControls.RJButton rjButton19;
		private CustomControls.RJControls.RJButton rjButton20;
		private CustomControls.RJControls.RJButton rjButton21;
		private CustomControls.RJControls.RJButton rjButton22;
		private CustomControls.RJControls.RJButton rjButton23;
		private CustomControls.RJControls.RJButton rjButton24;
		private CustomControls.RJControls.RJButton rjButton25;
		private CustomControls.RJControls.RJButton rjButton26;
		private CustomControls.RJControls.RJButton rjButton27;
		private CustomControls.RJControls.RJButton rjButton28;
		private CustomControls.RJControls.RJButton rjButton29;
		private CustomControls.RJControls.RJButton rjButton30;
		private CustomControls.RJControls.RJButton rjButton31;
		private CustomControls.RJControls.RJButton rjButton32;
		private CustomControls.RJControls.RJButton rjButton33;
		private CustomControls.RJControls.RJButton rjButton34;
		private CustomControls.RJControls.RJButton rjButton35;
		private CustomControls.RJControls.RJButton rjButton36;
		private CustomControls.RJControls.RJButton rjButton37;
		private CustomControls.RJControls.RJButton rjButton38;
		private CustomControls.RJControls.RJButton rjButton39;
		private CustomControls.RJControls.RJButton rjButton40;
		private CustomControls.RJControls.RJButton rjButton41;
		private CustomControls.RJControls.RJButton rjButton42;
		private CustomControls.RJControls.RJButton rjButton43;
		private CustomControls.RJControls.RJButton rjButton44;
		private CustomControls.RJControls.RJButton rjButton45;
		private CustomControls.RJControls.RJButton rjButton46;
		private CustomControls.RJControls.RJButton rjButton47;
		private CustomControls.RJControls.RJButton rjButton48;
		private CustomControls.RJControls.RJButton rjButton49;
		private CustomControls.RJControls.RJButton rjButton50;
		private CustomControls.RJControls.RJButton rjButton51;
		private CustomControls.RJControls.RJButton rjButton52;
		private CustomControls.RJControls.RJButton rjButton53;
		private CustomControls.RJControls.RJButton rjButton54;
		private CustomControls.RJControls.RJButton rjButton55;
		private CustomControls.RJControls.RJButton rjButton56;
		private CustomControls.RJControls.RJButton rjButton57;
		private CustomControls.RJControls.RJButton rjButton58;
		private CustomControls.RJControls.RJButton rjButton59;
		private CustomControls.RJControls.RJButton rjButton60;
		private CustomControls.RJControls.RJButton rjButton61;
		private CustomControls.RJControls.RJButton rjButton62;
		private CustomControls.RJControls.RJButton rjButton63;
		private CustomControls.RJControls.RJButton rjButton64;
		private CustomControls.RJControls.RJButton rjButton65;
		private CustomControls.RJControls.RJButton rjButton66;
		private CustomControls.RJControls.RJButton rjButton67;
		private CustomControls.RJControls.RJButton rjButton68;
		private CustomControls.RJControls.RJButton rjButton69;
		private CustomControls.RJControls.RJButton rjButton70;
		private CustomControls.RJControls.RJButton rjButton71;
		private CustomControls.RJControls.RJButton rjButton72;
		private CustomControls.RJControls.RJButton rjButton73;
		private CustomControls.RJControls.RJButton rjButton74;
		private CustomControls.RJControls.RJButton rjButton75;
		private CustomControls.RJControls.RJButton rjButton76;
		private CustomControls.RJControls.RJButton rjButton77;
		private CustomControls.RJControls.RJButton rjButton78;
		private CustomControls.RJControls.RJButton rjButton79;
		private CustomControls.RJControls.RJButton rjButton80;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox ptb_anhPhim;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_ghe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_giave;
        private System.Windows.Forms.TextBox txt_tongtien;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_close;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel2;
        private System.Windows.Forms.Label lbl_tenPhim;
        private System.Windows.Forms.Label lbl_PhongChieu;
        private System.Windows.Forms.Label lbl_SuatChieu;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
    }
}