﻿namespace QL_RapChieuPhim.Views
{
    partial class QL_SuatChieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QL_SuatChieu));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_TimKiem = new Bunifu.UI.WinForms.BunifuTextBox();
            this.dtpNgaySuatChieu = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_Them = new CustomControls.RJControls.RJButton();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgv_SuatChieu = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnPhong5 = new System.Windows.Forms.Button();
            this.btnPhong4 = new System.Windows.Forms.Button();
            this.btnPhong3 = new System.Windows.Forms.Button();
            this.btnPhong2 = new System.Windows.Forms.Button();
            this.btnPhong1 = new System.Windows.Forms.Button();
            this.btnToanBo = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SuatChieu)).BeginInit();
            this.panelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txt_TimKiem);
            this.panel1.Controls.Add(this.dtpNgaySuatChieu);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.btn_Them);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1122, 109);
            this.panel1.TabIndex = 2;
            // 
            // txt_TimKiem
            // 
            this.txt_TimKiem.AcceptsReturn = false;
            this.txt_TimKiem.AcceptsTab = false;
            this.txt_TimKiem.AnimationSpeed = 200;
            this.txt_TimKiem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txt_TimKiem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txt_TimKiem.BackColor = System.Drawing.Color.Transparent;
            this.txt_TimKiem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txt_TimKiem.BackgroundImage")));
            this.txt_TimKiem.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txt_TimKiem.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txt_TimKiem.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txt_TimKiem.BorderColorIdle = System.Drawing.Color.Silver;
            this.txt_TimKiem.BorderRadius = 10;
            this.txt_TimKiem.BorderThickness = 1;
            this.txt_TimKiem.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txt_TimKiem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TimKiem.DefaultFont = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TimKiem.DefaultText = "";
            this.txt_TimKiem.FillColor = System.Drawing.SystemColors.Control;
            this.txt_TimKiem.ForeColor = System.Drawing.Color.Black;
            this.txt_TimKiem.HideSelection = true;
            this.txt_TimKiem.IconLeft = null;
            this.txt_TimKiem.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TimKiem.IconPadding = 10;
            this.txt_TimKiem.IconRight = null;
            this.txt_TimKiem.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TimKiem.Lines = new string[0];
            this.txt_TimKiem.Location = new System.Drawing.Point(39, 41);
            this.txt_TimKiem.MaxLength = 32767;
            this.txt_TimKiem.MinimumSize = new System.Drawing.Size(1, 1);
            this.txt_TimKiem.Modified = false;
            this.txt_TimKiem.Multiline = false;
            this.txt_TimKiem.Name = "txt_TimKiem";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_TimKiem.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txt_TimKiem.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_TimKiem.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.SystemColors.Control;
            stateProperties8.ForeColor = System.Drawing.Color.Black;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_TimKiem.OnIdleState = stateProperties8;
            this.txt_TimKiem.Padding = new System.Windows.Forms.Padding(3);
            this.txt_TimKiem.PasswordChar = '\0';
            this.txt_TimKiem.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txt_TimKiem.PlaceholderText = "Tìm kiếm phim";
            this.txt_TimKiem.ReadOnly = false;
            this.txt_TimKiem.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_TimKiem.SelectedText = "";
            this.txt_TimKiem.SelectionLength = 0;
            this.txt_TimKiem.SelectionStart = 0;
            this.txt_TimKiem.ShortcutsEnabled = true;
            this.txt_TimKiem.Size = new System.Drawing.Size(315, 41);
            this.txt_TimKiem.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txt_TimKiem.TabIndex = 0;
            this.txt_TimKiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_TimKiem.TextMarginBottom = 0;
            this.txt_TimKiem.TextMarginLeft = 3;
            this.txt_TimKiem.TextMarginTop = 0;
            this.txt_TimKiem.TextPlaceholder = "Tìm kiếm phim";
            this.txt_TimKiem.UseSystemPasswordChar = false;
            this.txt_TimKiem.WordWrap = true;
            this.txt_TimKiem.TextChange += new System.EventHandler(this.txt_TimKiem_TextChanged);
            // 
            // dtpNgaySuatChieu
            // 
            this.dtpNgaySuatChieu.BackColor = System.Drawing.Color.Transparent;
            this.dtpNgaySuatChieu.BorderRadius = 5;
            this.dtpNgaySuatChieu.Color = System.Drawing.Color.DodgerBlue;
            this.dtpNgaySuatChieu.CustomFormat = "dd / MM / yyyy";
            this.dtpNgaySuatChieu.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.dtpNgaySuatChieu.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.dtpNgaySuatChieu.DisabledColor = System.Drawing.SystemColors.Window;
            this.dtpNgaySuatChieu.DisplayWeekNumbers = false;
            this.dtpNgaySuatChieu.DPHeight = 0;
            this.dtpNgaySuatChieu.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpNgaySuatChieu.FillDatePicker = false;
            this.dtpNgaySuatChieu.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgaySuatChieu.ForeColor = System.Drawing.Color.Black;
            this.dtpNgaySuatChieu.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgaySuatChieu.Icon = ((System.Drawing.Image)(resources.GetObject("dtpNgaySuatChieu.Icon")));
            this.dtpNgaySuatChieu.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.dtpNgaySuatChieu.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.dtpNgaySuatChieu.LeftTextMargin = 5;
            this.dtpNgaySuatChieu.Location = new System.Drawing.Point(877, 51);
            this.dtpNgaySuatChieu.MinimumSize = new System.Drawing.Size(4, 32);
            this.dtpNgaySuatChieu.Name = "dtpNgaySuatChieu";
            this.dtpNgaySuatChieu.Size = new System.Drawing.Size(237, 39);
            this.dtpNgaySuatChieu.TabIndex = 39;
            this.dtpNgaySuatChieu.Value = new System.DateTime(2023, 11, 6, 22, 18, 0, 0);
            this.dtpNgaySuatChieu.ValueChanged += new System.EventHandler(this.dtpNgaySuatChieu_ValueChanged);
            this.dtpNgaySuatChieu.MouseEnter += new System.EventHandler(this.dtpNgaySuatChieu_MouseEnter);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(39, 89);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(315, 1);
            this.panel5.TabIndex = 6;
            // 
            // btn_Them
            // 
            this.btn_Them.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_Them.BackgroundColor = System.Drawing.Color.DodgerBlue;
            this.btn_Them.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Them.BorderRadius = 15;
            this.btn_Them.BorderSize = 0;
            this.btn_Them.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Them.FlatAppearance.BorderSize = 0;
            this.btn_Them.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Them.Font = new System.Drawing.Font("Arial", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Them.ForeColor = System.Drawing.Color.White;
            this.btn_Them.Image = global::QL_RapChieuPhim.Properties.Resources.add_icon24px;
            this.btn_Them.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Them.Location = new System.Drawing.Point(396, 43);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(121, 47);
            this.btn_Them.TabIndex = 5;
            this.btn_Them.Text = " Thêm";
            this.btn_Them.TextColor = System.Drawing.Color.White;
            this.btn_Them.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Them.UseVisualStyleBackColor = false;
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.dgv_SuatChieu);
            this.panel2.Controls.Add(this.panelMenu);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1122, 505);
            this.panel2.TabIndex = 3;
            // 
            // dgv_SuatChieu
            // 
            this.dgv_SuatChieu.AllowCustomTheming = false;
            this.dgv_SuatChieu.AllowUserToAddRows = false;
            this.dgv_SuatChieu.AllowUserToDeleteRows = false;
            this.dgv_SuatChieu.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.dgv_SuatChieu.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_SuatChieu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_SuatChieu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_SuatChieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_SuatChieu.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgv_SuatChieu.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_SuatChieu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_SuatChieu.ColumnHeadersHeight = 40;
            this.dgv_SuatChieu.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgv_SuatChieu.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgv_SuatChieu.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgv_SuatChieu.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgv_SuatChieu.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgv_SuatChieu.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgv_SuatChieu.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgv_SuatChieu.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgv_SuatChieu.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dgv_SuatChieu.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgv_SuatChieu.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgv_SuatChieu.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgv_SuatChieu.CurrentTheme.Name = null;
            this.dgv_SuatChieu.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgv_SuatChieu.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgv_SuatChieu.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgv_SuatChieu.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgv_SuatChieu.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_SuatChieu.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_SuatChieu.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_SuatChieu.EnableHeadersVisualStyles = false;
            this.dgv_SuatChieu.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgv_SuatChieu.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgv_SuatChieu.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgv_SuatChieu.HeaderForeColor = System.Drawing.Color.White;
            this.dgv_SuatChieu.Location = new System.Drawing.Point(131, 115);
            this.dgv_SuatChieu.MultiSelect = false;
            this.dgv_SuatChieu.Name = "dgv_SuatChieu";
            this.dgv_SuatChieu.RowHeadersVisible = false;
            this.dgv_SuatChieu.RowHeadersWidth = 51;
            this.dgv_SuatChieu.RowTemplate.Height = 40;
            this.dgv_SuatChieu.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_SuatChieu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_SuatChieu.Size = new System.Drawing.Size(979, 354);
            this.dgv_SuatChieu.TabIndex = 0;
            this.dgv_SuatChieu.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dgv_SuatChieu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_SuatChieu_CellContentClick);
            // 
            // panelMenu
            // 
            this.panelMenu.Controls.Add(this.btnPhong5);
            this.panelMenu.Controls.Add(this.btnPhong4);
            this.panelMenu.Controls.Add(this.btnPhong3);
            this.panelMenu.Controls.Add(this.btnPhong2);
            this.panelMenu.Controls.Add(this.btnPhong1);
            this.panelMenu.Controls.Add(this.btnToanBo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(122, 505);
            this.panelMenu.TabIndex = 1;
            // 
            // btnPhong5
            // 
            this.btnPhong5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPhong5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhong5.Location = new System.Drawing.Point(0, 415);
            this.btnPhong5.Name = "btnPhong5";
            this.btnPhong5.Size = new System.Drawing.Size(122, 54);
            this.btnPhong5.TabIndex = 0;
            this.btnPhong5.Text = "Phòng 5";
            this.btnPhong5.UseVisualStyleBackColor = false;
            this.btnPhong5.Click += new System.EventHandler(this.btnPhong5_Click);
            // 
            // btnPhong4
            // 
            this.btnPhong4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPhong4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhong4.Location = new System.Drawing.Point(0, 355);
            this.btnPhong4.Name = "btnPhong4";
            this.btnPhong4.Size = new System.Drawing.Size(122, 54);
            this.btnPhong4.TabIndex = 0;
            this.btnPhong4.Text = "Phòng 4";
            this.btnPhong4.UseVisualStyleBackColor = false;
            this.btnPhong4.Click += new System.EventHandler(this.btnPhong4_Click);
            // 
            // btnPhong3
            // 
            this.btnPhong3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPhong3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhong3.Location = new System.Drawing.Point(0, 295);
            this.btnPhong3.Name = "btnPhong3";
            this.btnPhong3.Size = new System.Drawing.Size(122, 54);
            this.btnPhong3.TabIndex = 0;
            this.btnPhong3.Text = "Phòng 3";
            this.btnPhong3.UseVisualStyleBackColor = false;
            this.btnPhong3.Click += new System.EventHandler(this.btnPhong3_Click);
            // 
            // btnPhong2
            // 
            this.btnPhong2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPhong2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhong2.Location = new System.Drawing.Point(0, 235);
            this.btnPhong2.Name = "btnPhong2";
            this.btnPhong2.Size = new System.Drawing.Size(122, 54);
            this.btnPhong2.TabIndex = 0;
            this.btnPhong2.Text = "Phòng 2";
            this.btnPhong2.UseVisualStyleBackColor = false;
            this.btnPhong2.Click += new System.EventHandler(this.btnPhong2_Click);
            // 
            // btnPhong1
            // 
            this.btnPhong1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPhong1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhong1.Location = new System.Drawing.Point(0, 175);
            this.btnPhong1.Name = "btnPhong1";
            this.btnPhong1.Size = new System.Drawing.Size(122, 54);
            this.btnPhong1.TabIndex = 0;
            this.btnPhong1.Text = "Phòng 1";
            this.btnPhong1.UseVisualStyleBackColor = false;
            this.btnPhong1.Click += new System.EventHandler(this.btnPhong1_Click);
            // 
            // btnToanBo
            // 
            this.btnToanBo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnToanBo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToanBo.Location = new System.Drawing.Point(0, 115);
            this.btnToanBo.Name = "btnToanBo";
            this.btnToanBo.Size = new System.Drawing.Size(122, 54);
            this.btnToanBo.TabIndex = 0;
            this.btnToanBo.Text = "Toàn bộ";
            this.btnToanBo.UseVisualStyleBackColor = false;
            this.btnToanBo.Click += new System.EventHandler(this.btnToanBo_Click);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(122, 475);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1000, 30);
            this.panel3.TabIndex = 2;
            // 
            // QL_SuatChieu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1122, 505);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "QL_SuatChieu";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÝ SUẤT CHIẾU";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.QL_XuatChieu_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SuatChieu)).EndInit();
            this.panelMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private CustomControls.RJControls.RJButton btn_Them;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnToanBo;
        private System.Windows.Forms.Button btnPhong3;
        private System.Windows.Forms.Button btnPhong2;
        private System.Windows.Forms.Button btnPhong1;
        private System.Windows.Forms.Button btnPhong5;
        private System.Windows.Forms.Button btnPhong4;
        public Bunifu.UI.WinForms.BunifuDataGridView dgv_SuatChieu;
        public Bunifu.UI.WinForms.BunifuDatePicker dtpNgaySuatChieu;
        private Bunifu.UI.WinForms.BunifuTextBox txt_TimKiem;
        private System.Windows.Forms.Panel panel3;
    }
}