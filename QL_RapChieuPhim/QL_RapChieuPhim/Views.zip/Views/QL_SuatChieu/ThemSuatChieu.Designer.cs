﻿namespace QL_RapChieuPhim.Views
{
    partial class ThemSuatChieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemSuatChieu));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel_ChuThich = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.lblGiaVe = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblPhongChieu = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblGioChieu = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblNgayChieu = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblTenPhim = new Bunifu.UI.WinForms.BunifuLabel();
            this.cboTenPhim = new Bunifu.UI.WinForms.BunifuDropdown();
            this.cboPhongChieu = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.btn_luuPhim = new CustomControls.RJControls.RJButton();
            this.txtGiaVe = new Bunifu.UI.WinForms.BunifuTextBox();
            this.dtpNgaySuatChieu = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.ErrorMes = new System.Windows.Forms.ErrorProvider(this.components);
            this.dtpGioSuatChieu = new System.Windows.Forms.DateTimePicker();
            this.panel9.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_ChuThich.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorMes)).BeginInit();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Location = new System.Drawing.Point(606, 272);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(188, 1);
            this.panel9.TabIndex = 26;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(794, 1);
            this.panel10.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(257, 272);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 1);
            this.panel5.TabIndex = 27;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(794, 1);
            this.panel6.TabIndex = 4;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel8.Location = new System.Drawing.Point(27, 272);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(179, 1);
            this.panel8.TabIndex = 30;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(27, 154);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(471, 1);
            this.panel3.TabIndex = 25;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(794, 1);
            this.panel4.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(602, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 23);
            this.label3.TabIndex = 19;
            this.label3.Text = "Ngày chiếu";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(602, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 23);
            this.label7.TabIndex = 20;
            this.label7.Text = "Giá vé";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel7.Location = new System.Drawing.Point(605, 154);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(188, 1);
            this.panel7.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(23, 303);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 23);
            this.label8.TabIndex = 22;
            this.label8.Text = "Mô tả";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(269, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 23);
            this.label6.TabIndex = 23;
            this.label6.Text = "Phòng chiếu";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 23);
            this.label5.TabIndex = 21;
            this.label5.Text = "Suất chiếu";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 23);
            this.label4.TabIndex = 18;
            this.label4.Text = "Tên phim";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 21);
            this.label2.TabIndex = 17;
            this.label2.Text = "Tên phim";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(794, 1);
            this.panel2.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(1, 55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(908, 1);
            this.panel1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 27);
            this.label1.TabIndex = 15;
            this.label1.Text = "Thêm xuất chiếu";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(802, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 30);
            this.btnClose.TabIndex = 35;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // panel_ChuThich
            // 
            this.panel_ChuThich.BackColor = System.Drawing.Color.Transparent;
            this.panel_ChuThich.BorderColor = System.Drawing.Color.Black;
            this.panel_ChuThich.BorderRadius = 10;
            this.panel_ChuThich.BorderThickness = 1;
            this.panel_ChuThich.Controls.Add(this.lblGiaVe);
            this.panel_ChuThich.Controls.Add(this.lblPhongChieu);
            this.panel_ChuThich.Controls.Add(this.lblGioChieu);
            this.panel_ChuThich.Controls.Add(this.lblNgayChieu);
            this.panel_ChuThich.Controls.Add(this.lblTenPhim);
            this.panel_ChuThich.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.panel_ChuThich.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.panel_ChuThich.Location = new System.Drawing.Point(27, 343);
            this.panel_ChuThich.Name = "panel_ChuThich";
            this.panel_ChuThich.PanelColor = System.Drawing.SystemColors.Window;
            this.panel_ChuThich.PanelColor2 = System.Drawing.SystemColors.Window;
            this.panel_ChuThich.ShadowColor = System.Drawing.Color.DarkGray;
            this.panel_ChuThich.ShadowDept = 2;
            this.panel_ChuThich.ShadowDepth = 5;
            this.panel_ChuThich.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.panel_ChuThich.ShadowTopLeftVisible = false;
            this.panel_ChuThich.Size = new System.Drawing.Size(428, 270);
            this.panel_ChuThich.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.panel_ChuThich.TabIndex = 39;
            // 
            // lblGiaVe
            // 
            this.lblGiaVe.AllowParentOverrides = false;
            this.lblGiaVe.AutoEllipsis = false;
            this.lblGiaVe.CursorType = null;
            this.lblGiaVe.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiaVe.Location = new System.Drawing.Point(35, 218);
            this.lblGiaVe.Name = "lblGiaVe";
            this.lblGiaVe.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblGiaVe.Size = new System.Drawing.Size(0, 0);
            this.lblGiaVe.TabIndex = 0;
            this.lblGiaVe.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblGiaVe.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblPhongChieu
            // 
            this.lblPhongChieu.AllowParentOverrides = false;
            this.lblPhongChieu.AutoEllipsis = false;
            this.lblPhongChieu.CursorType = null;
            this.lblPhongChieu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhongChieu.Location = new System.Drawing.Point(37, 173);
            this.lblPhongChieu.Name = "lblPhongChieu";
            this.lblPhongChieu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblPhongChieu.Size = new System.Drawing.Size(0, 0);
            this.lblPhongChieu.TabIndex = 0;
            this.lblPhongChieu.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblPhongChieu.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblGioChieu
            // 
            this.lblGioChieu.AllowParentOverrides = false;
            this.lblGioChieu.AutoEllipsis = false;
            this.lblGioChieu.CursorType = null;
            this.lblGioChieu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGioChieu.Location = new System.Drawing.Point(37, 124);
            this.lblGioChieu.Name = "lblGioChieu";
            this.lblGioChieu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblGioChieu.Size = new System.Drawing.Size(0, 0);
            this.lblGioChieu.TabIndex = 0;
            this.lblGioChieu.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblGioChieu.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblNgayChieu
            // 
            this.lblNgayChieu.AllowParentOverrides = false;
            this.lblNgayChieu.AutoEllipsis = false;
            this.lblNgayChieu.CursorType = null;
            this.lblNgayChieu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgayChieu.Location = new System.Drawing.Point(37, 76);
            this.lblNgayChieu.Name = "lblNgayChieu";
            this.lblNgayChieu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblNgayChieu.Size = new System.Drawing.Size(0, 0);
            this.lblNgayChieu.TabIndex = 0;
            this.lblNgayChieu.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblNgayChieu.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblTenPhim
            // 
            this.lblTenPhim.AllowParentOverrides = false;
            this.lblTenPhim.AutoEllipsis = false;
            this.lblTenPhim.CursorType = null;
            this.lblTenPhim.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenPhim.Location = new System.Drawing.Point(37, 29);
            this.lblTenPhim.Name = "lblTenPhim";
            this.lblTenPhim.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTenPhim.Size = new System.Drawing.Size(0, 0);
            this.lblTenPhim.TabIndex = 0;
            this.lblTenPhim.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblTenPhim.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // cboTenPhim
            // 
            this.cboTenPhim.BackColor = System.Drawing.Color.Transparent;
            this.cboTenPhim.BackgroundColor = System.Drawing.SystemColors.Window;
            this.cboTenPhim.BorderColor = System.Drawing.Color.Silver;
            this.cboTenPhim.BorderRadius = 10;
            this.cboTenPhim.Color = System.Drawing.Color.Silver;
            this.cboTenPhim.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.cboTenPhim.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cboTenPhim.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cboTenPhim.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cboTenPhim.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.cboTenPhim.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.cboTenPhim.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cboTenPhim.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.cboTenPhim.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTenPhim.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cboTenPhim.FillDropDown = true;
            this.cboTenPhim.FillIndicator = false;
            this.cboTenPhim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboTenPhim.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTenPhim.ForeColor = System.Drawing.Color.Black;
            this.cboTenPhim.FormattingEnabled = true;
            this.cboTenPhim.Icon = null;
            this.cboTenPhim.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cboTenPhim.IndicatorColor = System.Drawing.Color.Black;
            this.cboTenPhim.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cboTenPhim.ItemBackColor = System.Drawing.Color.White;
            this.cboTenPhim.ItemBorderColor = System.Drawing.Color.White;
            this.cboTenPhim.ItemForeColor = System.Drawing.Color.Black;
            this.cboTenPhim.ItemHeight = 26;
            this.cboTenPhim.ItemHighLightColor = System.Drawing.SystemColors.Control;
            this.cboTenPhim.ItemHighLightForeColor = System.Drawing.Color.Black;
            this.cboTenPhim.ItemTopMargin = 3;
            this.cboTenPhim.Location = new System.Drawing.Point(27, 107);
            this.cboTenPhim.MaxDropDownItems = 3;
            this.cboTenPhim.Name = "cboTenPhim";
            this.cboTenPhim.Size = new System.Drawing.Size(471, 32);
            this.cboTenPhim.TabIndex = 41;
            this.cboTenPhim.Text = null;
            this.cboTenPhim.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cboTenPhim.TextLeftMargin = 5;
            this.cboTenPhim.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cboTenPhim_MouseDown);
            // 
            // cboPhongChieu
            // 
            this.cboPhongChieu.BackColor = System.Drawing.Color.Transparent;
            this.cboPhongChieu.BackgroundColor = System.Drawing.SystemColors.Window;
            this.cboPhongChieu.BorderColor = System.Drawing.Color.Silver;
            this.cboPhongChieu.BorderRadius = 10;
            this.cboPhongChieu.Color = System.Drawing.Color.Silver;
            this.cboPhongChieu.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.cboPhongChieu.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cboPhongChieu.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cboPhongChieu.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cboPhongChieu.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.cboPhongChieu.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.cboPhongChieu.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cboPhongChieu.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.cboPhongChieu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhongChieu.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cboPhongChieu.FillDropDown = true;
            this.cboPhongChieu.FillIndicator = false;
            this.cboPhongChieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPhongChieu.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPhongChieu.ForeColor = System.Drawing.Color.Black;
            this.cboPhongChieu.FormattingEnabled = true;
            this.cboPhongChieu.Icon = null;
            this.cboPhongChieu.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cboPhongChieu.IndicatorColor = System.Drawing.Color.Black;
            this.cboPhongChieu.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cboPhongChieu.ItemBackColor = System.Drawing.Color.White;
            this.cboPhongChieu.ItemBorderColor = System.Drawing.Color.White;
            this.cboPhongChieu.ItemForeColor = System.Drawing.Color.Black;
            this.cboPhongChieu.ItemHeight = 26;
            this.cboPhongChieu.ItemHighLightColor = System.Drawing.SystemColors.Control;
            this.cboPhongChieu.ItemHighLightForeColor = System.Drawing.Color.Black;
            this.cboPhongChieu.ItemTopMargin = 3;
            this.cboPhongChieu.Location = new System.Drawing.Point(259, 227);
            this.cboPhongChieu.Name = "cboPhongChieu";
            this.cboPhongChieu.Size = new System.Drawing.Size(198, 32);
            this.cboPhongChieu.TabIndex = 42;
            this.cboPhongChieu.Text = null;
            this.cboPhongChieu.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cboPhongChieu.TextLeftMargin = 5;
            this.cboPhongChieu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cboPhongChieu_MouseDown);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 12;
            this.bunifuElipse1.TargetControl = this;
            // 
            // btn_luuPhim
            // 
            this.btn_luuPhim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuPhim.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuPhim.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_luuPhim.BorderRadius = 16;
            this.btn_luuPhim.BorderSize = 0;
            this.btn_luuPhim.FlatAppearance.BorderSize = 0;
            this.btn_luuPhim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_luuPhim.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luuPhim.ForeColor = System.Drawing.Color.White;
            this.btn_luuPhim.Location = new System.Drawing.Point(700, 561);
            this.btn_luuPhim.Name = "btn_luuPhim";
            this.btn_luuPhim.Size = new System.Drawing.Size(117, 52);
            this.btn_luuPhim.TabIndex = 34;
            this.btn_luuPhim.Text = "Lưu";
            this.btn_luuPhim.TextColor = System.Drawing.Color.White;
            this.btn_luuPhim.UseVisualStyleBackColor = false;
            this.btn_luuPhim.Click += new System.EventHandler(this.btn_luuPhim_Click);
            // 
            // txtGiaVe
            // 
            this.txtGiaVe.AcceptsReturn = false;
            this.txtGiaVe.AcceptsTab = false;
            this.txtGiaVe.AnimationSpeed = 200;
            this.txtGiaVe.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtGiaVe.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtGiaVe.BackColor = System.Drawing.Color.Transparent;
            this.txtGiaVe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtGiaVe.BackgroundImage")));
            this.txtGiaVe.BorderColorActive = System.Drawing.SystemColors.Window;
            this.txtGiaVe.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtGiaVe.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtGiaVe.BorderColorIdle = System.Drawing.SystemColors.Window;
            this.txtGiaVe.BorderRadius = 1;
            this.txtGiaVe.BorderThickness = 1;
            this.txtGiaVe.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtGiaVe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaVe.DefaultFont = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaVe.DefaultText = "";
            this.txtGiaVe.FillColor = System.Drawing.SystemColors.Window;
            this.txtGiaVe.ForeColor = System.Drawing.Color.Black;
            this.txtGiaVe.HideSelection = true;
            this.txtGiaVe.IconLeft = null;
            this.txtGiaVe.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaVe.IconPadding = 10;
            this.txtGiaVe.IconRight = null;
            this.txtGiaVe.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaVe.Lines = new string[0];
            this.txtGiaVe.Location = new System.Drawing.Point(595, 218);
            this.txtGiaVe.MaxLength = 32767;
            this.txtGiaVe.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtGiaVe.Modified = false;
            this.txtGiaVe.Multiline = false;
            this.txtGiaVe.Name = "txtGiaVe";
            stateProperties1.BorderColor = System.Drawing.SystemColors.Window;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaVe.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtGiaVe.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaVe.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.SystemColors.Window;
            stateProperties4.FillColor = System.Drawing.SystemColors.Window;
            stateProperties4.ForeColor = System.Drawing.Color.Black;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaVe.OnIdleState = stateProperties4;
            this.txtGiaVe.Padding = new System.Windows.Forms.Padding(3);
            this.txtGiaVe.PasswordChar = '\0';
            this.txtGiaVe.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtGiaVe.PlaceholderText = "";
            this.txtGiaVe.ReadOnly = false;
            this.txtGiaVe.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGiaVe.SelectedText = "";
            this.txtGiaVe.SelectionLength = 0;
            this.txtGiaVe.SelectionStart = 0;
            this.txtGiaVe.ShortcutsEnabled = true;
            this.txtGiaVe.Size = new System.Drawing.Size(187, 52);
            this.txtGiaVe.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtGiaVe.TabIndex = 40;
            this.txtGiaVe.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGiaVe.TextMarginBottom = 0;
            this.txtGiaVe.TextMarginLeft = 3;
            this.txtGiaVe.TextMarginTop = 0;
            this.txtGiaVe.TextPlaceholder = "";
            this.txtGiaVe.UseSystemPasswordChar = false;
            this.txtGiaVe.WordWrap = true;
            // 
            // dtpNgaySuatChieu
            // 
            this.dtpNgaySuatChieu.BackColor = System.Drawing.Color.Transparent;
            this.dtpNgaySuatChieu.BorderRadius = 1;
            this.dtpNgaySuatChieu.Color = System.Drawing.SystemColors.Window;
            this.dtpNgaySuatChieu.CustomFormat = "dd/MM/yyyyy";
            this.dtpNgaySuatChieu.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.dtpNgaySuatChieu.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.dtpNgaySuatChieu.DisabledColor = System.Drawing.SystemColors.Window;
            this.dtpNgaySuatChieu.DisplayWeekNumbers = false;
            this.dtpNgaySuatChieu.DPHeight = 0;
            this.dtpNgaySuatChieu.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpNgaySuatChieu.FillDatePicker = false;
            this.dtpNgaySuatChieu.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgaySuatChieu.ForeColor = System.Drawing.Color.Black;
            this.dtpNgaySuatChieu.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgaySuatChieu.Icon = ((System.Drawing.Image)(resources.GetObject("dtpNgaySuatChieu.Icon")));
            this.dtpNgaySuatChieu.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.dtpNgaySuatChieu.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.dtpNgaySuatChieu.LeftTextMargin = 5;
            this.dtpNgaySuatChieu.Location = new System.Drawing.Point(580, 113);
            this.dtpNgaySuatChieu.MinimumSize = new System.Drawing.Size(4, 32);
            this.dtpNgaySuatChieu.Name = "dtpNgaySuatChieu";
            this.dtpNgaySuatChieu.Size = new System.Drawing.Size(252, 39);
            this.dtpNgaySuatChieu.TabIndex = 38;
            this.dtpNgaySuatChieu.Value = new System.DateTime(2023, 11, 6, 22, 18, 0, 0);
            // 
            // ErrorMes
            // 
            this.ErrorMes.ContainerControl = this;
            // 
            // dtpGioSuatChieu
            // 
            this.dtpGioSuatChieu.CustomFormat = "HH:mm";
            this.dtpGioSuatChieu.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpGioSuatChieu.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpGioSuatChieu.Location = new System.Drawing.Point(27, 227);
            this.dtpGioSuatChieu.Name = "dtpGioSuatChieu";
            this.dtpGioSuatChieu.ShowUpDown = true;
            this.dtpGioSuatChieu.Size = new System.Drawing.Size(179, 39);
            this.dtpGioSuatChieu.TabIndex = 43;
            this.dtpGioSuatChieu.Validating += new System.ComponentModel.CancelEventHandler(this.dtpGioSuatChieu_Validating);
            // 
            // ThemSuatChieu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(846, 637);
            this.Controls.Add(this.dtpGioSuatChieu);
            this.Controls.Add(this.cboPhongChieu);
            this.Controls.Add(this.cboTenPhim);
            this.Controls.Add(this.txtGiaVe);
            this.Controls.Add(this.panel_ChuThich);
            this.Controls.Add(this.dtpNgaySuatChieu);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btn_luuPhim);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThemSuatChieu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThemSuatChieu";
            this.Load += new System.EventHandler(this.ThemSuatChieu_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Login_MouseDown);
            this.panel9.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel_ChuThich.ResumeLayout(false);
            this.panel_ChuThich.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorMes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CustomControls.RJControls.RJButton btn_luuPhim;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private Bunifu.UI.WinForms.BunifuDatePicker dtpNgaySuatChieu;
        private Bunifu.UI.WinForms.BunifuShadowPanel panel_ChuThich;
        private Bunifu.UI.WinForms.BunifuDropdown cboTenPhim;
        private Bunifu.UI.WinForms.BunifuDropdown cboPhongChieu;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuTextBox txtGiaVe;
        private System.Windows.Forms.ErrorProvider ErrorMes;
        private System.Windows.Forms.DateTimePicker dtpGioSuatChieu;
        private Bunifu.UI.WinForms.BunifuLabel lblGiaVe;
        private Bunifu.UI.WinForms.BunifuLabel lblPhongChieu;
        private Bunifu.UI.WinForms.BunifuLabel lblGioChieu;
        private Bunifu.UI.WinForms.BunifuLabel lblNgayChieu;
        private Bunifu.UI.WinForms.BunifuLabel lblTenPhim;
    }
}