﻿namespace QL_RapChieuPhim.Views
{
    partial class Edit_KhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close_fixKhachHang = new System.Windows.Forms.Button();
            this.lbl_suaKhachHang = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_fixSoDTKH = new System.Windows.Forms.Label();
            this.lbl_fixGioiTinhKH = new System.Windows.Forms.Label();
            this.lbl_fixNgaySinhKH = new System.Windows.Forms.Label();
            this.dTP_fixNgaySinhKH = new System.Windows.Forms.DateTimePicker();
            this.txt_fixSoDTKH = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txt_fixHoTenKH = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbl_fixHoTenKH = new System.Windows.Forms.Label();
            this.txt_fixTKKH = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_fixTKKH = new System.Windows.Forms.Label();
            this.cB_fixGioiTinhKH = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_luuSuaKhachHang = new CustomControls.RJControls.RJButton();
            this.btn_huySuaKhachHang = new CustomControls.RJControls.RJButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_close_fixKhachHang);
            this.panel1.Controls.Add(this.lbl_suaKhachHang);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(667, 48);
            this.panel1.TabIndex = 0;
            // 
            // btn_close_fixKhachHang
            // 
            this.btn_close_fixKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_fixKhachHang.Location = new System.Drawing.Point(624, 9);
            this.btn_close_fixKhachHang.Name = "btn_close_fixKhachHang";
            this.btn_close_fixKhachHang.Size = new System.Drawing.Size(30, 30);
            this.btn_close_fixKhachHang.TabIndex = 45;
            this.btn_close_fixKhachHang.Text = "X";
            this.btn_close_fixKhachHang.UseVisualStyleBackColor = true;
            this.btn_close_fixKhachHang.Click += new System.EventHandler(this.btn_close_fixKhachHang_Click);
            // 
            // lbl_suaKhachHang
            // 
            this.lbl_suaKhachHang.AutoSize = true;
            this.lbl_suaKhachHang.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Bold);
            this.lbl_suaKhachHang.Location = new System.Drawing.Point(12, 9);
            this.lbl_suaKhachHang.Name = "lbl_suaKhachHang";
            this.lbl_suaKhachHang.Size = new System.Drawing.Size(375, 34);
            this.lbl_suaKhachHang.TabIndex = 3;
            this.lbl_suaKhachHang.Text = "Sửa thông tin khách hàng";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_luuSuaKhachHang);
            this.panel2.Controls.Add(this.btn_huySuaKhachHang);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 369);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(667, 60);
            this.panel2.TabIndex = 1;
            // 
            // lbl_fixSoDTKH
            // 
            this.lbl_fixSoDTKH.AutoSize = true;
            this.lbl_fixSoDTKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixSoDTKH.Location = new System.Drawing.Point(133, 299);
            this.lbl_fixSoDTKH.Name = "lbl_fixSoDTKH";
            this.lbl_fixSoDTKH.Size = new System.Drawing.Size(141, 24);
            this.lbl_fixSoDTKH.TabIndex = 56;
            this.lbl_fixSoDTKH.Text = "Số điện thoại:";
            // 
            // lbl_fixGioiTinhKH
            // 
            this.lbl_fixGioiTinhKH.AutoSize = true;
            this.lbl_fixGioiTinhKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixGioiTinhKH.Location = new System.Drawing.Point(48, 185);
            this.lbl_fixGioiTinhKH.Name = "lbl_fixGioiTinhKH";
            this.lbl_fixGioiTinhKH.Size = new System.Drawing.Size(100, 24);
            this.lbl_fixGioiTinhKH.TabIndex = 57;
            this.lbl_fixGioiTinhKH.Text = "Giới tính:";
            // 
            // lbl_fixNgaySinhKH
            // 
            this.lbl_fixNgaySinhKH.AutoSize = true;
            this.lbl_fixNgaySinhKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixNgaySinhKH.Location = new System.Drawing.Point(332, 190);
            this.lbl_fixNgaySinhKH.Name = "lbl_fixNgaySinhKH";
            this.lbl_fixNgaySinhKH.Size = new System.Drawing.Size(111, 24);
            this.lbl_fixNgaySinhKH.TabIndex = 55;
            this.lbl_fixNgaySinhKH.Text = "Ngày sinh:";
            // 
            // dTP_fixNgaySinhKH
            // 
            this.dTP_fixNgaySinhKH.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP_fixNgaySinhKH.Location = new System.Drawing.Point(336, 220);
            this.dTP_fixNgaySinhKH.Name = "dTP_fixNgaySinhKH";
            this.dTP_fixNgaySinhKH.Size = new System.Drawing.Size(150, 22);
            this.dTP_fixNgaySinhKH.TabIndex = 62;
            this.dTP_fixNgaySinhKH.ValueChanged += new System.EventHandler(this.dTP_fixNgaySinhKH_ValueChanged);
            // 
            // txt_fixSoDTKH
            // 
            this.txt_fixSoDTKH.BackColor = System.Drawing.Color.White;
            this.txt_fixSoDTKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixSoDTKH.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixSoDTKH.Location = new System.Drawing.Point(309, 300);
            this.txt_fixSoDTKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixSoDTKH.Multiline = true;
            this.txt_fixSoDTKH.Name = "txt_fixSoDTKH";
            this.txt_fixSoDTKH.Size = new System.Drawing.Size(211, 30);
            this.txt_fixSoDTKH.TabIndex = 61;
            this.txt_fixSoDTKH.UseSystemPasswordChar = true;
            this.txt_fixSoDTKH.TextChanged += new System.EventHandler(this.txt_fixSoDTKH_TextChanged);
            this.txt_fixSoDTKH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_fixSoDTKH_KeyPress);
            this.txt_fixSoDTKH.Validating += new System.ComponentModel.CancelEventHandler(this.txt_fixSoDTKH_Validating);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(309, 333);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(211, 1);
            this.panel8.TabIndex = 60;
            // 
            // txt_fixHoTenKH
            // 
            this.txt_fixHoTenKH.BackColor = System.Drawing.Color.White;
            this.txt_fixHoTenKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixHoTenKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixHoTenKH.Location = new System.Drawing.Point(336, 122);
            this.txt_fixHoTenKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixHoTenKH.Multiline = true;
            this.txt_fixHoTenKH.Name = "txt_fixHoTenKH";
            this.txt_fixHoTenKH.Size = new System.Drawing.Size(301, 30);
            this.txt_fixHoTenKH.TabIndex = 54;
            this.txt_fixHoTenKH.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(336, 155);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(301, 1);
            this.panel5.TabIndex = 53;
            // 
            // lbl_fixHoTenKH
            // 
            this.lbl_fixHoTenKH.AutoSize = true;
            this.lbl_fixHoTenKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixHoTenKH.Location = new System.Drawing.Point(332, 84);
            this.lbl_fixHoTenKH.Name = "lbl_fixHoTenKH";
            this.lbl_fixHoTenKH.Size = new System.Drawing.Size(107, 24);
            this.lbl_fixHoTenKH.TabIndex = 52;
            this.lbl_fixHoTenKH.Text = "Họ và tên:";
            // 
            // txt_fixTKKH
            // 
            this.txt_fixTKKH.BackColor = System.Drawing.Color.White;
            this.txt_fixTKKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixTKKH.Enabled = false;
            this.txt_fixTKKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixTKKH.Location = new System.Drawing.Point(52, 122);
            this.txt_fixTKKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixTKKH.Multiline = true;
            this.txt_fixTKKH.Name = "txt_fixTKKH";
            this.txt_fixTKKH.Size = new System.Drawing.Size(150, 30);
            this.txt_fixTKKH.TabIndex = 51;
            this.txt_fixTKKH.UseSystemPasswordChar = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(52, 155);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(150, 1);
            this.panel4.TabIndex = 50;
            // 
            // lbl_fixTKKH
            // 
            this.lbl_fixTKKH.AutoSize = true;
            this.lbl_fixTKKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixTKKH.Location = new System.Drawing.Point(48, 84);
            this.lbl_fixTKKH.Name = "lbl_fixTKKH";
            this.lbl_fixTKKH.Size = new System.Drawing.Size(161, 24);
            this.lbl_fixTKKH.TabIndex = 49;
            this.lbl_fixTKKH.Text = "Mã khách hàng:";
            // 
            // cB_fixGioiTinhKH
            // 
            this.cB_fixGioiTinhKH.FormattingEnabled = true;
            this.cB_fixGioiTinhKH.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cB_fixGioiTinhKH.Location = new System.Drawing.Point(52, 222);
            this.cB_fixGioiTinhKH.Name = "cB_fixGioiTinhKH";
            this.cB_fixGioiTinhKH.Size = new System.Drawing.Size(150, 24);
            this.cB_fixGioiTinhKH.TabIndex = 63;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(52, 253);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(150, 1);
            this.panel3.TabIndex = 64;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(336, 253);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(152, 1);
            this.panel6.TabIndex = 65;
            // 
            // btn_luuSuaKhachHang
            // 
            this.btn_luuSuaKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuSuaKhachHang.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuSuaKhachHang.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_luuSuaKhachHang.BorderRadius = 16;
            this.btn_luuSuaKhachHang.BorderSize = 0;
            this.btn_luuSuaKhachHang.FlatAppearance.BorderSize = 0;
            this.btn_luuSuaKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_luuSuaKhachHang.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luuSuaKhachHang.ForeColor = System.Drawing.Color.White;
            this.btn_luuSuaKhachHang.Location = new System.Drawing.Point(531, 8);
            this.btn_luuSuaKhachHang.Name = "btn_luuSuaKhachHang";
            this.btn_luuSuaKhachHang.Size = new System.Drawing.Size(106, 40);
            this.btn_luuSuaKhachHang.TabIndex = 12;
            this.btn_luuSuaKhachHang.Text = "Lưu";
            this.btn_luuSuaKhachHang.TextColor = System.Drawing.Color.White;
            this.btn_luuSuaKhachHang.UseVisualStyleBackColor = false;
            this.btn_luuSuaKhachHang.Click += new System.EventHandler(this.btn_luuSuaKhachHang_Click);
            // 
            // btn_huySuaKhachHang
            // 
            this.btn_huySuaKhachHang.BackColor = System.Drawing.Color.Red;
            this.btn_huySuaKhachHang.BackgroundColor = System.Drawing.Color.Red;
            this.btn_huySuaKhachHang.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_huySuaKhachHang.BorderRadius = 16;
            this.btn_huySuaKhachHang.BorderSize = 0;
            this.btn_huySuaKhachHang.FlatAppearance.BorderSize = 0;
            this.btn_huySuaKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_huySuaKhachHang.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_huySuaKhachHang.ForeColor = System.Drawing.Color.White;
            this.btn_huySuaKhachHang.Location = new System.Drawing.Point(348, 8);
            this.btn_huySuaKhachHang.Name = "btn_huySuaKhachHang";
            this.btn_huySuaKhachHang.Size = new System.Drawing.Size(106, 40);
            this.btn_huySuaKhachHang.TabIndex = 13;
            this.btn_huySuaKhachHang.Text = "Hủy";
            this.btn_huySuaKhachHang.TextColor = System.Drawing.Color.White;
            this.btn_huySuaKhachHang.UseVisualStyleBackColor = false;
            this.btn_huySuaKhachHang.Click += new System.EventHandler(this.btn_huySuaKhachHang_Click);
            // 
            // Edit_KhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(667, 429);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbl_fixSoDTKH);
            this.Controls.Add(this.cB_fixGioiTinhKH);
            this.Controls.Add(this.dTP_fixNgaySinhKH);
            this.Controls.Add(this.lbl_fixNgaySinhKH);
            this.Controls.Add(this.lbl_fixHoTenKH);
            this.Controls.Add(this.lbl_fixGioiTinhKH);
            this.Controls.Add(this.txt_fixSoDTKH);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.txt_fixHoTenKH);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.txt_fixTKKH);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lbl_fixTKKH);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Edit_KhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit_KhachHang";
            this.Load += new System.EventHandler(this.Edit_KhachHang_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_suaKhachHang;
        private System.Windows.Forms.Button btn_close_fixKhachHang;
        private System.Windows.Forms.Panel panel2;
        private CustomControls.RJControls.RJButton btn_luuSuaKhachHang;
        private CustomControls.RJControls.RJButton btn_huySuaKhachHang;
        private System.Windows.Forms.DateTimePicker dTP_fixNgaySinhKH;
        private System.Windows.Forms.TextBox txt_fixSoDTKH;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbl_fixGioiTinhKH;
        private System.Windows.Forms.Label lbl_fixSoDTKH;
        private System.Windows.Forms.Label lbl_fixNgaySinhKH;
        private System.Windows.Forms.TextBox txt_fixHoTenKH;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_fixHoTenKH;
        private System.Windows.Forms.TextBox txt_fixTKKH;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_fixTKKH;
        private System.Windows.Forms.ComboBox cB_fixGioiTinhKH;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
    }
}