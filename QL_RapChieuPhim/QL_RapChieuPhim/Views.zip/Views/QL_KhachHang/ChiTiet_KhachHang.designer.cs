﻿namespace QL_RapChieuPhim.Views
{
    partial class ChiTiet_KhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close_chiTietKhachHang = new System.Windows.Forms.Button();
            this.lbl_chiTietKhachHang = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dTP_chiTietNgaySinhKH = new System.Windows.Forms.DateTimePicker();
            this.txt_chiTietSoDTKH = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txt_chiTietGioiTinhKH = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_chiTietHoTenKH = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txt_chiTietTKKH = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_chiTietSoDTKH = new System.Windows.Forms.Label();
            this.lbl_chiTietNgaySinhKH = new System.Windows.Forms.Label();
            this.lbl_chiTietGioiTinhKH = new System.Windows.Forms.Label();
            this.lbl_chiTietHoTenKH = new System.Windows.Forms.Label();
            this.lbl_chiTietTKKH = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_close_chiTietKhachHang);
            this.panel1.Controls.Add(this.lbl_chiTietKhachHang);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(690, 48);
            this.panel1.TabIndex = 0;
            // 
            // btn_close_chiTietKhachHang
            // 
            this.btn_close_chiTietKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_chiTietKhachHang.Location = new System.Drawing.Point(648, 9);
            this.btn_close_chiTietKhachHang.Name = "btn_close_chiTietKhachHang";
            this.btn_close_chiTietKhachHang.Size = new System.Drawing.Size(30, 30);
            this.btn_close_chiTietKhachHang.TabIndex = 46;
            this.btn_close_chiTietKhachHang.Text = "X";
            this.btn_close_chiTietKhachHang.UseVisualStyleBackColor = true;
            this.btn_close_chiTietKhachHang.Click += new System.EventHandler(this.btn_close_chiTietKhachHang_Click);
            // 
            // lbl_chiTietKhachHang
            // 
            this.lbl_chiTietKhachHang.AutoSize = true;
            this.lbl_chiTietKhachHang.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Bold);
            this.lbl_chiTietKhachHang.Location = new System.Drawing.Point(12, 9);
            this.lbl_chiTietKhachHang.Name = "lbl_chiTietKhachHang";
            this.lbl_chiTietKhachHang.Size = new System.Drawing.Size(418, 34);
            this.lbl_chiTietKhachHang.TabIndex = 4;
            this.lbl_chiTietKhachHang.Text = "Chi tiết thông tin khách hàng";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.dTP_chiTietNgaySinhKH);
            this.panel2.Controls.Add(this.txt_chiTietSoDTKH);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.txt_chiTietGioiTinhKH);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.txt_chiTietHoTenKH);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.txt_chiTietTKKH);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lbl_chiTietSoDTKH);
            this.panel2.Controls.Add(this.lbl_chiTietNgaySinhKH);
            this.panel2.Controls.Add(this.lbl_chiTietGioiTinhKH);
            this.panel2.Controls.Add(this.lbl_chiTietHoTenKH);
            this.panel2.Controls.Add(this.lbl_chiTietTKKH);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(690, 264);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(433, 226);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(123, 1);
            this.panel3.TabIndex = 84;
            // 
            // dTP_chiTietNgaySinhKH
            // 
            this.dTP_chiTietNgaySinhKH.Enabled = false;
            this.dTP_chiTietNgaySinhKH.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTP_chiTietNgaySinhKH.Location = new System.Drawing.Point(433, 193);
            this.dTP_chiTietNgaySinhKH.Name = "dTP_chiTietNgaySinhKH";
            this.dTP_chiTietNgaySinhKH.Size = new System.Drawing.Size(122, 22);
            this.dTP_chiTietNgaySinhKH.TabIndex = 83;
            // 
            // txt_chiTietSoDTKH
            // 
            this.txt_chiTietSoDTKH.BackColor = System.Drawing.Color.White;
            this.txt_chiTietSoDTKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietSoDTKH.Enabled = false;
            this.txt_chiTietSoDTKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietSoDTKH.Location = new System.Drawing.Point(125, 192);
            this.txt_chiTietSoDTKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietSoDTKH.Multiline = true;
            this.txt_chiTietSoDTKH.Name = "txt_chiTietSoDTKH";
            this.txt_chiTietSoDTKH.Size = new System.Drawing.Size(176, 30);
            this.txt_chiTietSoDTKH.TabIndex = 82;
            this.txt_chiTietSoDTKH.UseSystemPasswordChar = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(125, 225);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(176, 1);
            this.panel7.TabIndex = 81;
            // 
            // txt_chiTietGioiTinhKH
            // 
            this.txt_chiTietGioiTinhKH.BackColor = System.Drawing.Color.White;
            this.txt_chiTietGioiTinhKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietGioiTinhKH.Enabled = false;
            this.txt_chiTietGioiTinhKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietGioiTinhKH.Location = new System.Drawing.Point(535, 77);
            this.txt_chiTietGioiTinhKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietGioiTinhKH.Multiline = true;
            this.txt_chiTietGioiTinhKH.Name = "txt_chiTietGioiTinhKH";
            this.txt_chiTietGioiTinhKH.Size = new System.Drawing.Size(123, 30);
            this.txt_chiTietGioiTinhKH.TabIndex = 80;
            this.txt_chiTietGioiTinhKH.UseSystemPasswordChar = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(535, 110);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(123, 1);
            this.panel6.TabIndex = 79;
            // 
            // txt_chiTietHoTenKH
            // 
            this.txt_chiTietHoTenKH.BackColor = System.Drawing.Color.White;
            this.txt_chiTietHoTenKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietHoTenKH.Enabled = false;
            this.txt_chiTietHoTenKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietHoTenKH.Location = new System.Drawing.Point(249, 77);
            this.txt_chiTietHoTenKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietHoTenKH.Multiline = true;
            this.txt_chiTietHoTenKH.Name = "txt_chiTietHoTenKH";
            this.txt_chiTietHoTenKH.Size = new System.Drawing.Size(239, 30);
            this.txt_chiTietHoTenKH.TabIndex = 78;
            this.txt_chiTietHoTenKH.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(249, 110);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(239, 1);
            this.panel5.TabIndex = 77;
            // 
            // txt_chiTietTKKH
            // 
            this.txt_chiTietTKKH.BackColor = System.Drawing.Color.White;
            this.txt_chiTietTKKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietTKKH.Enabled = false;
            this.txt_chiTietTKKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietTKKH.Location = new System.Drawing.Point(37, 77);
            this.txt_chiTietTKKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietTKKH.Multiline = true;
            this.txt_chiTietTKKH.Name = "txt_chiTietTKKH";
            this.txt_chiTietTKKH.Size = new System.Drawing.Size(172, 30);
            this.txt_chiTietTKKH.TabIndex = 76;
            this.txt_chiTietTKKH.UseSystemPasswordChar = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(37, 110);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(172, 1);
            this.panel4.TabIndex = 75;
            // 
            // lbl_chiTietSoDTKH
            // 
            this.lbl_chiTietSoDTKH.AutoSize = true;
            this.lbl_chiTietSoDTKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietSoDTKH.Location = new System.Drawing.Point(121, 152);
            this.lbl_chiTietSoDTKH.Name = "lbl_chiTietSoDTKH";
            this.lbl_chiTietSoDTKH.Size = new System.Drawing.Size(141, 24);
            this.lbl_chiTietSoDTKH.TabIndex = 74;
            this.lbl_chiTietSoDTKH.Text = "Số điện thoại:";
            // 
            // lbl_chiTietNgaySinhKH
            // 
            this.lbl_chiTietNgaySinhKH.AutoSize = true;
            this.lbl_chiTietNgaySinhKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietNgaySinhKH.Location = new System.Drawing.Point(429, 152);
            this.lbl_chiTietNgaySinhKH.Name = "lbl_chiTietNgaySinhKH";
            this.lbl_chiTietNgaySinhKH.Size = new System.Drawing.Size(111, 24);
            this.lbl_chiTietNgaySinhKH.TabIndex = 73;
            this.lbl_chiTietNgaySinhKH.Text = "Ngày sinh:";
            // 
            // lbl_chiTietGioiTinhKH
            // 
            this.lbl_chiTietGioiTinhKH.AutoSize = true;
            this.lbl_chiTietGioiTinhKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietGioiTinhKH.Location = new System.Drawing.Point(531, 33);
            this.lbl_chiTietGioiTinhKH.Name = "lbl_chiTietGioiTinhKH";
            this.lbl_chiTietGioiTinhKH.Size = new System.Drawing.Size(100, 24);
            this.lbl_chiTietGioiTinhKH.TabIndex = 72;
            this.lbl_chiTietGioiTinhKH.Text = "Giới tính:";
            // 
            // lbl_chiTietHoTenKH
            // 
            this.lbl_chiTietHoTenKH.AutoSize = true;
            this.lbl_chiTietHoTenKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietHoTenKH.Location = new System.Drawing.Point(245, 33);
            this.lbl_chiTietHoTenKH.Name = "lbl_chiTietHoTenKH";
            this.lbl_chiTietHoTenKH.Size = new System.Drawing.Size(107, 24);
            this.lbl_chiTietHoTenKH.TabIndex = 71;
            this.lbl_chiTietHoTenKH.Text = "Họ và tên:";
            // 
            // lbl_chiTietTKKH
            // 
            this.lbl_chiTietTKKH.AutoSize = true;
            this.lbl_chiTietTKKH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietTKKH.Location = new System.Drawing.Point(33, 33);
            this.lbl_chiTietTKKH.Name = "lbl_chiTietTKKH";
            this.lbl_chiTietTKKH.Size = new System.Drawing.Size(161, 24);
            this.lbl_chiTietTKKH.TabIndex = 70;
            this.lbl_chiTietTKKH.Text = "Mã khách hàng:";
            // 
            // ChiTiet_KhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(690, 312);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChiTiet_KhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChiTiet_KhachHang";
            this.Load += new System.EventHandler(this.ChiTiet_KhachHang_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_chiTietKhachHang;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_close_chiTietKhachHang;
        private System.Windows.Forms.TextBox txt_chiTietSoDTKH;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txt_chiTietGioiTinhKH;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_chiTietHoTenKH;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txt_chiTietTKKH;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_chiTietSoDTKH;
        private System.Windows.Forms.Label lbl_chiTietNgaySinhKH;
        private System.Windows.Forms.Label lbl_chiTietGioiTinhKH;
        private System.Windows.Forms.Label lbl_chiTietHoTenKH;
        private System.Windows.Forms.Label lbl_chiTietTKKH;
        private System.Windows.Forms.DateTimePicker dTP_chiTietNgaySinhKH;
        private System.Windows.Forms.Panel panel3;
    } 
    }