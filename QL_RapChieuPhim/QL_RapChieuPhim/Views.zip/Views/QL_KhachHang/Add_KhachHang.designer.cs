﻿namespace QL_RapChieuPhim.Views
{
    partial class Add_KhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close_addKhachHang = new System.Windows.Forms.Button();
            this.lbl_themKhachHang = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_huyLuuKhachHang = new CustomControls.RJControls.RJButton();
            this.btn_luuKhachHang = new CustomControls.RJControls.RJButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dTP_addNgaySinhKH = new System.Windows.Forms.DateTimePicker();
            this.txt_addSoDTKH = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txt_addGioiTinhKH = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbl_addGioiTinhKH = new System.Windows.Forms.Label();
            this.lbl_addSoDTKH = new System.Windows.Forms.Label();
            this.lbl_addNgaySinhKH = new System.Windows.Forms.Label();
            this.txt_addHoTenKH = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbl_addHoTenKH = new System.Windows.Forms.Label();
            this.txt_addTKKH = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_addTKKH = new System.Windows.Forms.Label();
            this.lbl_thongTinKH = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_close_addKhachHang);
            this.panel1.Controls.Add(this.lbl_themKhachHang);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(828, 48);
            this.panel1.TabIndex = 0;
            // 
            // btn_close_addKhachHang
            // 
            this.btn_close_addKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_addKhachHang.Location = new System.Drawing.Point(777, 9);
            this.btn_close_addKhachHang.Name = "btn_close_addKhachHang";
            this.btn_close_addKhachHang.Size = new System.Drawing.Size(30, 30);
            this.btn_close_addKhachHang.TabIndex = 20;
            this.btn_close_addKhachHang.Text = "X";
            this.btn_close_addKhachHang.UseVisualStyleBackColor = true;
            this.btn_close_addKhachHang.Click += new System.EventHandler(this.btn_close_addKhachHang_Click);
            // 
            // lbl_themKhachHang
            // 
            this.lbl_themKhachHang.AutoSize = true;
            this.lbl_themKhachHang.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Bold);
            this.lbl_themKhachHang.Location = new System.Drawing.Point(12, 9);
            this.lbl_themKhachHang.Name = "lbl_themKhachHang";
            this.lbl_themKhachHang.Size = new System.Drawing.Size(263, 34);
            this.lbl_themKhachHang.TabIndex = 1;
            this.lbl_themKhachHang.Text = "Thêm khách hàng";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_huyLuuKhachHang);
            this.panel2.Controls.Add(this.btn_luuKhachHang);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 453);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(828, 58);
            this.panel2.TabIndex = 1;
            // 
            // btn_huyLuuKhachHang
            // 
            this.btn_huyLuuKhachHang.BackColor = System.Drawing.Color.Red;
            this.btn_huyLuuKhachHang.BackgroundColor = System.Drawing.Color.Red;
            this.btn_huyLuuKhachHang.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_huyLuuKhachHang.BorderRadius = 16;
            this.btn_huyLuuKhachHang.BorderSize = 0;
            this.btn_huyLuuKhachHang.FlatAppearance.BorderSize = 0;
            this.btn_huyLuuKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_huyLuuKhachHang.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_huyLuuKhachHang.ForeColor = System.Drawing.Color.White;
            this.btn_huyLuuKhachHang.Location = new System.Drawing.Point(533, 6);
            this.btn_huyLuuKhachHang.Name = "btn_huyLuuKhachHang";
            this.btn_huyLuuKhachHang.Size = new System.Drawing.Size(106, 40);
            this.btn_huyLuuKhachHang.TabIndex = 12;
            this.btn_huyLuuKhachHang.Text = "Hủy";
            this.btn_huyLuuKhachHang.TextColor = System.Drawing.Color.White;
            this.btn_huyLuuKhachHang.UseVisualStyleBackColor = false;
            this.btn_huyLuuKhachHang.Click += new System.EventHandler(this.btn_huyLuuKhachHang_Click);
            // 
            // btn_luuKhachHang
            // 
            this.btn_luuKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuKhachHang.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuKhachHang.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_luuKhachHang.BorderRadius = 16;
            this.btn_luuKhachHang.BorderSize = 0;
            this.btn_luuKhachHang.FlatAppearance.BorderSize = 0;
            this.btn_luuKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_luuKhachHang.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luuKhachHang.ForeColor = System.Drawing.Color.White;
            this.btn_luuKhachHang.Location = new System.Drawing.Point(701, 6);
            this.btn_luuKhachHang.Name = "btn_luuKhachHang";
            this.btn_luuKhachHang.Size = new System.Drawing.Size(106, 40);
            this.btn_luuKhachHang.TabIndex = 11;
            this.btn_luuKhachHang.Text = "Lưu";
            this.btn_luuKhachHang.TextColor = System.Drawing.Color.White;
            this.btn_luuKhachHang.UseVisualStyleBackColor = false;
            this.btn_luuKhachHang.Click += new System.EventHandler(this.btn_luuKhachHang_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dTP_addNgaySinhKH);
            this.panel3.Controls.Add(this.txt_addSoDTKH);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.txt_addGioiTinhKH);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.lbl_addGioiTinhKH);
            this.panel3.Controls.Add(this.lbl_addSoDTKH);
            this.panel3.Controls.Add(this.lbl_addNgaySinhKH);
            this.panel3.Controls.Add(this.txt_addHoTenKH);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.lbl_addHoTenKH);
            this.panel3.Controls.Add(this.txt_addTKKH);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.lbl_addTKKH);
            this.panel3.Controls.Add(this.lbl_thongTinKH);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 48);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(828, 405);
            this.panel3.TabIndex = 2;
            // 
            // dTP_addNgaySinhKH
            // 
            this.dTP_addNgaySinhKH.Location = new System.Drawing.Point(310, 262);
            this.dTP_addNgaySinhKH.Name = "dTP_addNgaySinhKH";
            this.dTP_addNgaySinhKH.Size = new System.Drawing.Size(480, 22);
            this.dTP_addNgaySinhKH.TabIndex = 48;
            // 
            // txt_addSoDTKH
            // 
            this.txt_addSoDTKH.BackColor = System.Drawing.Color.White;
            this.txt_addSoDTKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_addSoDTKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addSoDTKH.Location = new System.Drawing.Point(310, 313);
            this.txt_addSoDTKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_addSoDTKH.Multiline = true;
            this.txt_addSoDTKH.Name = "txt_addSoDTKH";
            this.txt_addSoDTKH.Size = new System.Drawing.Size(480, 30);
            this.txt_addSoDTKH.TabIndex = 46;
            this.txt_addSoDTKH.UseSystemPasswordChar = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(310, 346);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(480, 1);
            this.panel8.TabIndex = 45;
            // 
            // txt_addGioiTinhKH
            // 
            this.txt_addGioiTinhKH.BackColor = System.Drawing.Color.White;
            this.txt_addGioiTinhKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_addGioiTinhKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addGioiTinhKH.Location = new System.Drawing.Point(310, 203);
            this.txt_addGioiTinhKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_addGioiTinhKH.Multiline = true;
            this.txt_addGioiTinhKH.Name = "txt_addGioiTinhKH";
            this.txt_addGioiTinhKH.Size = new System.Drawing.Size(480, 30);
            this.txt_addGioiTinhKH.TabIndex = 44;
            this.txt_addGioiTinhKH.UseSystemPasswordChar = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(310, 236);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(480, 1);
            this.panel6.TabIndex = 43;
            // 
            // lbl_addGioiTinhKH
            // 
            this.lbl_addGioiTinhKH.AutoSize = true;
            this.lbl_addGioiTinhKH.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addGioiTinhKH.Location = new System.Drawing.Point(58, 206);
            this.lbl_addGioiTinhKH.Name = "lbl_addGioiTinhKH";
            this.lbl_addGioiTinhKH.Size = new System.Drawing.Size(83, 19);
            this.lbl_addGioiTinhKH.TabIndex = 42;
            this.lbl_addGioiTinhKH.Text = "Giới tính:";
            // 
            // lbl_addSoDTKH
            // 
            this.lbl_addSoDTKH.AutoSize = true;
            this.lbl_addSoDTKH.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addSoDTKH.Location = new System.Drawing.Point(58, 316);
            this.lbl_addSoDTKH.Name = "lbl_addSoDTKH";
            this.lbl_addSoDTKH.Size = new System.Drawing.Size(118, 19);
            this.lbl_addSoDTKH.TabIndex = 41;
            this.lbl_addSoDTKH.Text = "Số điện thoại:";
            // 
            // lbl_addNgaySinhKH
            // 
            this.lbl_addNgaySinhKH.AutoSize = true;
            this.lbl_addNgaySinhKH.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addNgaySinhKH.Location = new System.Drawing.Point(58, 261);
            this.lbl_addNgaySinhKH.Name = "lbl_addNgaySinhKH";
            this.lbl_addNgaySinhKH.Size = new System.Drawing.Size(93, 19);
            this.lbl_addNgaySinhKH.TabIndex = 40;
            this.lbl_addNgaySinhKH.Text = "Ngày sinh:";
            // 
            // txt_addHoTenKH
            // 
            this.txt_addHoTenKH.BackColor = System.Drawing.Color.White;
            this.txt_addHoTenKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_addHoTenKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addHoTenKH.Location = new System.Drawing.Point(310, 148);
            this.txt_addHoTenKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_addHoTenKH.Multiline = true;
            this.txt_addHoTenKH.Name = "txt_addHoTenKH";
            this.txt_addHoTenKH.Size = new System.Drawing.Size(480, 30);
            this.txt_addHoTenKH.TabIndex = 39;
            this.txt_addHoTenKH.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(310, 181);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(480, 1);
            this.panel5.TabIndex = 38;
            // 
            // lbl_addHoTenKH
            // 
            this.lbl_addHoTenKH.AutoSize = true;
            this.lbl_addHoTenKH.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addHoTenKH.Location = new System.Drawing.Point(58, 151);
            this.lbl_addHoTenKH.Name = "lbl_addHoTenKH";
            this.lbl_addHoTenKH.Size = new System.Drawing.Size(90, 19);
            this.lbl_addHoTenKH.TabIndex = 37;
            this.lbl_addHoTenKH.Text = "Họ và tên:";
            // 
            // txt_addTKKH
            // 
            this.txt_addTKKH.BackColor = System.Drawing.Color.White;
            this.txt_addTKKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_addTKKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addTKKH.Location = new System.Drawing.Point(310, 93);
            this.txt_addTKKH.Margin = new System.Windows.Forms.Padding(4);
            this.txt_addTKKH.Multiline = true;
            this.txt_addTKKH.Name = "txt_addTKKH";
            this.txt_addTKKH.Size = new System.Drawing.Size(480, 30);
            this.txt_addTKKH.TabIndex = 36;
            this.txt_addTKKH.UseSystemPasswordChar = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(310, 126);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(480, 1);
            this.panel4.TabIndex = 35;
            // 
            // lbl_addTKKH
            // 
            this.lbl_addTKKH.AutoSize = true;
            this.lbl_addTKKH.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addTKKH.Location = new System.Drawing.Point(58, 96);
            this.lbl_addTKKH.Name = "lbl_addTKKH";
            this.lbl_addTKKH.Size = new System.Drawing.Size(217, 19);
            this.lbl_addTKKH.TabIndex = 34;
            this.lbl_addTKKH.Text = "Tên tài khoản khách hàng:";
            // 
            // lbl_thongTinKH
            // 
            this.lbl_thongTinKH.AutoSize = true;
            this.lbl_thongTinKH.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_thongTinKH.Location = new System.Drawing.Point(30, 35);
            this.lbl_thongTinKH.Name = "lbl_thongTinKH";
            this.lbl_thongTinKH.Size = new System.Drawing.Size(204, 27);
            this.lbl_thongTinKH.TabIndex = 33;
            this.lbl_thongTinKH.Text = "Thông tin cơ bản";
            // 
            // Add_KhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(828, 511);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_KhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_KhachHang";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_themKhachHang;
        private System.Windows.Forms.Button btn_close_addKhachHang;
        private System.Windows.Forms.Panel panel2;
        private CustomControls.RJControls.RJButton btn_huyLuuKhachHang;
        private CustomControls.RJControls.RJButton btn_luuKhachHang;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DateTimePicker dTP_addNgaySinhKH;
        private System.Windows.Forms.TextBox txt_addSoDTKH;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_addGioiTinhKH;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl_addGioiTinhKH;
        private System.Windows.Forms.Label lbl_addSoDTKH;
        private System.Windows.Forms.Label lbl_addNgaySinhKH;
        private System.Windows.Forms.TextBox txt_addHoTenKH;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_addHoTenKH;
        private System.Windows.Forms.TextBox txt_addTKKH;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_addTKKH;
        private System.Windows.Forms.Label lbl_thongTinKH;
    }
}