﻿namespace QL_RapChieuPhim.Views
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.imageList_movie = new System.Windows.Forms.ImageList(this.components);
            this.timer_transfer = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.image_slider = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.btn_DangNhap = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txt_MatKhau = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txt_TaiKhoan = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.PictureBox();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.image_slider)).BeginInit();
            this.panel2.SuspendLayout();
            this.bunifuShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList_movie
            // 
            this.imageList_movie.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList_movie.ImageStream")));
            this.imageList_movie.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList_movie.Images.SetKeyName(0, "61co1a-tY5S.jpg");
            this.imageList_movie.Images.SetKeyName(1, "61KYVvWl-LL._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(2, "71Lvqoov42L.jpg");
            this.imageList_movie.Images.SetKeyName(3, "71mXmB41psS._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(4, "81EuuG-54lL._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(5, "81hsswTfQXL._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(6, "81KWTMl0JUL._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(7, "81Xqgmj-4TL._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(8, "91zzAMkVCUL._AC_UF1000,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(9, "612ggeW50+L._AC_UF894,1000_QL80_.jpg");
            this.imageList_movie.Images.SetKeyName(10, "7118ecsxO3L.jpg");
            this.imageList_movie.Images.SetKeyName(11, "MV5BMDBmYTZjNjUtN2M1MS00MTQ2LTk2ODgtNzc2M2QyZGE5NTVjXkEyXkFqcGdeQXVyNzAwMjU2MTY@." +
        "_V1_.jpg");
            // 
            // timer_transfer
            // 
            this.timer_transfer.Enabled = true;
            this.timer_transfer.Interval = 2000;
            this.timer_transfer.Tick += new System.EventHandler(this.timer_transfer_Tick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.image_slider);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(373, 574);
            this.panel1.TabIndex = 0;
            // 
            // image_slider
            // 
            this.image_slider.Dock = System.Windows.Forms.DockStyle.Left;
            this.image_slider.Location = new System.Drawing.Point(0, 0);
            this.image_slider.Margin = new System.Windows.Forms.Padding(4);
            this.image_slider.Name = "image_slider";
            this.image_slider.Size = new System.Drawing.Size(373, 574);
            this.image_slider.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.image_slider.TabIndex = 0;
            this.image_slider.TabStop = false;
            this.image_slider.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Login_MouseDown);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.bunifuShadowPanel1);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.ForeColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(373, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(568, 574);
            this.panel2.TabIndex = 1;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Login_MouseDown);
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.DimGray;
            this.bunifuShadowPanel1.BorderRadius = 1;
            this.bunifuShadowPanel1.BorderThickness = 1;
            this.bunifuShadowPanel1.Controls.Add(this.btn_DangNhap);
            this.bunifuShadowPanel1.Controls.Add(this.txt_MatKhau);
            this.bunifuShadowPanel1.Controls.Add(this.txt_TaiKhoan);
            this.bunifuShadowPanel1.Controls.Add(this.label2);
            this.bunifuShadowPanel1.Controls.Add(this.panel6);
            this.bunifuShadowPanel1.Controls.Add(this.panel7);
            this.bunifuShadowPanel1.Controls.Add(this.pictureBox2);
            this.bunifuShadowPanel1.Controls.Add(this.pictureBox3);
            this.bunifuShadowPanel1.Controls.Add(this.label3);
            this.bunifuShadowPanel1.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel1.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(36, 48);
            this.bunifuShadowPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.bunifuShadowPanel1.PanelColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.bunifuShadowPanel1.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowDepth = 12;
            this.bunifuShadowPanel1.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(505, 490);
            this.bunifuShadowPanel1.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel1.TabIndex = 2;
            // 
            // btn_DangNhap
            // 
            this.btn_DangNhap.ActiveBorderThickness = 1;
            this.btn_DangNhap.ActiveCornerRadius = 20;
            this.btn_DangNhap.ActiveFillColor = System.Drawing.Color.Blue;
            this.btn_DangNhap.ActiveForecolor = System.Drawing.Color.White;
            this.btn_DangNhap.ActiveLineColor = System.Drawing.Color.Blue;
            this.btn_DangNhap.BackColor = System.Drawing.Color.Transparent;
            this.btn_DangNhap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_DangNhap.BackgroundImage")));
            this.btn_DangNhap.ButtonText = "Đăng nhập";
            this.btn_DangNhap.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.btn_DangNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.btn_DangNhap.ForeColor = System.Drawing.Color.White;
            this.btn_DangNhap.IdleBorderThickness = 1;
            this.btn_DangNhap.IdleCornerRadius = 20;
            this.btn_DangNhap.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_DangNhap.IdleForecolor = System.Drawing.Color.White;
            this.btn_DangNhap.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_DangNhap.Location = new System.Drawing.Point(200, 327);
            this.btn_DangNhap.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_DangNhap.Name = "btn_DangNhap";
            this.btn_DangNhap.Size = new System.Drawing.Size(122, 58);
            this.btn_DangNhap.TabIndex = 16;
            this.btn_DangNhap.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_DangNhap.UseWaitCursor = true;
            this.btn_DangNhap.Click += new System.EventHandler(this.btn_DangNhap_Click_1);
            // 
            // txt_MatKhau
            // 
            this.txt_MatKhau.AcceptsReturn = false;
            this.txt_MatKhau.AcceptsTab = false;
            this.txt_MatKhau.AnimationSpeed = 200;
            this.txt_MatKhau.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txt_MatKhau.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txt_MatKhau.BackColor = System.Drawing.Color.Transparent;
            this.txt_MatKhau.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txt_MatKhau.BackgroundImage")));
            this.txt_MatKhau.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txt_MatKhau.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txt_MatKhau.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txt_MatKhau.BorderColorIdle = System.Drawing.Color.Black;
            this.txt_MatKhau.BorderRadius = 1;
            this.txt_MatKhau.BorderThickness = 1;
            this.txt_MatKhau.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txt_MatKhau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MatKhau.DefaultFont = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_MatKhau.DefaultText = "";
            this.txt_MatKhau.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txt_MatKhau.ForeColor = System.Drawing.Color.LightGray;
            this.txt_MatKhau.HideSelection = true;
            this.txt_MatKhau.IconLeft = null;
            this.txt_MatKhau.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MatKhau.IconPadding = 10;
            this.txt_MatKhau.IconRight = null;
            this.txt_MatKhau.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_MatKhau.Lines = new string[0];
            this.txt_MatKhau.Location = new System.Drawing.Point(146, 238);
            this.txt_MatKhau.MaxLength = 32767;
            this.txt_MatKhau.MinimumSize = new System.Drawing.Size(1, 1);
            this.txt_MatKhau.Modified = false;
            this.txt_MatKhau.Multiline = false;
            this.txt_MatKhau.Name = "txt_MatKhau";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_MatKhau.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txt_MatKhau.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_MatKhau.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Black;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            stateProperties4.ForeColor = System.Drawing.Color.LightGray;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_MatKhau.OnIdleState = stateProperties4;
            this.txt_MatKhau.Padding = new System.Windows.Forms.Padding(3);
            this.txt_MatKhau.PasswordChar = '\0';
            this.txt_MatKhau.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txt_MatKhau.PlaceholderText = "Mật khẩu";
            this.txt_MatKhau.ReadOnly = false;
            this.txt_MatKhau.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_MatKhau.SelectedText = "";
            this.txt_MatKhau.SelectionLength = 0;
            this.txt_MatKhau.SelectionStart = 0;
            this.txt_MatKhau.ShortcutsEnabled = true;
            this.txt_MatKhau.Size = new System.Drawing.Size(273, 42);
            this.txt_MatKhau.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txt_MatKhau.TabIndex = 2;
            this.txt_MatKhau.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_MatKhau.TextMarginBottom = 0;
            this.txt_MatKhau.TextMarginLeft = 3;
            this.txt_MatKhau.TextMarginTop = 0;
            this.txt_MatKhau.TextPlaceholder = "Mật khẩu";
            this.txt_MatKhau.UseSystemPasswordChar = false;
            this.txt_MatKhau.WordWrap = true;
            this.txt_MatKhau.Enter += new System.EventHandler(this.txt_MatKhau_Enter);
            this.txt_MatKhau.Leave += new System.EventHandler(this.txt_MatKhau_Leave);
            // 
            // txt_TaiKhoan
            // 
            this.txt_TaiKhoan.AcceptsReturn = false;
            this.txt_TaiKhoan.AcceptsTab = false;
            this.txt_TaiKhoan.AnimationSpeed = 200;
            this.txt_TaiKhoan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txt_TaiKhoan.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txt_TaiKhoan.BackColor = System.Drawing.Color.Transparent;
            this.txt_TaiKhoan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txt_TaiKhoan.BackgroundImage")));
            this.txt_TaiKhoan.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txt_TaiKhoan.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txt_TaiKhoan.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txt_TaiKhoan.BorderColorIdle = System.Drawing.Color.Black;
            this.txt_TaiKhoan.BorderRadius = 1;
            this.txt_TaiKhoan.BorderThickness = 1;
            this.txt_TaiKhoan.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txt_TaiKhoan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TaiKhoan.DefaultFont = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_TaiKhoan.DefaultText = "";
            this.txt_TaiKhoan.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txt_TaiKhoan.ForeColor = System.Drawing.Color.LightGray;
            this.txt_TaiKhoan.HideSelection = true;
            this.txt_TaiKhoan.IconLeft = null;
            this.txt_TaiKhoan.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TaiKhoan.IconPadding = 10;
            this.txt_TaiKhoan.IconRight = null;
            this.txt_TaiKhoan.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_TaiKhoan.Lines = new string[0];
            this.txt_TaiKhoan.Location = new System.Drawing.Point(146, 169);
            this.txt_TaiKhoan.MaxLength = 32767;
            this.txt_TaiKhoan.MinimumSize = new System.Drawing.Size(1, 1);
            this.txt_TaiKhoan.Modified = false;
            this.txt_TaiKhoan.Multiline = false;
            this.txt_TaiKhoan.Name = "txt_TaiKhoan";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_TaiKhoan.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txt_TaiKhoan.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_TaiKhoan.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Black;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            stateProperties8.ForeColor = System.Drawing.Color.LightGray;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_TaiKhoan.OnIdleState = stateProperties8;
            this.txt_TaiKhoan.Padding = new System.Windows.Forms.Padding(3);
            this.txt_TaiKhoan.PasswordChar = '\0';
            this.txt_TaiKhoan.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txt_TaiKhoan.PlaceholderText = "Tài khoản";
            this.txt_TaiKhoan.ReadOnly = false;
            this.txt_TaiKhoan.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_TaiKhoan.SelectedText = "";
            this.txt_TaiKhoan.SelectionLength = 0;
            this.txt_TaiKhoan.SelectionStart = 0;
            this.txt_TaiKhoan.ShortcutsEnabled = true;
            this.txt_TaiKhoan.Size = new System.Drawing.Size(273, 42);
            this.txt_TaiKhoan.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txt_TaiKhoan.TabIndex = 1;
            this.txt_TaiKhoan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_TaiKhoan.TextMarginBottom = 0;
            this.txt_TaiKhoan.TextMarginLeft = 3;
            this.txt_TaiKhoan.TextMarginTop = 0;
            this.txt_TaiKhoan.TextPlaceholder = "Tài khoản";
            this.txt_TaiKhoan.UseSystemPasswordChar = false;
            this.txt_TaiKhoan.WordWrap = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(199, 413);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 18);
            this.label2.TabIndex = 13;
            this.label2.Text = "Quên mật khẩu?";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(106, 282);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(315, 1);
            this.panel6.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(106, 213);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(315, 1);
            this.panel7.TabIndex = 12;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QL_RapChieuPhim.Properties.Resources.user;
            this.pictureBox2.Location = new System.Drawing.Point(106, 175);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::QL_RapChieuPhim.Properties.Resources._lock;
            this.pictureBox3.Location = new System.Drawing.Point(106, 244);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 31);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(180, 64);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 51);
            this.label3.TabIndex = 8;
            this.label3.Text = "LOGIN";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.Image = global::QL_RapChieuPhim.Properties.Resources.close_icon2;
            this.btnClose.Location = new System.Drawing.Point(514, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(42, 29);
            this.btnClose.TabIndex = 1;
            this.btnClose.TabStop = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 574);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Login";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Login_KeyPress);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Login_MouseDown);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.image_slider)).EndInit();
            this.panel2.ResumeLayout(false);
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList_movie;
        private System.Windows.Forms.Timer timer_transfer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox image_slider;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox btnClose;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_DangNhap;
        private Bunifu.UI.WinForms.BunifuTextBox txt_MatKhau;
        private Bunifu.UI.WinForms.BunifuTextBox txt_TaiKhoan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label3;
    } 
}