﻿namespace QL_RapChieuPhim.Views
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_menu = new System.Windows.Forms.Panel();
            this.lbl_admin = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.slidebar_timer = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_tieude = new System.Windows.Forms.Label();
            this.panel_form = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox_menu = new System.Windows.Forms.PictureBox();
            this.ThongKe_DoanhSo = new System.Windows.Forms.Button();
            this.QL_khachHang = new System.Windows.Forms.Button();
            this.QL_NhanVien = new System.Windows.Forms.Button();
            this.btn_QLSanPham = new System.Windows.Forms.Button();
            this.btn_QLSuatChieu = new System.Windows.Forms.Button();
            this.btn_QLPhim = new System.Windows.Forms.Button();
            this.panel_menu.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_menu)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_menu
            // 
            this.panel_menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel_menu.Controls.Add(this.lbl_admin);
            this.panel_menu.Controls.Add(this.button2);
            this.panel_menu.Controls.Add(this.button1);
            this.panel_menu.Controls.Add(this.label1);
            this.panel_menu.Controls.Add(this.panel1);
            this.panel_menu.Controls.Add(this.pictureBox_menu);
            this.panel_menu.Controls.Add(this.ThongKe_DoanhSo);
            this.panel_menu.Controls.Add(this.QL_khachHang);
            this.panel_menu.Controls.Add(this.QL_NhanVien);
            this.panel_menu.Controls.Add(this.btn_QLSanPham);
            this.panel_menu.Controls.Add(this.btn_QLSuatChieu);
            this.panel_menu.Controls.Add(this.btn_QLPhim);
            this.panel_menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_menu.Location = new System.Drawing.Point(0, 0);
            this.panel_menu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_menu.MaximumSize = new System.Drawing.Size(224, 0);
            this.panel_menu.MinimumSize = new System.Drawing.Size(60, 511);
            this.panel_menu.Name = "panel_menu";
            this.panel_menu.Size = new System.Drawing.Size(224, 511);
            this.panel_menu.TabIndex = 0;
            this.panel_menu.Click += new System.EventHandler(this.panel_menu_Click);
            // 
            // lbl_admin
            // 
            this.lbl_admin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_admin.AutoSize = true;
            this.lbl_admin.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin.ForeColor = System.Drawing.Color.White;
            this.lbl_admin.Location = new System.Drawing.Point(50, 440);
            this.lbl_admin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_admin.Name = "lbl_admin";
            this.lbl_admin.Size = new System.Drawing.Size(0, 19);
            this.lbl_admin.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(58, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Menu";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(0, 470);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(224, 41);
            this.panel1.TabIndex = 1;
            // 
            // slidebar_timer
            // 
            this.slidebar_timer.Interval = 10;
            this.slidebar_timer.Tick += new System.EventHandler(this.slidebar_timer_Tick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.panel2.Controls.Add(this.lbl_tieude);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(224, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(798, 46);
            this.panel2.TabIndex = 1;
            // 
            // lbl_tieude
            // 
            this.lbl_tieude.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_tieude.AutoSize = true;
            this.lbl_tieude.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.lbl_tieude.ForeColor = System.Drawing.Color.White;
            this.lbl_tieude.Location = new System.Drawing.Point(310, 9);
            this.lbl_tieude.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_tieude.Name = "lbl_tieude";
            this.lbl_tieude.Size = new System.Drawing.Size(184, 22);
            this.lbl_tieude.TabIndex = 0;
            this.lbl_tieude.Text = "QUẢN LÝ RẠP DVK";
            // 
            // panel_form
            // 
            this.panel_form.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_form.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_form.Location = new System.Drawing.Point(224, 46);
            this.panel_form.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel_form.Name = "panel_form";
            this.panel_form.Size = new System.Drawing.Size(798, 465);
            this.panel_form.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Gainsboro;
            this.button2.Image = global::QL_RapChieuPhim.Properties.Resources.admin_icon;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 429);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(224, 41);
            this.button2.TabIndex = 8;
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Image = global::QL_RapChieuPhim.Properties.Resources.exit;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 470);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(224, 41);
            this.button1.TabIndex = 7;
            this.button1.Text = "   Đăng xuất";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox_menu
            // 
            this.pictureBox_menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_menu.Image = global::QL_RapChieuPhim.Properties.Resources.menu_bar;
            this.pictureBox_menu.Location = new System.Drawing.Point(16, 18);
            this.pictureBox_menu.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox_menu.Name = "pictureBox_menu";
            this.pictureBox_menu.Size = new System.Drawing.Size(25, 28);
            this.pictureBox_menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_menu.TabIndex = 1;
            this.pictureBox_menu.TabStop = false;
            this.pictureBox_menu.Click += new System.EventHandler(this.pictureBox_menu_Click);
            // 
            // ThongKe_DoanhSo
            // 
            this.ThongKe_DoanhSo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThongKe_DoanhSo.FlatAppearance.BorderSize = 0;
            this.ThongKe_DoanhSo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ThongKe_DoanhSo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThongKe_DoanhSo.ForeColor = System.Drawing.Color.Gainsboro;
            this.ThongKe_DoanhSo.Image = global::QL_RapChieuPhim.Properties.Resources.chart_Icon;
            this.ThongKe_DoanhSo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ThongKe_DoanhSo.Location = new System.Drawing.Point(-4, 275);
            this.ThongKe_DoanhSo.Margin = new System.Windows.Forms.Padding(2);
            this.ThongKe_DoanhSo.Name = "ThongKe_DoanhSo";
            this.ThongKe_DoanhSo.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.ThongKe_DoanhSo.Size = new System.Drawing.Size(224, 41);
            this.ThongKe_DoanhSo.TabIndex = 6;
            this.ThongKe_DoanhSo.Text = "   Thống kê doanh số";
            this.ThongKe_DoanhSo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ThongKe_DoanhSo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ThongKe_DoanhSo.UseVisualStyleBackColor = true;
            this.ThongKe_DoanhSo.Click += new System.EventHandler(this.ThongKe_DoanhSo_Click);
            // 
            // QL_khachHang
            // 
            this.QL_khachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.QL_khachHang.FlatAppearance.BorderSize = 0;
            this.QL_khachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QL_khachHang.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QL_khachHang.ForeColor = System.Drawing.Color.Gainsboro;
            this.QL_khachHang.Image = global::QL_RapChieuPhim.Properties.Resources.QL_khachhang;
            this.QL_khachHang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QL_khachHang.Location = new System.Drawing.Point(0, 230);
            this.QL_khachHang.Margin = new System.Windows.Forms.Padding(2);
            this.QL_khachHang.Name = "QL_khachHang";
            this.QL_khachHang.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.QL_khachHang.Size = new System.Drawing.Size(224, 41);
            this.QL_khachHang.TabIndex = 6;
            this.QL_khachHang.Text = "   Quản lý khách hàng";
            this.QL_khachHang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QL_khachHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.QL_khachHang.UseVisualStyleBackColor = true;
            this.QL_khachHang.Click += new System.EventHandler(this.QL_khachHang_Click);
            // 
            // QL_NhanVien
            // 
            this.QL_NhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.QL_NhanVien.FlatAppearance.BorderSize = 0;
            this.QL_NhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.QL_NhanVien.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QL_NhanVien.ForeColor = System.Drawing.Color.Gainsboro;
            this.QL_NhanVien.Image = global::QL_RapChieuPhim.Properties.Resources.QL_nhanvien;
            this.QL_NhanVien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QL_NhanVien.Location = new System.Drawing.Point(0, 189);
            this.QL_NhanVien.Margin = new System.Windows.Forms.Padding(2);
            this.QL_NhanVien.Name = "QL_NhanVien";
            this.QL_NhanVien.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.QL_NhanVien.Size = new System.Drawing.Size(224, 41);
            this.QL_NhanVien.TabIndex = 5;
            this.QL_NhanVien.Text = "   Quản lý nhân viên";
            this.QL_NhanVien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QL_NhanVien.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.QL_NhanVien.UseVisualStyleBackColor = true;
            this.QL_NhanVien.Click += new System.EventHandler(this.QL_NhanVien_Click);
            // 
            // btn_QLSanPham
            // 
            this.btn_QLSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_QLSanPham.FlatAppearance.BorderSize = 0;
            this.btn_QLSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_QLSanPham.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_QLSanPham.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_QLSanPham.Image = global::QL_RapChieuPhim.Properties.Resources.QL_sanpham;
            this.btn_QLSanPham.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_QLSanPham.Location = new System.Drawing.Point(0, 149);
            this.btn_QLSanPham.Margin = new System.Windows.Forms.Padding(2);
            this.btn_QLSanPham.Name = "btn_QLSanPham";
            this.btn_QLSanPham.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_QLSanPham.Size = new System.Drawing.Size(224, 41);
            this.btn_QLSanPham.TabIndex = 4;
            this.btn_QLSanPham.Text = "   Quản lý sản phẩm";
            this.btn_QLSanPham.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_QLSanPham.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_QLSanPham.UseVisualStyleBackColor = true;
            this.btn_QLSanPham.Click += new System.EventHandler(this.btn_QLSanPham_Click);
            // 
            // btn_QLSuatChieu
            // 
            this.btn_QLSuatChieu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_QLSuatChieu.FlatAppearance.BorderSize = 0;
            this.btn_QLSuatChieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_QLSuatChieu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_QLSuatChieu.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_QLSuatChieu.Image = global::QL_RapChieuPhim.Properties.Resources.QL_suatchieu;
            this.btn_QLSuatChieu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_QLSuatChieu.Location = new System.Drawing.Point(0, 108);
            this.btn_QLSuatChieu.Margin = new System.Windows.Forms.Padding(2);
            this.btn_QLSuatChieu.Name = "btn_QLSuatChieu";
            this.btn_QLSuatChieu.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_QLSuatChieu.Size = new System.Drawing.Size(224, 41);
            this.btn_QLSuatChieu.TabIndex = 3;
            this.btn_QLSuatChieu.Text = "   Quản lý suất chiếu";
            this.btn_QLSuatChieu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_QLSuatChieu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_QLSuatChieu.UseVisualStyleBackColor = true;
            this.btn_QLSuatChieu.Click += new System.EventHandler(this.btn_QLSuatChieu_Click);
            // 
            // btn_QLPhim
            // 
            this.btn_QLPhim.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_QLPhim.FlatAppearance.BorderSize = 0;
            this.btn_QLPhim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_QLPhim.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_QLPhim.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_QLPhim.Image = global::QL_RapChieuPhim.Properties.Resources.QL_film;
            this.btn_QLPhim.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_QLPhim.Location = new System.Drawing.Point(0, 67);
            this.btn_QLPhim.Margin = new System.Windows.Forms.Padding(2);
            this.btn_QLPhim.Name = "btn_QLPhim";
            this.btn_QLPhim.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_QLPhim.Size = new System.Drawing.Size(224, 41);
            this.btn_QLPhim.TabIndex = 2;
            this.btn_QLPhim.Text = "   Quản lý phim";
            this.btn_QLPhim.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_QLPhim.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_QLPhim.UseVisualStyleBackColor = true;
            this.btn_QLPhim.Click += new System.EventHandler(this.btn_QLPhim_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 511);
            this.Controls.Add(this.panel_form);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.panel_menu.ResumeLayout(false);
            this.panel_menu.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_menu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_menu;
        private System.Windows.Forms.Button btn_QLPhim;
        private System.Windows.Forms.Button QL_khachHang;
        private System.Windows.Forms.Button QL_NhanVien;
        private System.Windows.Forms.Button btn_QLSanPham;
        private System.Windows.Forms.Button btn_QLSuatChieu;
        private System.Windows.Forms.PictureBox pictureBox_menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer slidebar_timer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel_form;
        private System.Windows.Forms.Label lbl_tieude;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lbl_admin;
        private System.Windows.Forms.Button ThongKe_DoanhSo;
    }
}