﻿namespace QL_RapChieuPhim.Views
{
    partial class sanPham2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sanPham2));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.txt_timkiemSP = new Bunifu.UI.WinForms.BunifuTextBox();
            this.cbb_LoaiSP = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_ThemSP = new CustomControls.RJControls.RJButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(19, 32);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(804, 314);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // txt_timkiemSP
            // 
            this.txt_timkiemSP.AcceptsReturn = false;
            this.txt_timkiemSP.AcceptsTab = false;
            this.txt_timkiemSP.AnimationSpeed = 200;
            this.txt_timkiemSP.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txt_timkiemSP.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txt_timkiemSP.BackColor = System.Drawing.Color.Transparent;
            this.txt_timkiemSP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txt_timkiemSP.BackgroundImage")));
            this.txt_timkiemSP.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txt_timkiemSP.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txt_timkiemSP.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txt_timkiemSP.BorderColorIdle = System.Drawing.Color.Silver;
            this.txt_timkiemSP.BorderRadius = 10;
            this.txt_timkiemSP.BorderThickness = 1;
            this.txt_timkiemSP.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txt_timkiemSP.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_timkiemSP.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.txt_timkiemSP.DefaultText = "";
            this.txt_timkiemSP.FillColor = System.Drawing.Color.White;
            this.txt_timkiemSP.HideSelection = true;
            this.txt_timkiemSP.IconLeft = null;
            this.txt_timkiemSP.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_timkiemSP.IconPadding = 10;
            this.txt_timkiemSP.IconRight = null;
            this.txt_timkiemSP.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_timkiemSP.Lines = new string[0];
            this.txt_timkiemSP.Location = new System.Drawing.Point(10, 80);
            this.txt_timkiemSP.MaxLength = 32767;
            this.txt_timkiemSP.MinimumSize = new System.Drawing.Size(1, 1);
            this.txt_timkiemSP.Modified = false;
            this.txt_timkiemSP.Multiline = false;
            this.txt_timkiemSP.Name = "txt_timkiemSP";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_timkiemSP.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txt_timkiemSP.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_timkiemSP.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txt_timkiemSP.OnIdleState = stateProperties4;
            this.txt_timkiemSP.Padding = new System.Windows.Forms.Padding(3);
            this.txt_timkiemSP.PasswordChar = '\0';
            this.txt_timkiemSP.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txt_timkiemSP.PlaceholderText = "Enter text";
            this.txt_timkiemSP.ReadOnly = false;
            this.txt_timkiemSP.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_timkiemSP.SelectedText = "";
            this.txt_timkiemSP.SelectionLength = 0;
            this.txt_timkiemSP.SelectionStart = 0;
            this.txt_timkiemSP.ShortcutsEnabled = true;
            this.txt_timkiemSP.Size = new System.Drawing.Size(260, 36);
            this.txt_timkiemSP.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txt_timkiemSP.TabIndex = 10;
            this.txt_timkiemSP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_timkiemSP.TextMarginBottom = 0;
            this.txt_timkiemSP.TextMarginLeft = 3;
            this.txt_timkiemSP.TextMarginTop = 0;
            this.txt_timkiemSP.TextPlaceholder = "Enter text";
            this.txt_timkiemSP.UseSystemPasswordChar = false;
            this.txt_timkiemSP.WordWrap = true;
            this.txt_timkiemSP.TextChange += new System.EventHandler(this.txt_timkiemSP_TextChange);
            // 
            // cbb_LoaiSP
            // 
            this.cbb_LoaiSP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbb_LoaiSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbb_LoaiSP.ForeColor = System.Drawing.Color.DarkGray;
            this.cbb_LoaiSP.FormattingEnabled = true;
            this.cbb_LoaiSP.Location = new System.Drawing.Point(733, 98);
            this.cbb_LoaiSP.Margin = new System.Windows.Forms.Padding(2);
            this.cbb_LoaiSP.Name = "cbb_LoaiSP";
            this.cbb_LoaiSP.Size = new System.Drawing.Size(91, 21);
            this.cbb_LoaiSP.TabIndex = 15;
            this.cbb_LoaiSP.Text = "Tất cả";
            this.cbb_LoaiSP.SelectedIndexChanged += new System.EventHandler(this.cbb_LoaiSP_SelectedIndexChanged);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(732, 126);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(90, 1);
            this.panel6.TabIndex = 14;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(9, 132);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(838, 365);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bảng sản phẩm";
            // 
            // btn_ThemSP
            // 
            this.btn_ThemSP.BackColor = System.Drawing.Color.White;
            this.btn_ThemSP.BackgroundColor = System.Drawing.Color.White;
            this.btn_ThemSP.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_ThemSP.BorderRadius = 15;
            this.btn_ThemSP.BorderSize = 3;
            this.btn_ThemSP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ThemSP.FlatAppearance.BorderSize = 0;
            this.btn_ThemSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ThemSP.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThemSP.ForeColor = System.Drawing.Color.DimGray;
            this.btn_ThemSP.Image = global::QL_RapChieuPhim.Properties.Resources.popcorn_icon;
            this.btn_ThemSP.Location = new System.Drawing.Point(434, 55);
            this.btn_ThemSP.Margin = new System.Windows.Forms.Padding(2);
            this.btn_ThemSP.Name = "btn_ThemSP";
            this.btn_ThemSP.Size = new System.Drawing.Size(115, 73);
            this.btn_ThemSP.TabIndex = 9;
            this.btn_ThemSP.Text = " Thêm sản phẩm";
            this.btn_ThemSP.TextColor = System.Drawing.Color.DimGray;
            this.btn_ThemSP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_ThemSP.UseVisualStyleBackColor = false;
            this.btn_ThemSP.Click += new System.EventHandler(this.btn_ThemSP_Click);
            // 
            // sanPham2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(856, 503);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbb_LoaiSP);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.txt_timkiemSP);
            this.Controls.Add(this.btn_ThemSP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "sanPham2";
            this.Text = "QUẢN LÝ SẢN PHẨM";
            this.Load += new System.EventHandler(this.sanPham2_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private CustomControls.RJControls.RJButton btn_ThemSP;
        private Bunifu.UI.WinForms.BunifuTextBox txt_timkiemSP;
        private System.Windows.Forms.ComboBox cbb_LoaiSP;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}