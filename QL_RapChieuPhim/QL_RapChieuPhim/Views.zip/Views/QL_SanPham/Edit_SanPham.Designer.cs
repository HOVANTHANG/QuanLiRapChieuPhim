﻿namespace QL_RapChieuPhim.Views
{
    partial class Edit_SanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_MaSp = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_TenSp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txt_SoLuong = new System.Windows.Forms.TextBox();
            this.txt_DonGia = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbb_LoaiSp = new System.Windows.Forms.ComboBox();
            this.btn_luuSP = new CustomControls.RJControls.RJButton();
            this.btn_huySP = new CustomControls.RJControls.RJButton();
            this.dtb_NgayNhap = new System.Windows.Forms.DateTimePicker();
            this.btn_openAnhSP = new CustomControls.RJControls.RJButton();
            this.pictureBox_AnhSP = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AnhSP)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_MaSp
            // 
            this.txt_MaSp.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_MaSp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaSp.Enabled = false;
            this.txt_MaSp.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaSp.Location = new System.Drawing.Point(152, 82);
            this.txt_MaSp.Margin = new System.Windows.Forms.Padding(5);
            this.txt_MaSp.Multiline = true;
            this.txt_MaSp.Name = "txt_MaSp";
            this.txt_MaSp.Size = new System.Drawing.Size(208, 36);
            this.txt_MaSp.TabIndex = 1;
            this.txt_MaSp.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(0, 55);
            this.panel5.Margin = new System.Windows.Forms.Padding(5);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(780, 1);
            this.panel5.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 22);
            this.label1.TabIndex = 13;
            this.label1.Text = "Sửa sản phẩm";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 88);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Mã sản phẩm";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(152, 127);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(208, 1);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(152, 196);
            this.panel2.Margin = new System.Windows.Forms.Padding(5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(208, 1);
            this.panel2.TabIndex = 11;
            // 
            // txt_TenSp
            // 
            this.txt_TenSp.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_TenSp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_TenSp.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenSp.Location = new System.Drawing.Point(152, 151);
            this.txt_TenSp.Margin = new System.Windows.Forms.Padding(5);
            this.txt_TenSp.Multiline = true;
            this.txt_TenSp.Name = "txt_TenSp";
            this.txt_TenSp.Size = new System.Drawing.Size(208, 36);
            this.txt_TenSp.TabIndex = 2;
            this.txt_TenSp.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 157);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "Tên sản phẩm";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(152, 269);
            this.panel3.Margin = new System.Windows.Forms.Padding(5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(208, 1);
            this.panel3.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(31, 229);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 16);
            this.label4.TabIndex = 14;
            this.label4.Text = "Loại";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(525, 127);
            this.panel4.Margin = new System.Windows.Forms.Padding(5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(211, 1);
            this.panel4.TabIndex = 11;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(525, 196);
            this.panel6.Margin = new System.Windows.Forms.Padding(5);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(211, 1);
            this.panel6.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(525, 269);
            this.panel7.Margin = new System.Windows.Forms.Padding(5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(211, 1);
            this.panel7.TabIndex = 11;
            // 
            // txt_SoLuong
            // 
            this.txt_SoLuong.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_SoLuong.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_SoLuong.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SoLuong.Location = new System.Drawing.Point(525, 151);
            this.txt_SoLuong.Margin = new System.Windows.Forms.Padding(5);
            this.txt_SoLuong.Multiline = true;
            this.txt_SoLuong.Name = "txt_SoLuong";
            this.txt_SoLuong.Size = new System.Drawing.Size(211, 36);
            this.txt_SoLuong.TabIndex = 5;
            this.txt_SoLuong.UseSystemPasswordChar = true;
            // 
            // txt_DonGia
            // 
            this.txt_DonGia.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txt_DonGia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_DonGia.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DonGia.Location = new System.Drawing.Point(525, 223);
            this.txt_DonGia.Margin = new System.Windows.Forms.Padding(5);
            this.txt_DonGia.Multiline = true;
            this.txt_DonGia.Name = "txt_DonGia";
            this.txt_DonGia.Size = new System.Drawing.Size(211, 36);
            this.txt_DonGia.TabIndex = 6;
            this.txt_DonGia.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(406, 88);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Ngày nhập";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(406, 157);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Số lượng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(406, 229);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Đơn giá";
            // 
            // cbb_LoaiSp
            // 
            this.cbb_LoaiSp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbb_LoaiSp.FormattingEnabled = true;
            this.cbb_LoaiSp.Location = new System.Drawing.Point(152, 226);
            this.cbb_LoaiSp.Name = "cbb_LoaiSp";
            this.cbb_LoaiSp.Size = new System.Drawing.Size(208, 24);
            this.cbb_LoaiSp.TabIndex = 3;
            // 
            // btn_luuSP
            // 
            this.btn_luuSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuSP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuSP.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_luuSP.BorderRadius = 16;
            this.btn_luuSP.BorderSize = 0;
            this.btn_luuSP.FlatAppearance.BorderSize = 0;
            this.btn_luuSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_luuSP.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luuSP.ForeColor = System.Drawing.Color.White;
            this.btn_luuSP.Location = new System.Drawing.Point(515, 494);
            this.btn_luuSP.Name = "btn_luuSP";
            this.btn_luuSP.Size = new System.Drawing.Size(106, 40);
            this.btn_luuSP.TabIndex = 19;
            this.btn_luuSP.Text = "Lưu";
            this.btn_luuSP.TextColor = System.Drawing.Color.White;
            this.btn_luuSP.UseVisualStyleBackColor = false;
            this.btn_luuSP.Click += new System.EventHandler(this.btn_luuSP_Click);
            // 
            // btn_huySP
            // 
            this.btn_huySP.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_huySP.BackgroundColor = System.Drawing.Color.OrangeRed;
            this.btn_huySP.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_huySP.BorderRadius = 16;
            this.btn_huySP.BorderSize = 0;
            this.btn_huySP.FlatAppearance.BorderSize = 0;
            this.btn_huySP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_huySP.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_huySP.ForeColor = System.Drawing.Color.White;
            this.btn_huySP.Location = new System.Drawing.Point(637, 494);
            this.btn_huySP.Name = "btn_huySP";
            this.btn_huySP.Size = new System.Drawing.Size(106, 40);
            this.btn_huySP.TabIndex = 19;
            this.btn_huySP.Text = "Hủy";
            this.btn_huySP.TextColor = System.Drawing.Color.White;
            this.btn_huySP.UseVisualStyleBackColor = false;
            this.btn_huySP.Click += new System.EventHandler(this.btn_huySP_Click);
            // 
            // dtb_NgayNhap
            // 
            this.dtb_NgayNhap.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtb_NgayNhap.Location = new System.Drawing.Point(525, 88);
            this.dtb_NgayNhap.Name = "dtb_NgayNhap";
            this.dtb_NgayNhap.Size = new System.Drawing.Size(211, 23);
            this.dtb_NgayNhap.TabIndex = 4;
            // 
            // btn_openAnhSP
            // 
            this.btn_openAnhSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_openAnhSP.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_openAnhSP.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_openAnhSP.BorderRadius = 10;
            this.btn_openAnhSP.BorderSize = 0;
            this.btn_openAnhSP.FlatAppearance.BorderSize = 0;
            this.btn_openAnhSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_openAnhSP.ForeColor = System.Drawing.Color.White;
            this.btn_openAnhSP.Image = global::QL_RapChieuPhim.Properties.Resources.folder_icon;
            this.btn_openAnhSP.Location = new System.Drawing.Point(380, 403);
            this.btn_openAnhSP.Name = "btn_openAnhSP";
            this.btn_openAnhSP.Size = new System.Drawing.Size(61, 40);
            this.btn_openAnhSP.TabIndex = 18;
            this.btn_openAnhSP.TextColor = System.Drawing.Color.White;
            this.btn_openAnhSP.UseVisualStyleBackColor = false;
            this.btn_openAnhSP.Click += new System.EventHandler(this.btn_openAnhSP_Click);
            // 
            // pictureBox_AnhSP
            // 
            this.pictureBox_AnhSP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_AnhSP.Location = new System.Drawing.Point(24, 296);
            this.pictureBox_AnhSP.Name = "pictureBox_AnhSP";
            this.pictureBox_AnhSP.Size = new System.Drawing.Size(350, 238);
            this.pictureBox_AnhSP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_AnhSP.TabIndex = 20;
            this.pictureBox_AnhSP.TabStop = false;
            // 
            // Edit_SanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(780, 546);
            this.Controls.Add(this.dtb_NgayNhap);
            this.Controls.Add(this.btn_openAnhSP);
            this.Controls.Add(this.btn_huySP);
            this.Controls.Add(this.btn_luuSP);
            this.Controls.Add(this.pictureBox_AnhSP);
            this.Controls.Add(this.cbb_LoaiSp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_DonGia);
            this.Controls.Add(this.txt_SoLuong);
            this.Controls.Add(this.txt_TenSp);
            this.Controls.Add(this.txt_MaSp);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Edit_SanPham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_SanPham";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AnhSP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_MaSp;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_TenSp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txt_SoLuong;
        private System.Windows.Forms.TextBox txt_DonGia;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbb_LoaiSp;
        private CustomControls.RJControls.RJButton btn_openAnhSP;
        private CustomControls.RJControls.RJButton btn_luuSP;
        private System.Windows.Forms.PictureBox pictureBox_AnhSP;
        private CustomControls.RJControls.RJButton btn_huySP;
        private System.Windows.Forms.DateTimePicker dtb_NgayNhap;
    }
}