﻿namespace QL_RapChieuPhim.Views
{
    partial class Add_Phim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_MaPhim = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_ThoiLuongPhim = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_addDaodien = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbb_TheLoaiPhim = new System.Windows.Forms.ComboBox();
            this.cbb_QuocGia = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_NamPhatHanh = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_MoTaPhim = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox_AnhPhim = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_close_addphim = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txt_TenPhim = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.error_Phim = new System.Windows.Forms.ErrorProvider(this.components);
            this.btn_openAnhPhim = new CustomControls.RJControls.RJButton();
            this.btn_luuPhim = new CustomControls.RJControls.RJButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AnhPhim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error_Phim)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_MaPhim
            // 
            this.txt_MaPhim.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_MaPhim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaPhim.Enabled = false;
            this.txt_MaPhim.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaPhim.Location = new System.Drawing.Point(10, 110);
            this.txt_MaPhim.Multiline = true;
            this.txt_MaPhim.Name = "txt_MaPhim";
            this.txt_MaPhim.Size = new System.Drawing.Size(111, 24);
            this.txt_MaPhim.TabIndex = 1;
            this.txt_MaPhim.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(1, 33);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(677, 1);
            this.panel5.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 2);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 27);
            this.label1.TabIndex = 10;
            this.label1.Text = "Thêm Phim";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label2.Location = new System.Drawing.Point(10, 68);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Mã Phim";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(10, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(111, 1);
            this.panel1.TabIndex = 8;
            // 
            // txt_ThoiLuongPhim
            // 
            this.txt_ThoiLuongPhim.BackColor = System.Drawing.Color.White;
            this.txt_ThoiLuongPhim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ThoiLuongPhim.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ThoiLuongPhim.Location = new System.Drawing.Point(535, 191);
            this.txt_ThoiLuongPhim.Multiline = true;
            this.txt_ThoiLuongPhim.Name = "txt_ThoiLuongPhim";
            this.txt_ThoiLuongPhim.Size = new System.Drawing.Size(113, 28);
            this.txt_ThoiLuongPhim.TabIndex = 5;
            this.txt_ThoiLuongPhim.UseSystemPasswordChar = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(412, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(236, 1);
            this.panel2.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label3.Location = new System.Drawing.Point(410, 68);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Thể Loại";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(10, 221);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(365, 1);
            this.panel3.TabIndex = 8;
            // 
            // txt_addDaodien
            // 
            this.txt_addDaodien.BackColor = System.Drawing.Color.White;
            this.txt_addDaodien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_addDaodien.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addDaodien.Location = new System.Drawing.Point(10, 194);
            this.txt_addDaodien.Multiline = true;
            this.txt_addDaodien.Name = "txt_addDaodien";
            this.txt_addDaodien.Size = new System.Drawing.Size(365, 24);
            this.txt_addDaodien.TabIndex = 3;
            this.txt_addDaodien.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label4.Location = new System.Drawing.Point(11, 153);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Đạo Diễn";
            // 
            // cbb_TheLoaiPhim
            // 
            this.cbb_TheLoaiPhim.BackColor = System.Drawing.Color.White;
            this.cbb_TheLoaiPhim.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_TheLoaiPhim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbb_TheLoaiPhim.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_TheLoaiPhim.FormattingEnabled = true;
            this.cbb_TheLoaiPhim.Location = new System.Drawing.Point(412, 108);
            this.cbb_TheLoaiPhim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbb_TheLoaiPhim.Name = "cbb_TheLoaiPhim";
            this.cbb_TheLoaiPhim.Size = new System.Drawing.Size(237, 27);
            this.cbb_TheLoaiPhim.TabIndex = 2;
            // 
            // cbb_QuocGia
            // 
            this.cbb_QuocGia.BackColor = System.Drawing.Color.White;
            this.cbb_QuocGia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_QuocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbb_QuocGia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_QuocGia.FormattingEnabled = true;
            this.cbb_QuocGia.Location = new System.Drawing.Point(412, 193);
            this.cbb_QuocGia.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbb_QuocGia.Name = "cbb_QuocGia";
            this.cbb_QuocGia.Size = new System.Drawing.Size(114, 27);
            this.cbb_QuocGia.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(412, 221);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(113, 1);
            this.panel4.TabIndex = 13;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(535, 221);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(113, 1);
            this.panel6.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label5.Location = new System.Drawing.Point(410, 153);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Quốc Gia";
            // 
            // txt_NamPhatHanh
            // 
            this.txt_NamPhatHanh.BackColor = System.Drawing.Color.White;
            this.txt_NamPhatHanh.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_NamPhatHanh.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NamPhatHanh.Location = new System.Drawing.Point(550, 271);
            this.txt_NamPhatHanh.Multiline = true;
            this.txt_NamPhatHanh.Name = "txt_NamPhatHanh";
            this.txt_NamPhatHanh.Size = new System.Drawing.Size(98, 28);
            this.txt_NamPhatHanh.TabIndex = 9;
            this.txt_NamPhatHanh.UseSystemPasswordChar = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(550, 301);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(98, 1);
            this.panel7.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label6.Location = new System.Drawing.Point(548, 236);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 16);
            this.label6.TabIndex = 15;
            this.label6.Text = "Năm phát hành";
            // 
            // txt_MoTaPhim
            // 
            this.txt_MoTaPhim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_MoTaPhim.Location = new System.Drawing.Point(10, 260);
            this.txt_MoTaPhim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_MoTaPhim.Multiline = true;
            this.txt_MoTaPhim.Name = "txt_MoTaPhim";
            this.txt_MoTaPhim.Size = new System.Drawing.Size(310, 194);
            this.txt_MoTaPhim.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label7.Location = new System.Drawing.Point(11, 236);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Mô tả phim";
            // 
            // pictureBox_AnhPhim
            // 
            this.pictureBox_AnhPhim.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_AnhPhim.Location = new System.Drawing.Point(340, 260);
            this.pictureBox_AnhPhim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox_AnhPhim.Name = "pictureBox_AnhPhim";
            this.pictureBox_AnhPhim.Size = new System.Drawing.Size(149, 194);
            this.pictureBox_AnhPhim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_AnhPhim.TabIndex = 17;
            this.pictureBox_AnhPhim.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label8.Location = new System.Drawing.Point(532, 153);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 16);
            this.label8.TabIndex = 11;
            this.label8.Text = "Thời Lượng";
            // 
            // btn_close_addphim
            // 
            this.btn_close_addphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_addphim.Location = new System.Drawing.Point(654, 2);
            this.btn_close_addphim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_close_addphim.Name = "btn_close_addphim";
            this.btn_close_addphim.Size = new System.Drawing.Size(22, 24);
            this.btn_close_addphim.TabIndex = 18;
            this.btn_close_addphim.Text = "X";
            this.btn_close_addphim.UseVisualStyleBackColor = true;
            this.btn_close_addphim.Click += new System.EventHandler(this.btn_close_addphim_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(148, 136);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(215, 1);
            this.panel8.TabIndex = 8;
            // 
            // txt_TenPhim
            // 
            this.txt_TenPhim.BackColor = System.Drawing.Color.White;
            this.txt_TenPhim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_TenPhim.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenPhim.Location = new System.Drawing.Point(148, 108);
            this.txt_TenPhim.Multiline = true;
            this.txt_TenPhim.Name = "txt_TenPhim";
            this.txt_TenPhim.Size = new System.Drawing.Size(215, 24);
            this.txt_TenPhim.TabIndex = 2;
            this.txt_TenPhim.UseSystemPasswordChar = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label9.Location = new System.Drawing.Point(146, 68);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 16);
            this.label9.TabIndex = 11;
            this.label9.Text = "Tên Phim";
            // 
            // error_Phim
            // 
            this.error_Phim.ContainerControl = this;
            // 
            // btn_openAnhPhim
            // 
            this.btn_openAnhPhim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_openAnhPhim.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_openAnhPhim.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_openAnhPhim.BorderRadius = 10;
            this.btn_openAnhPhim.BorderSize = 0;
            this.btn_openAnhPhim.FlatAppearance.BorderSize = 0;
            this.btn_openAnhPhim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_openAnhPhim.ForeColor = System.Drawing.Color.White;
            this.btn_openAnhPhim.Image = global::QL_RapChieuPhim.Properties.Resources.folder_icon;
            this.btn_openAnhPhim.Location = new System.Drawing.Point(502, 421);
            this.btn_openAnhPhim.Margin = new System.Windows.Forms.Padding(2);
            this.btn_openAnhPhim.Name = "btn_openAnhPhim";
            this.btn_openAnhPhim.Size = new System.Drawing.Size(46, 32);
            this.btn_openAnhPhim.TabIndex = 7;
            this.btn_openAnhPhim.TextColor = System.Drawing.Color.White;
            this.btn_openAnhPhim.UseVisualStyleBackColor = false;
            this.btn_openAnhPhim.Click += new System.EventHandler(this.btn_openAnhPhim_Click);
            // 
            // btn_luuPhim
            // 
            this.btn_luuPhim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuPhim.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuPhim.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_luuPhim.BorderRadius = 16;
            this.btn_luuPhim.BorderSize = 0;
            this.btn_luuPhim.FlatAppearance.BorderSize = 0;
            this.btn_luuPhim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_luuPhim.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luuPhim.ForeColor = System.Drawing.Color.White;
            this.btn_luuPhim.Location = new System.Drawing.Point(592, 421);
            this.btn_luuPhim.Margin = new System.Windows.Forms.Padding(2);
            this.btn_luuPhim.Name = "btn_luuPhim";
            this.btn_luuPhim.Size = new System.Drawing.Size(80, 32);
            this.btn_luuPhim.TabIndex = 8;
            this.btn_luuPhim.Text = "Lưu";
            this.btn_luuPhim.TextColor = System.Drawing.Color.White;
            this.btn_luuPhim.UseVisualStyleBackColor = false;
            this.btn_luuPhim.Click += new System.EventHandler(this.btn_luuPhim_Click);
            // 
            // Add_Phim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(681, 463);
            this.Controls.Add(this.btn_close_addphim);
            this.Controls.Add(this.btn_openAnhPhim);
            this.Controls.Add(this.btn_luuPhim);
            this.Controls.Add(this.pictureBox_AnhPhim);
            this.Controls.Add(this.txt_MoTaPhim);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbb_QuocGia);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.cbb_TheLoaiPhim);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_NamPhatHanh);
            this.Controls.Add(this.txt_ThoiLuongPhim);
            this.Controls.Add(this.txt_addDaodien);
            this.Controls.Add(this.txt_TenPhim);
            this.Controls.Add(this.txt_MaPhim);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Add_Phim";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Phim";
            this.Load += new System.EventHandler(this.Add_Phim_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AnhPhim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error_Phim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_MaPhim;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_ThoiLuongPhim;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txt_addDaodien;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbb_TheLoaiPhim;
        private System.Windows.Forms.ComboBox cbb_QuocGia;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_NamPhatHanh;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_MoTaPhim;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox_AnhPhim;
        private CustomControls.RJControls.RJButton btn_luuPhim;
        private CustomControls.RJControls.RJButton btn_openAnhPhim;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_close_addphim;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_TenPhim;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ErrorProvider error_Phim;
    }
}