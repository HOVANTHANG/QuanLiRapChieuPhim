﻿namespace QL_RapChieuPhim.Views
{
    partial class ChiTiet_NhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close_chiTietNhanVien = new System.Windows.Forms.Button();
            this.lbl_chiTietNhanVien = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dTP_chiTietCaLam = new System.Windows.Forms.DateTimePicker();
            this.dTP_chiTietNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txt_chiTietTaiKhoan = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txt_chiTietLuong = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txt_chiTietSoDT = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txt_chiTietGioiTinh = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_chiTietHoTen = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txt_chiTietMNV = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_chiTietTaiKhoan = new System.Windows.Forms.Label();
            this.lbl_chiTietCaLam = new System.Windows.Forms.Label();
            this.lbl_chiTietLuong = new System.Windows.Forms.Label();
            this.lbl_chiTietSoDT = new System.Windows.Forms.Label();
            this.lbl_chiTietNgaySinh = new System.Windows.Forms.Label();
            this.lbl_chiTietGioiTinh = new System.Windows.Forms.Label();
            this.lbl_chiTietHoTen = new System.Windows.Forms.Label();
            this.lbl_chiTietMNV = new System.Windows.Forms.Label();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_close_chiTietNhanVien);
            this.panel1.Controls.Add(this.lbl_chiTietNhanVien);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(610, 48);
            this.panel1.TabIndex = 0;
            // 
            // btn_close_chiTietNhanVien
            // 
            this.btn_close_chiTietNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_chiTietNhanVien.Location = new System.Drawing.Point(569, 9);
            this.btn_close_chiTietNhanVien.Name = "btn_close_chiTietNhanVien";
            this.btn_close_chiTietNhanVien.Size = new System.Drawing.Size(30, 30);
            this.btn_close_chiTietNhanVien.TabIndex = 45;
            this.btn_close_chiTietNhanVien.Text = "X";
            this.btn_close_chiTietNhanVien.UseVisualStyleBackColor = true;
            this.btn_close_chiTietNhanVien.Click += new System.EventHandler(this.btn_close_chiTietNhanVien_Click);
            // 
            // lbl_chiTietNhanVien
            // 
            this.lbl_chiTietNhanVien.AutoSize = true;
            this.lbl_chiTietNhanVien.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Bold);
            this.lbl_chiTietNhanVien.Location = new System.Drawing.Point(12, 9);
            this.lbl_chiTietNhanVien.Name = "lbl_chiTietNhanVien";
            this.lbl_chiTietNhanVien.Size = new System.Drawing.Size(393, 34);
            this.lbl_chiTietNhanVien.TabIndex = 3;
            this.lbl_chiTietNhanVien.Text = "Chi tiết thông tin nhân viên";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.dTP_chiTietCaLam);
            this.panel2.Controls.Add(this.dTP_chiTietNgaySinh);
            this.panel2.Controls.Add(this.txt_chiTietTaiKhoan);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.txt_chiTietLuong);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.txt_chiTietSoDT);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.txt_chiTietGioiTinh);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.txt_chiTietHoTen);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.txt_chiTietMNV);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lbl_chiTietTaiKhoan);
            this.panel2.Controls.Add(this.lbl_chiTietCaLam);
            this.panel2.Controls.Add(this.lbl_chiTietLuong);
            this.panel2.Controls.Add(this.lbl_chiTietSoDT);
            this.panel2.Controls.Add(this.lbl_chiTietNgaySinh);
            this.panel2.Controls.Add(this.lbl_chiTietGioiTinh);
            this.panel2.Controls.Add(this.lbl_chiTietHoTen);
            this.panel2.Controls.Add(this.lbl_chiTietMNV);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(610, 483);
            this.panel2.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.ForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(31, 445);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(115, 1);
            this.panel9.TabIndex = 71;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(285, 208);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(139, 1);
            this.panel3.TabIndex = 70;
            // 
            // dTP_chiTietCaLam
            // 
            this.dTP_chiTietCaLam.CustomFormat = "HH:mm";
            this.dTP_chiTietCaLam.Enabled = false;
            this.dTP_chiTietCaLam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP_chiTietCaLam.Location = new System.Drawing.Point(31, 421);
            this.dTP_chiTietCaLam.Name = "dTP_chiTietCaLam";
            this.dTP_chiTietCaLam.ShowUpDown = true;
            this.dTP_chiTietCaLam.Size = new System.Drawing.Size(115, 22);
            this.dTP_chiTietCaLam.TabIndex = 69;
            // 
            // dTP_chiTietNgaySinh
            // 
            this.dTP_chiTietNgaySinh.Enabled = false;
            this.dTP_chiTietNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTP_chiTietNgaySinh.Location = new System.Drawing.Point(285, 183);
            this.dTP_chiTietNgaySinh.Name = "dTP_chiTietNgaySinh";
            this.dTP_chiTietNgaySinh.Size = new System.Drawing.Size(139, 22);
            this.dTP_chiTietNgaySinh.TabIndex = 68;
            // 
            // txt_chiTietTaiKhoan
            // 
            this.txt_chiTietTaiKhoan.BackColor = System.Drawing.Color.White;
            this.txt_chiTietTaiKhoan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietTaiKhoan.Enabled = false;
            this.txt_chiTietTaiKhoan.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietTaiKhoan.Location = new System.Drawing.Point(285, 413);
            this.txt_chiTietTaiKhoan.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietTaiKhoan.Multiline = true;
            this.txt_chiTietTaiKhoan.Name = "txt_chiTietTaiKhoan";
            this.txt_chiTietTaiKhoan.Size = new System.Drawing.Size(210, 30);
            this.txt_chiTietTaiKhoan.TabIndex = 67;
            this.txt_chiTietTaiKhoan.UseSystemPasswordChar = true;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.ForeColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(285, 446);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(210, 1);
            this.panel10.TabIndex = 66;
            // 
            // txt_chiTietLuong
            // 
            this.txt_chiTietLuong.BackColor = System.Drawing.Color.White;
            this.txt_chiTietLuong.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietLuong.Enabled = false;
            this.txt_chiTietLuong.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietLuong.Location = new System.Drawing.Point(285, 296);
            this.txt_chiTietLuong.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietLuong.Multiline = true;
            this.txt_chiTietLuong.Name = "txt_chiTietLuong";
            this.txt_chiTietLuong.Size = new System.Drawing.Size(177, 30);
            this.txt_chiTietLuong.TabIndex = 63;
            this.txt_chiTietLuong.UseSystemPasswordChar = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(285, 329);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(177, 1);
            this.panel8.TabIndex = 62;
            // 
            // txt_chiTietSoDT
            // 
            this.txt_chiTietSoDT.BackColor = System.Drawing.Color.White;
            this.txt_chiTietSoDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietSoDT.Enabled = false;
            this.txt_chiTietSoDT.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietSoDT.Location = new System.Drawing.Point(31, 296);
            this.txt_chiTietSoDT.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietSoDT.Multiline = true;
            this.txt_chiTietSoDT.Name = "txt_chiTietSoDT";
            this.txt_chiTietSoDT.Size = new System.Drawing.Size(193, 30);
            this.txt_chiTietSoDT.TabIndex = 61;
            this.txt_chiTietSoDT.UseSystemPasswordChar = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(31, 329);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(193, 1);
            this.panel7.TabIndex = 60;
            // 
            // txt_chiTietGioiTinh
            // 
            this.txt_chiTietGioiTinh.BackColor = System.Drawing.Color.White;
            this.txt_chiTietGioiTinh.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietGioiTinh.Enabled = false;
            this.txt_chiTietGioiTinh.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietGioiTinh.Location = new System.Drawing.Point(31, 175);
            this.txt_chiTietGioiTinh.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietGioiTinh.Multiline = true;
            this.txt_chiTietGioiTinh.Name = "txt_chiTietGioiTinh";
            this.txt_chiTietGioiTinh.Size = new System.Drawing.Size(162, 30);
            this.txt_chiTietGioiTinh.TabIndex = 58;
            this.txt_chiTietGioiTinh.UseSystemPasswordChar = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(31, 208);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(162, 1);
            this.panel6.TabIndex = 57;
            // 
            // txt_chiTietHoTen
            // 
            this.txt_chiTietHoTen.BackColor = System.Drawing.Color.White;
            this.txt_chiTietHoTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietHoTen.Enabled = false;
            this.txt_chiTietHoTen.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietHoTen.Location = new System.Drawing.Point(285, 61);
            this.txt_chiTietHoTen.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietHoTen.Multiline = true;
            this.txt_chiTietHoTen.Name = "txt_chiTietHoTen";
            this.txt_chiTietHoTen.Size = new System.Drawing.Size(312, 30);
            this.txt_chiTietHoTen.TabIndex = 56;
            this.txt_chiTietHoTen.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(285, 94);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(312, 1);
            this.panel5.TabIndex = 55;
            // 
            // txt_chiTietMNV
            // 
            this.txt_chiTietMNV.BackColor = System.Drawing.Color.White;
            this.txt_chiTietMNV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_chiTietMNV.Enabled = false;
            this.txt_chiTietMNV.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_chiTietMNV.Location = new System.Drawing.Point(31, 61);
            this.txt_chiTietMNV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_chiTietMNV.Multiline = true;
            this.txt_chiTietMNV.Name = "txt_chiTietMNV";
            this.txt_chiTietMNV.Size = new System.Drawing.Size(162, 30);
            this.txt_chiTietMNV.TabIndex = 54;
            this.txt_chiTietMNV.UseSystemPasswordChar = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(31, 94);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(162, 1);
            this.panel4.TabIndex = 53;
            // 
            // lbl_chiTietTaiKhoan
            // 
            this.lbl_chiTietTaiKhoan.AutoSize = true;
            this.lbl_chiTietTaiKhoan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietTaiKhoan.Location = new System.Drawing.Point(281, 372);
            this.lbl_chiTietTaiKhoan.Name = "lbl_chiTietTaiKhoan";
            this.lbl_chiTietTaiKhoan.Size = new System.Drawing.Size(110, 24);
            this.lbl_chiTietTaiKhoan.TabIndex = 51;
            this.lbl_chiTietTaiKhoan.Text = "Tài khoản:";
            // 
            // lbl_chiTietCaLam
            // 
            this.lbl_chiTietCaLam.AutoSize = true;
            this.lbl_chiTietCaLam.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietCaLam.Location = new System.Drawing.Point(27, 372);
            this.lbl_chiTietCaLam.Name = "lbl_chiTietCaLam";
            this.lbl_chiTietCaLam.Size = new System.Drawing.Size(81, 24);
            this.lbl_chiTietCaLam.TabIndex = 50;
            this.lbl_chiTietCaLam.Text = "Ca làm:";
            // 
            // lbl_chiTietLuong
            // 
            this.lbl_chiTietLuong.AutoSize = true;
            this.lbl_chiTietLuong.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietLuong.Location = new System.Drawing.Point(281, 250);
            this.lbl_chiTietLuong.Name = "lbl_chiTietLuong";
            this.lbl_chiTietLuong.Size = new System.Drawing.Size(81, 24);
            this.lbl_chiTietLuong.TabIndex = 49;
            this.lbl_chiTietLuong.Text = "Lương:";
            // 
            // lbl_chiTietSoDT
            // 
            this.lbl_chiTietSoDT.AutoSize = true;
            this.lbl_chiTietSoDT.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietSoDT.Location = new System.Drawing.Point(27, 250);
            this.lbl_chiTietSoDT.Name = "lbl_chiTietSoDT";
            this.lbl_chiTietSoDT.Size = new System.Drawing.Size(141, 24);
            this.lbl_chiTietSoDT.TabIndex = 48;
            this.lbl_chiTietSoDT.Text = "Số điện thoại:";
            // 
            // lbl_chiTietNgaySinh
            // 
            this.lbl_chiTietNgaySinh.AutoSize = true;
            this.lbl_chiTietNgaySinh.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietNgaySinh.Location = new System.Drawing.Point(281, 134);
            this.lbl_chiTietNgaySinh.Name = "lbl_chiTietNgaySinh";
            this.lbl_chiTietNgaySinh.Size = new System.Drawing.Size(111, 24);
            this.lbl_chiTietNgaySinh.TabIndex = 47;
            this.lbl_chiTietNgaySinh.Text = "Ngày sinh:";
            // 
            // lbl_chiTietGioiTinh
            // 
            this.lbl_chiTietGioiTinh.AutoSize = true;
            this.lbl_chiTietGioiTinh.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietGioiTinh.Location = new System.Drawing.Point(27, 134);
            this.lbl_chiTietGioiTinh.Name = "lbl_chiTietGioiTinh";
            this.lbl_chiTietGioiTinh.Size = new System.Drawing.Size(100, 24);
            this.lbl_chiTietGioiTinh.TabIndex = 46;
            this.lbl_chiTietGioiTinh.Text = "Giới tính:";
            // 
            // lbl_chiTietHoTen
            // 
            this.lbl_chiTietHoTen.AutoSize = true;
            this.lbl_chiTietHoTen.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietHoTen.Location = new System.Drawing.Point(281, 22);
            this.lbl_chiTietHoTen.Name = "lbl_chiTietHoTen";
            this.lbl_chiTietHoTen.Size = new System.Drawing.Size(107, 24);
            this.lbl_chiTietHoTen.TabIndex = 45;
            this.lbl_chiTietHoTen.Text = "Họ và tên:";
            // 
            // lbl_chiTietMNV
            // 
            this.lbl_chiTietMNV.AutoSize = true;
            this.lbl_chiTietMNV.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_chiTietMNV.Location = new System.Drawing.Point(27, 22);
            this.lbl_chiTietMNV.Name = "lbl_chiTietMNV";
            this.lbl_chiTietMNV.Size = new System.Drawing.Size(143, 24);
            this.lbl_chiTietMNV.TabIndex = 44;
            this.lbl_chiTietMNV.Text = "Mã nhân viên:";
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 20;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 5;
            this.bunifuElipse2.TargetControl = this;
            // 
            // ChiTiet_NhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(610, 531);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChiTiet_NhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChiTiet_NhanVien";
            this.Load += new System.EventHandler(this.ChiTiet_NhanVien_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_chiTietNhanVien;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_chiTietTaiKhoan;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txt_chiTietLuong;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_chiTietSoDT;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txt_chiTietGioiTinh;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_chiTietHoTen;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txt_chiTietMNV;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_chiTietTaiKhoan;
        private System.Windows.Forms.Label lbl_chiTietCaLam;
        private System.Windows.Forms.Label lbl_chiTietLuong;
        private System.Windows.Forms.Label lbl_chiTietSoDT;
        private System.Windows.Forms.Label lbl_chiTietNgaySinh;
        private System.Windows.Forms.Label lbl_chiTietGioiTinh;
        private System.Windows.Forms.Label lbl_chiTietHoTen;
        private System.Windows.Forms.Label lbl_chiTietMNV;
        private System.Windows.Forms.Button btn_close_chiTietNhanVien;
        private System.Windows.Forms.DateTimePicker dTP_chiTietNgaySinh;
        private System.Windows.Forms.DateTimePicker dTP_chiTietCaLam;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel9;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
    }
}