﻿namespace QL_RapChieuPhim.Views
{
    partial class Edit_NhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close_fixNhanVien = new System.Windows.Forms.Button();
            this.lbl_suaNhanVien = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_luuSuaNhanVien = new CustomControls.RJControls.RJButton();
            this.btn_huySuaNhanVien = new CustomControls.RJControls.RJButton();
            this.lbl_fixMatKhau = new System.Windows.Forms.Label();
            this.lbl_fixTaiKhoan = new System.Windows.Forms.Label();
            this.lbl_fixCaLam = new System.Windows.Forms.Label();
            this.lbl_fixLuong = new System.Windows.Forms.Label();
            this.lbl_fixSoDT = new System.Windows.Forms.Label();
            this.lbl_fixNgaySinh = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cB_fixgioiTinh = new System.Windows.Forms.ComboBox();
            this.dTP_fixCaLam = new System.Windows.Forms.DateTimePicker();
            this.lbl_fixHoTen = new System.Windows.Forms.Label();
            this.txt_fixMatKhau = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txt_fixTaiKhoan = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txt_fixLuong = new System.Windows.Forms.TextBox();
            this.lbl_fixGioiTinh = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txt_fixSoDT = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dTP_fixNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txt_fixHoTen = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txt_fixMNV = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_fixMNV = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btn_close_fixNhanVien);
            this.panel1.Controls.Add(this.lbl_suaNhanVien);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(653, 48);
            this.panel1.TabIndex = 0;
            // 
            // btn_close_fixNhanVien
            // 
            this.btn_close_fixNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_fixNhanVien.Location = new System.Drawing.Point(617, 9);
            this.btn_close_fixNhanVien.Name = "btn_close_fixNhanVien";
            this.btn_close_fixNhanVien.Size = new System.Drawing.Size(30, 30);
            this.btn_close_fixNhanVien.TabIndex = 44;
            this.btn_close_fixNhanVien.Text = "X";
            this.btn_close_fixNhanVien.UseVisualStyleBackColor = true;
            this.btn_close_fixNhanVien.Click += new System.EventHandler(this.btn_close_fixNhanVien_Click);
            // 
            // lbl_suaNhanVien
            // 
            this.lbl_suaNhanVien.AutoSize = true;
            this.lbl_suaNhanVien.Font = new System.Drawing.Font("Arial", 17F, System.Drawing.FontStyle.Bold);
            this.lbl_suaNhanVien.Location = new System.Drawing.Point(12, 9);
            this.lbl_suaNhanVien.Name = "lbl_suaNhanVien";
            this.lbl_suaNhanVien.Size = new System.Drawing.Size(350, 34);
            this.lbl_suaNhanVien.TabIndex = 2;
            this.lbl_suaNhanVien.Text = "Sửa thông tin nhân viên";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_luuSuaNhanVien);
            this.panel2.Controls.Add(this.btn_huySuaNhanVien);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 535);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(653, 60);
            this.panel2.TabIndex = 1;
            // 
            // btn_luuSuaNhanVien
            // 
            this.btn_luuSuaNhanVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuSuaNhanVien.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(183)))), ((int)(((byte)(253)))));
            this.btn_luuSuaNhanVien.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_luuSuaNhanVien.BorderRadius = 16;
            this.btn_luuSuaNhanVien.BorderSize = 0;
            this.btn_luuSuaNhanVien.FlatAppearance.BorderSize = 0;
            this.btn_luuSuaNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_luuSuaNhanVien.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_luuSuaNhanVien.ForeColor = System.Drawing.Color.White;
            this.btn_luuSuaNhanVien.Location = new System.Drawing.Point(535, 8);
            this.btn_luuSuaNhanVien.Name = "btn_luuSuaNhanVien";
            this.btn_luuSuaNhanVien.Size = new System.Drawing.Size(106, 40);
            this.btn_luuSuaNhanVien.TabIndex = 10;
            this.btn_luuSuaNhanVien.Text = "Lưu";
            this.btn_luuSuaNhanVien.TextColor = System.Drawing.Color.White;
            this.btn_luuSuaNhanVien.UseVisualStyleBackColor = false;
            this.btn_luuSuaNhanVien.Click += new System.EventHandler(this.btn_luuSuaNhanVien_Click);
            // 
            // btn_huySuaNhanVien
            // 
            this.btn_huySuaNhanVien.BackColor = System.Drawing.Color.Red;
            this.btn_huySuaNhanVien.BackgroundColor = System.Drawing.Color.Red;
            this.btn_huySuaNhanVien.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_huySuaNhanVien.BorderRadius = 16;
            this.btn_huySuaNhanVien.BorderSize = 0;
            this.btn_huySuaNhanVien.FlatAppearance.BorderSize = 0;
            this.btn_huySuaNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_huySuaNhanVien.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_huySuaNhanVien.ForeColor = System.Drawing.Color.White;
            this.btn_huySuaNhanVien.Location = new System.Drawing.Point(374, 8);
            this.btn_huySuaNhanVien.Name = "btn_huySuaNhanVien";
            this.btn_huySuaNhanVien.Size = new System.Drawing.Size(106, 40);
            this.btn_huySuaNhanVien.TabIndex = 11;
            this.btn_huySuaNhanVien.Text = "Hủy";
            this.btn_huySuaNhanVien.TextColor = System.Drawing.Color.White;
            this.btn_huySuaNhanVien.UseVisualStyleBackColor = false;
            this.btn_huySuaNhanVien.Click += new System.EventHandler(this.btn_huySuaNhanVien_Click);
            // 
            // lbl_fixMatKhau
            // 
            this.lbl_fixMatKhau.AutoSize = true;
            this.lbl_fixMatKhau.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixMatKhau.Location = new System.Drawing.Point(359, 376);
            this.lbl_fixMatKhau.Name = "lbl_fixMatKhau";
            this.lbl_fixMatKhau.Size = new System.Drawing.Size(104, 24);
            this.lbl_fixMatKhau.TabIndex = 25;
            this.lbl_fixMatKhau.Text = "Mật khẩu:";
            // 
            // lbl_fixTaiKhoan
            // 
            this.lbl_fixTaiKhoan.AutoSize = true;
            this.lbl_fixTaiKhoan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixTaiKhoan.Location = new System.Drawing.Point(41, 376);
            this.lbl_fixTaiKhoan.Name = "lbl_fixTaiKhoan";
            this.lbl_fixTaiKhoan.Size = new System.Drawing.Size(110, 24);
            this.lbl_fixTaiKhoan.TabIndex = 24;
            this.lbl_fixTaiKhoan.Text = "Tài khoản:";
            // 
            // lbl_fixCaLam
            // 
            this.lbl_fixCaLam.AutoSize = true;
            this.lbl_fixCaLam.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixCaLam.Location = new System.Drawing.Point(481, 145);
            this.lbl_fixCaLam.Name = "lbl_fixCaLam";
            this.lbl_fixCaLam.Size = new System.Drawing.Size(81, 24);
            this.lbl_fixCaLam.TabIndex = 23;
            this.lbl_fixCaLam.Text = "Ca làm:";
            // 
            // lbl_fixLuong
            // 
            this.lbl_fixLuong.AutoSize = true;
            this.lbl_fixLuong.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixLuong.Location = new System.Drawing.Point(330, 261);
            this.lbl_fixLuong.Name = "lbl_fixLuong";
            this.lbl_fixLuong.Size = new System.Drawing.Size(81, 24);
            this.lbl_fixLuong.TabIndex = 22;
            this.lbl_fixLuong.Text = "Lương:";
            // 
            // lbl_fixSoDT
            // 
            this.lbl_fixSoDT.AutoSize = true;
            this.lbl_fixSoDT.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixSoDT.Location = new System.Drawing.Point(41, 261);
            this.lbl_fixSoDT.Name = "lbl_fixSoDT";
            this.lbl_fixSoDT.Size = new System.Drawing.Size(141, 24);
            this.lbl_fixSoDT.TabIndex = 21;
            this.lbl_fixSoDT.Text = "Số điện thoại:";
            // 
            // lbl_fixNgaySinh
            // 
            this.lbl_fixNgaySinh.AutoSize = true;
            this.lbl_fixNgaySinh.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixNgaySinh.Location = new System.Drawing.Point(242, 145);
            this.lbl_fixNgaySinh.Name = "lbl_fixNgaySinh";
            this.lbl_fixNgaySinh.Size = new System.Drawing.Size(111, 24);
            this.lbl_fixNgaySinh.TabIndex = 20;
            this.lbl_fixNgaySinh.Text = "Ngày sinh:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.lbl_fixMatKhau);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.lbl_fixTaiKhoan);
            this.panel3.Controls.Add(this.cB_fixgioiTinh);
            this.panel3.Controls.Add(this.dTP_fixCaLam);
            this.panel3.Controls.Add(this.lbl_fixCaLam);
            this.panel3.Controls.Add(this.lbl_fixHoTen);
            this.panel3.Controls.Add(this.lbl_fixLuong);
            this.panel3.Controls.Add(this.txt_fixMatKhau);
            this.panel3.Controls.Add(this.lbl_fixSoDT);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.txt_fixTaiKhoan);
            this.panel3.Controls.Add(this.lbl_fixNgaySinh);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.txt_fixLuong);
            this.panel3.Controls.Add(this.lbl_fixGioiTinh);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.txt_fixSoDT);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.dTP_fixNgaySinh);
            this.panel3.Controls.Add(this.txt_fixHoTen);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.txt_fixMNV);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.lbl_fixMNV);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 48);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(653, 487);
            this.panel3.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.ForeColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(487, 218);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(140, 1);
            this.panel12.TabIndex = 48;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.ForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(246, 218);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(165, 1);
            this.panel9.TabIndex = 47;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(45, 217);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(130, 1);
            this.panel6.TabIndex = 46;
            // 
            // cB_fixgioiTinh
            // 
            this.cB_fixgioiTinh.FormattingEnabled = true;
            this.cB_fixgioiTinh.Items.AddRange(new object[] {
    "Nam",
    "Nữ"});
            this.cB_fixgioiTinh.Location = new System.Drawing.Point(45, 191);
            this.cB_fixgioiTinh.Name = "cB_fixgioiTinh";
            this.cB_fixgioiTinh.Size = new System.Drawing.Size(130, 24);
            this.cB_fixgioiTinh.TabIndex = 45;
            // 
            // dTP_fixCaLam
            // 
            this.dTP_fixCaLam.CustomFormat = "HH:mm";
            this.dTP_fixCaLam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP_fixCaLam.Location = new System.Drawing.Point(485, 194);
            this.dTP_fixCaLam.Name = "dTP_fixCaLam";
            this.dTP_fixCaLam.ShowUpDown = true;
            this.dTP_fixCaLam.Size = new System.Drawing.Size(139, 22);
            this.dTP_fixCaLam.TabIndex = 44;
            // 
            // lbl_fixHoTen
            // 
            this.lbl_fixHoTen.AutoSize = true;
            this.lbl_fixHoTen.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixHoTen.Location = new System.Drawing.Point(333, 37);
            this.lbl_fixHoTen.Name = "lbl_fixHoTen";
            this.lbl_fixHoTen.Size = new System.Drawing.Size(107, 24);
            this.lbl_fixHoTen.TabIndex = 12;
            this.lbl_fixHoTen.Text = "Họ và tên:";
            // 
            // txt_fixMatKhau
            // 
            this.txt_fixMatKhau.BackColor = System.Drawing.Color.White;
            this.txt_fixMatKhau.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixMatKhau.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixMatKhau.Location = new System.Drawing.Point(363, 421);
            this.txt_fixMatKhau.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixMatKhau.Multiline = true;
            this.txt_fixMatKhau.Name = "txt_fixMatKhau";
            this.txt_fixMatKhau.PasswordChar = '•';
            this.txt_fixMatKhau.Size = new System.Drawing.Size(231, 30);
            this.txt_fixMatKhau.TabIndex = 43;
            this.txt_fixMatKhau.Validating += new System.ComponentModel.CancelEventHandler(this.txt_fixMatKhau_Validating);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.ForeColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(363, 454);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(231, 1);
            this.panel11.TabIndex = 42;
            // 
            // txt_fixTaiKhoan
            // 
            this.txt_fixTaiKhoan.BackColor = System.Drawing.Color.White;
            this.txt_fixTaiKhoan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixTaiKhoan.Enabled = false;
            this.txt_fixTaiKhoan.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixTaiKhoan.Location = new System.Drawing.Point(45, 421);
            this.txt_fixTaiKhoan.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixTaiKhoan.Multiline = true;
            this.txt_fixTaiKhoan.Name = "txt_fixTaiKhoan";
            this.txt_fixTaiKhoan.Size = new System.Drawing.Size(220, 30);
            this.txt_fixTaiKhoan.TabIndex = 41;
            this.txt_fixTaiKhoan.UseSystemPasswordChar = true;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.ForeColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(45, 454);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(220, 1);
            this.panel10.TabIndex = 40;
            // 
            // txt_fixLuong
            // 
            this.txt_fixLuong.BackColor = System.Drawing.Color.White;
            this.txt_fixLuong.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixLuong.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixLuong.Location = new System.Drawing.Point(334, 300);
            this.txt_fixLuong.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixLuong.Multiline = true;
            this.txt_fixLuong.Name = "txt_fixLuong";
            this.txt_fixLuong.Size = new System.Drawing.Size(181, 30);
            this.txt_fixLuong.TabIndex = 37;
            this.txt_fixLuong.UseSystemPasswordChar = true;
            this.txt_fixLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_fixSoDT_KeyPress);
            // 
            // lbl_fixGioiTinh
            // 
            this.lbl_fixGioiTinh.AutoSize = true;
            this.lbl_fixGioiTinh.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixGioiTinh.Location = new System.Drawing.Point(41, 145);
            this.lbl_fixGioiTinh.Name = "lbl_fixGioiTinh";
            this.lbl_fixGioiTinh.Size = new System.Drawing.Size(100, 24);
            this.lbl_fixGioiTinh.TabIndex = 19;
            this.lbl_fixGioiTinh.Text = "Giới tính:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(334, 333);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(181, 1);
            this.panel8.TabIndex = 36;
            // 
            // txt_fixSoDT
            // 
            this.txt_fixSoDT.BackColor = System.Drawing.Color.White;
            this.txt_fixSoDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixSoDT.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixSoDT.Location = new System.Drawing.Point(45, 300);
            this.txt_fixSoDT.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixSoDT.Multiline = true;
            this.txt_fixSoDT.Name = "txt_fixSoDT";
            this.txt_fixSoDT.Size = new System.Drawing.Size(177, 30);
            this.txt_fixSoDT.TabIndex = 35;
            this.txt_fixSoDT.UseSystemPasswordChar = true;
            this.txt_fixSoDT.TextChanged += new System.EventHandler(this.txt_fixSoDT_TextChanged);
            this.txt_fixSoDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_fixSoDT_KeyPress);
            this.txt_fixSoDT.Validating += new System.ComponentModel.CancelEventHandler(this.txt_fixSoDT_Validating);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(45, 333);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(177, 1);
            this.panel7.TabIndex = 34;
            // 
            // dTP_fixNgaySinh
            // 
            this.dTP_fixNgaySinh.CustomFormat = "yyyy-MM-dd";
            this.dTP_fixNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTP_fixNgaySinh.Location = new System.Drawing.Point(246, 194);
            this.dTP_fixNgaySinh.Name = "dTP_fixNgaySinh";
            this.dTP_fixNgaySinh.Size = new System.Drawing.Size(165, 22);
            this.dTP_fixNgaySinh.TabIndex = 33;
            this.dTP_fixNgaySinh.ValueChanged += new System.EventHandler(this.dTP_fixNgaySinh_ValueChanged);
            // 
            // txt_fixHoTen
            // 
            this.txt_fixHoTen.BackColor = System.Drawing.Color.White;
            this.txt_fixHoTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixHoTen.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixHoTen.Location = new System.Drawing.Point(337, 77);
            this.txt_fixHoTen.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixHoTen.Multiline = true;
            this.txt_fixHoTen.Name = "txt_fixHoTen";
            this.txt_fixHoTen.Size = new System.Drawing.Size(287, 30);
            this.txt_fixHoTen.TabIndex = 29;
            this.txt_fixHoTen.UseSystemPasswordChar = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(337, 110);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(287, 1);
            this.panel5.TabIndex = 28;
            // 
            // txt_fixMNV
            // 
            this.txt_fixMNV.BackColor = System.Drawing.Color.White;
            this.txt_fixMNV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_fixMNV.Enabled = false;
            this.txt_fixMNV.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fixMNV.Location = new System.Drawing.Point(45, 77);
            this.txt_fixMNV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fixMNV.Multiline = true;
            this.txt_fixMNV.Name = "txt_fixMNV";
            this.txt_fixMNV.Size = new System.Drawing.Size(163, 30);
            this.txt_fixMNV.TabIndex = 27;
            this.txt_fixMNV.UseSystemPasswordChar = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(45, 110);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(163, 1);
            this.panel4.TabIndex = 26;
            // 
            // lbl_fixMNV
            // 
            this.lbl_fixMNV.AutoSize = true;
            this.lbl_fixMNV.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fixMNV.Location = new System.Drawing.Point(41, 37);
            this.lbl_fixMNV.Name = "lbl_fixMNV";
            this.lbl_fixMNV.Size = new System.Drawing.Size(143, 24);
            this.lbl_fixMNV.TabIndex = 3;
            this.lbl_fixMNV.Text = "Mã nhân viên:";
            // 
            // Edit_NhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(653, 595);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Edit_NhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit_NhanVien";
            this.Load += new System.EventHandler(this.Edit_NhanVien_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_suaNhanVien;
        private CustomControls.RJControls.RJButton btn_huySuaNhanVien;
        private CustomControls.RJControls.RJButton btn_luuSuaNhanVien;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_fixMNV;
        private System.Windows.Forms.Label lbl_fixHoTen;
        private System.Windows.Forms.Label lbl_fixGioiTinh;
        private System.Windows.Forms.Label lbl_fixNgaySinh;
        private System.Windows.Forms.Label lbl_fixSoDT;
        private System.Windows.Forms.Label lbl_fixLuong;
        private System.Windows.Forms.Label lbl_fixCaLam;
        private System.Windows.Forms.Label lbl_fixTaiKhoan;
        private System.Windows.Forms.Label lbl_fixMatKhau;
        private System.Windows.Forms.TextBox txt_fixMNV;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txt_fixHoTen;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DateTimePicker dTP_fixNgaySinh;
        private System.Windows.Forms.TextBox txt_fixMatKhau;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txt_fixTaiKhoan;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txt_fixLuong;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_fixSoDT;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btn_close_fixNhanVien;
        private System.Windows.Forms.DateTimePicker dTP_fixCaLam;
        private System.Windows.Forms.ComboBox cB_fixgioiTinh;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel12;
    }
}