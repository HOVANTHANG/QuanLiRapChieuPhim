﻿namespace QL_RapChieuPhim.Views
{
    partial class HoaDonSP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HoaDonSP));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.txt_maNV = new System.Windows.Forms.TextBox();
            this.txt_ngayBan = new System.Windows.Forms.TextBox();
            this.txt_MaHD = new System.Windows.Forms.TextBox();
            this.txt_TongTienThanhToan = new System.Windows.Forms.TextBox();
            this.ve = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.bunifuShadowPanel3 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.btn_thanhToan = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_SL = new System.Windows.Forms.TextBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.bunifuShadowPanel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(308, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 418);
            this.panel4.TabIndex = 41;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(14, 45);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(288, 1);
            this.panel7.TabIndex = 42;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.ForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(14, 337);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(288, 1);
            this.panel9.TabIndex = 46;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.ForeColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(314, 337);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(288, 1);
            this.panel11.TabIndex = 47;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(314, 13);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(288, 319);
            this.flowLayoutPanel1.TabIndex = 48;
            // 
            // txt_maNV
            // 
            this.txt_maNV.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_maNV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_maNV.Enabled = false;
            this.txt_maNV.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maNV.Location = new System.Drawing.Point(128, 119);
            this.txt_maNV.Multiline = true;
            this.txt_maNV.Name = "txt_maNV";
            this.txt_maNV.Size = new System.Drawing.Size(174, 24);
            this.txt_maNV.TabIndex = 49;
            this.txt_maNV.UseSystemPasswordChar = true;
            // 
            // txt_ngayBan
            // 
            this.txt_ngayBan.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_ngayBan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ngayBan.Enabled = false;
            this.txt_ngayBan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ngayBan.Location = new System.Drawing.Point(128, 173);
            this.txt_ngayBan.Multiline = true;
            this.txt_ngayBan.Name = "txt_ngayBan";
            this.txt_ngayBan.Size = new System.Drawing.Size(174, 24);
            this.txt_ngayBan.TabIndex = 49;
            this.txt_ngayBan.UseSystemPasswordChar = true;
            // 
            // txt_MaHD
            // 
            this.txt_MaHD.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_MaHD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaHD.Enabled = false;
            this.txt_MaHD.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaHD.Location = new System.Drawing.Point(128, 63);
            this.txt_MaHD.Multiline = true;
            this.txt_MaHD.Name = "txt_MaHD";
            this.txt_MaHD.Size = new System.Drawing.Size(78, 24);
            this.txt_MaHD.TabIndex = 45;
            this.txt_MaHD.UseSystemPasswordChar = true;
            this.txt_MaHD.TextChanged += new System.EventHandler(this.txt_MaHD_TextChanged);
            // 
            // txt_TongTienThanhToan
            // 
            this.txt_TongTienThanhToan.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_TongTienThanhToan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_TongTienThanhToan.Enabled = false;
            this.txt_TongTienThanhToan.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TongTienThanhToan.Location = new System.Drawing.Point(398, 344);
            this.txt_TongTienThanhToan.Multiline = true;
            this.txt_TongTienThanhToan.Name = "txt_TongTienThanhToan";
            this.txt_TongTienThanhToan.Size = new System.Drawing.Size(174, 24);
            this.txt_TongTienThanhToan.TabIndex = 49;
            this.txt_TongTienThanhToan.UseSystemPasswordChar = true;
            // 
            // ve
            // 
            this.ve.AutoSize = true;
            this.ve.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ve.Location = new System.Drawing.Point(75, 13);
            this.ve.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ve.Name = "ve";
            this.ve.Size = new System.Drawing.Size(202, 26);
            this.ve.TabIndex = 51;
            this.ve.Text = "Thông tin hóa đơn";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 74);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "MÃ HÓA ĐƠN: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 130);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 53;
            this.label7.Text = "MÃ NHÂN VIÊN:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 184);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 54;
            this.label8.Text = "NGÀY BÁN:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(314, 355);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 54;
            this.label14.Text = "TỔNG TIỀN";
            // 
            // bunifuShadowPanel3
            // 
            this.bunifuShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel3.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel3.BorderRadius = 8;
            this.bunifuShadowPanel3.BorderThickness = 1;
            this.bunifuShadowPanel3.Controls.Add(this.btn_thanhToan);
            this.bunifuShadowPanel3.Controls.Add(this.label2);
            this.bunifuShadowPanel3.Controls.Add(this.txt_SL);
            this.bunifuShadowPanel3.Controls.Add(this.label14);
            this.bunifuShadowPanel3.Controls.Add(this.label8);
            this.bunifuShadowPanel3.Controls.Add(this.label7);
            this.bunifuShadowPanel3.Controls.Add(this.label6);
            this.bunifuShadowPanel3.Controls.Add(this.ve);
            this.bunifuShadowPanel3.Controls.Add(this.txt_TongTienThanhToan);
            this.bunifuShadowPanel3.Controls.Add(this.txt_MaHD);
            this.bunifuShadowPanel3.Controls.Add(this.txt_ngayBan);
            this.bunifuShadowPanel3.Controls.Add(this.txt_maNV);
            this.bunifuShadowPanel3.Controls.Add(this.flowLayoutPanel1);
            this.bunifuShadowPanel3.Controls.Add(this.panel11);
            this.bunifuShadowPanel3.Controls.Add(this.panel9);
            this.bunifuShadowPanel3.Controls.Add(this.panel7);
            this.bunifuShadowPanel3.Controls.Add(this.panel4);
            this.bunifuShadowPanel3.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel3.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel3.Location = new System.Drawing.Point(11, 35);
            this.bunifuShadowPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuShadowPanel3.Name = "bunifuShadowPanel3";
            this.bunifuShadowPanel3.PanelColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel3.PanelColor2 = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel3.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel3.ShadowDept = 2;
            this.bunifuShadowPanel3.ShadowDepth = 5;
            this.bunifuShadowPanel3.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel3.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel3.Size = new System.Drawing.Size(613, 399);
            this.bunifuShadowPanel3.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel3.TabIndex = 3;
            // 
            // btn_thanhToan
            // 
            this.btn_thanhToan.AllowAnimations = true;
            this.btn_thanhToan.AllowMouseEffects = true;
            this.btn_thanhToan.AllowToggling = false;
            this.btn_thanhToan.AnimationSpeed = 200;
            this.btn_thanhToan.AutoGenerateColors = false;
            this.btn_thanhToan.AutoRoundBorders = false;
            this.btn_thanhToan.AutoSizeLeftIcon = true;
            this.btn_thanhToan.AutoSizeRightIcon = true;
            this.btn_thanhToan.BackColor = System.Drawing.Color.Transparent;
            this.btn_thanhToan.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_thanhToan.BackgroundImage")));
            this.btn_thanhToan.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.ButtonText = "Thanh Toán";
            this.btn_thanhToan.ButtonTextMarginLeft = 0;
            this.btn_thanhToan.ColorContrastOnClick = 45;
            this.btn_thanhToan.ColorContrastOnHover = 45;
            this.btn_thanhToan.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btn_thanhToan.CustomizableEdges = borderEdges1;
            this.btn_thanhToan.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_thanhToan.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btn_thanhToan.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_thanhToan.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn_thanhToan.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btn_thanhToan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_thanhToan.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_thanhToan.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_thanhToan.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btn_thanhToan.IconMarginLeft = 11;
            this.btn_thanhToan.IconPadding = 10;
            this.btn_thanhToan.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_thanhToan.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_thanhToan.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btn_thanhToan.IconSize = 25;
            this.btn_thanhToan.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.IdleBorderRadius = 20;
            this.btn_thanhToan.IdleBorderThickness = 1;
            this.btn_thanhToan.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.IdleIconLeftImage = null;
            this.btn_thanhToan.IdleIconRightImage = null;
            this.btn_thanhToan.IndicateFocus = false;
            this.btn_thanhToan.Location = new System.Drawing.Point(91, 344);
            this.btn_thanhToan.Margin = new System.Windows.Forms.Padding(2);
            this.btn_thanhToan.Name = "btn_thanhToan";
            this.btn_thanhToan.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btn_thanhToan.OnDisabledState.BorderRadius = 20;
            this.btn_thanhToan.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.OnDisabledState.BorderThickness = 1;
            this.btn_thanhToan.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_thanhToan.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn_thanhToan.OnDisabledState.IconLeftImage = null;
            this.btn_thanhToan.OnDisabledState.IconRightImage = null;
            this.btn_thanhToan.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn_thanhToan.onHoverState.BorderRadius = 20;
            this.btn_thanhToan.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.onHoverState.BorderThickness = 1;
            this.btn_thanhToan.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn_thanhToan.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.onHoverState.IconLeftImage = null;
            this.btn_thanhToan.onHoverState.IconRightImage = null;
            this.btn_thanhToan.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.OnIdleState.BorderRadius = 20;
            this.btn_thanhToan.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.OnIdleState.BorderThickness = 1;
            this.btn_thanhToan.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.OnIdleState.IconLeftImage = null;
            this.btn_thanhToan.OnIdleState.IconRightImage = null;
            this.btn_thanhToan.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btn_thanhToan.OnPressedState.BorderRadius = 20;
            this.btn_thanhToan.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.OnPressedState.BorderThickness = 1;
            this.btn_thanhToan.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btn_thanhToan.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.OnPressedState.IconLeftImage = null;
            this.btn_thanhToan.OnPressedState.IconRightImage = null;
            this.btn_thanhToan.Size = new System.Drawing.Size(92, 36);
            this.btn_thanhToan.TabIndex = 57;
            this.btn_thanhToan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_thanhToan.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_thanhToan.TextMarginLeft = 0;
            this.btn_thanhToan.TextPadding = new System.Windows.Forms.Padding(0);
            this.btn_thanhToan.UseDefaultRadiusAndThickness = true;
            this.btn_thanhToan.Click += new System.EventHandler(this.btn_thanhToan_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 249);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 56;
            this.label2.Text = "SỐ LƯỢNG";
            // 
            // txt_SL
            // 
            this.txt_SL.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_SL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_SL.Enabled = false;
            this.txt_SL.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SL.Location = new System.Drawing.Point(132, 238);
            this.txt_SL.Multiline = true;
            this.txt_SL.Name = "txt_SL";
            this.txt_SL.Size = new System.Drawing.Size(174, 24);
            this.txt_SL.TabIndex = 55;
            this.txt_SL.UseSystemPasswordChar = true;
            // 
            // btn_close
            // 
            this.btn_close.FlatAppearance.BorderSize = 0;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_close.Location = new System.Drawing.Point(592, 3);
            this.btn_close.Margin = new System.Windows.Forms.Padding(2);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(41, 28);
            this.btn_close.TabIndex = 4;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.btn_close);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(635, 33);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(881, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(41, 28);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // HoaDonSP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 445);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bunifuShadowPanel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "HoaDonSP";
            this.Text = "HoaDonSP";
            this.Load += new System.EventHandler(this.HoaDonSP_Load);
            this.bunifuShadowPanel3.ResumeLayout(false);
            this.bunifuShadowPanel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TextBox txt_maNV;
        private System.Windows.Forms.TextBox txt_ngayBan;
        private System.Windows.Forms.TextBox txt_MaHD;
        private System.Windows.Forms.TextBox txt_TongTienThanhToan;
        private System.Windows.Forms.Label ve;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_SL;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_thanhToan;
    }
}