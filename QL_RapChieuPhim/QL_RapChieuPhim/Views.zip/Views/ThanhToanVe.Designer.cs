﻿namespace QL_RapChieuPhim.Views
{
    partial class ThanhToanVe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThanhToanVe));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close = new System.Windows.Forms.Button();
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuShadowPanel2 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.rdo_Nu = new System.Windows.Forms.RadioButton();
            this.rdo_Nam = new System.Windows.Forms.RadioButton();
            this.dtp_NgaySinh = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_thanhToan = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txt_maKhach = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_sdtKhach = new System.Windows.Forms.TextBox();
            this.txt_addHoTenKH = new System.Windows.Forms.TextBox();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bunifuShadowPanel3 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ve = new System.Windows.Forms.Label();
            this.txt_TongTienThanhToan = new System.Windows.Forms.TextBox();
            this.txt_tongtienDoAn = new System.Windows.Forms.TextBox();
            this.txt_tongTienVe = new System.Windows.Forms.TextBox();
            this.txt_giave = new System.Windows.Forms.TextBox();
            this.txt_Ghe = new System.Windows.Forms.TextBox();
            this.txt_phongchieu = new System.Windows.Forms.TextBox();
            this.txt_MaVe = new System.Windows.Forms.TextBox();
            this.txt_giochieu = new System.Windows.Forms.TextBox();
            this.txt_ngaychieu = new System.Windows.Forms.TextBox();
            this.txt_tenphim = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_back = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.bunifuShadowPanel1.SuspendLayout();
            this.bunifuShadowPanel2.SuspendLayout();
            this.bunifuShadowPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.btn_close);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(922, 33);
            this.panel1.TabIndex = 1;
            // 
            // btn_close
            // 
            this.btn_close.FlatAppearance.BorderSize = 0;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_close.Location = new System.Drawing.Point(881, 2);
            this.btn_close.Margin = new System.Windows.Forms.Padding(2);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(41, 28);
            this.btn_close.TabIndex = 0;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel1.BorderRadius = 8;
            this.bunifuShadowPanel1.BorderThickness = 1;
            this.bunifuShadowPanel1.Controls.Add(this.label2);
            this.bunifuShadowPanel1.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel1.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(17, 86);
            this.bunifuShadowPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel1.PanelColor2 = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel1.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowDepth = 5;
            this.bunifuShadowPanel1.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(267, 59);
            this.bunifuShadowPanel1.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(41, 13);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 26);
            this.label2.TabIndex = 51;
            this.label2.Text = "Thanh toán vé";
            // 
            // bunifuShadowPanel2
            // 
            this.bunifuShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel2.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel2.BorderRadius = 8;
            this.bunifuShadowPanel2.BorderThickness = 1;
            this.bunifuShadowPanel2.Controls.Add(this.rdo_Nu);
            this.bunifuShadowPanel2.Controls.Add(this.rdo_Nam);
            this.bunifuShadowPanel2.Controls.Add(this.dtp_NgaySinh);
            this.bunifuShadowPanel2.Controls.Add(this.label17);
            this.bunifuShadowPanel2.Controls.Add(this.panel14);
            this.bunifuShadowPanel2.Controls.Add(this.label16);
            this.bunifuShadowPanel2.Controls.Add(this.label4);
            this.bunifuShadowPanel2.Controls.Add(this.label5);
            this.bunifuShadowPanel2.Controls.Add(this.label3);
            this.bunifuShadowPanel2.Controls.Add(this.panel6);
            this.bunifuShadowPanel2.Controls.Add(this.btn_thanhToan);
            this.bunifuShadowPanel2.Controls.Add(this.txt_maKhach);
            this.bunifuShadowPanel2.Controls.Add(this.panel2);
            this.bunifuShadowPanel2.Controls.Add(this.txt_sdtKhach);
            this.bunifuShadowPanel2.Controls.Add(this.txt_addHoTenKH);
            this.bunifuShadowPanel2.Controls.Add(this.bunifuLabel3);
            this.bunifuShadowPanel2.Controls.Add(this.panel5);
            this.bunifuShadowPanel2.Controls.Add(this.panel3);
            this.bunifuShadowPanel2.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel2.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel2.Location = new System.Drawing.Point(17, 160);
            this.bunifuShadowPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuShadowPanel2.Name = "bunifuShadowPanel2";
            this.bunifuShadowPanel2.PanelColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel2.PanelColor2 = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel2.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel2.ShadowDept = 2;
            this.bunifuShadowPanel2.ShadowDepth = 5;
            this.bunifuShadowPanel2.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel2.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel2.Size = new System.Drawing.Size(267, 350);
            this.bunifuShadowPanel2.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel2.TabIndex = 2;
            // 
            // rdo_Nu
            // 
            this.rdo_Nu.AutoSize = true;
            this.rdo_Nu.Location = new System.Drawing.Point(187, 200);
            this.rdo_Nu.Margin = new System.Windows.Forms.Padding(2);
            this.rdo_Nu.Name = "rdo_Nu";
            this.rdo_Nu.Size = new System.Drawing.Size(39, 17);
            this.rdo_Nu.TabIndex = 60;
            this.rdo_Nu.TabStop = true;
            this.rdo_Nu.Text = "Nữ";
            this.rdo_Nu.UseVisualStyleBackColor = true;
            // 
            // rdo_Nam
            // 
            this.rdo_Nam.AutoSize = true;
            this.rdo_Nam.Location = new System.Drawing.Point(100, 200);
            this.rdo_Nam.Margin = new System.Windows.Forms.Padding(2);
            this.rdo_Nam.Name = "rdo_Nam";
            this.rdo_Nam.Size = new System.Drawing.Size(47, 17);
            this.rdo_Nam.TabIndex = 60;
            this.rdo_Nam.TabStop = true;
            this.rdo_Nam.Text = "Nam";
            this.rdo_Nam.UseVisualStyleBackColor = true;
            // 
            // dtp_NgaySinh
            // 
            this.dtp_NgaySinh.CustomFormat = "dd/MM/yyyy";
            this.dtp_NgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_NgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_NgaySinh.Location = new System.Drawing.Point(102, 236);
            this.dtp_NgaySinh.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_NgaySinh.Name = "dtp_NgaySinh";
            this.dtp_NgaySinh.Size = new System.Drawing.Size(151, 23);
            this.dtp_NgaySinh.TabIndex = 59;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 251);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 13);
            this.label17.TabIndex = 58;
            this.label17.Text = "NGÀY SINH";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Black;
            this.panel14.ForeColor = System.Drawing.Color.Black;
            this.panel14.Location = new System.Drawing.Point(102, 263);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(153, 1);
            this.panel14.TabIndex = 57;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 203);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 55;
            this.label16.Text = "GIỚI TÍNH";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "TÊN KHÁCH:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 161);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 52;
            this.label5.Text = "SỐ ĐIỆN THOẠI";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 58);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 52;
            this.label3.Text = "MÃ KHÁCH:";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(102, 171);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(153, 1);
            this.panel6.TabIndex = 46;
            // 
            // btn_thanhToan
            // 
            this.btn_thanhToan.AllowAnimations = true;
            this.btn_thanhToan.AllowMouseEffects = true;
            this.btn_thanhToan.AllowToggling = false;
            this.btn_thanhToan.AnimationSpeed = 200;
            this.btn_thanhToan.AutoGenerateColors = false;
            this.btn_thanhToan.AutoRoundBorders = false;
            this.btn_thanhToan.AutoSizeLeftIcon = true;
            this.btn_thanhToan.AutoSizeRightIcon = true;
            this.btn_thanhToan.BackColor = System.Drawing.Color.Transparent;
            this.btn_thanhToan.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_thanhToan.BackgroundImage")));
            this.btn_thanhToan.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.ButtonText = "Thanh Toán";
            this.btn_thanhToan.ButtonTextMarginLeft = 0;
            this.btn_thanhToan.ColorContrastOnClick = 45;
            this.btn_thanhToan.ColorContrastOnHover = 45;
            this.btn_thanhToan.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btn_thanhToan.CustomizableEdges = borderEdges1;
            this.btn_thanhToan.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_thanhToan.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btn_thanhToan.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_thanhToan.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn_thanhToan.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btn_thanhToan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_thanhToan.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_thanhToan.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_thanhToan.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btn_thanhToan.IconMarginLeft = 11;
            this.btn_thanhToan.IconPadding = 10;
            this.btn_thanhToan.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_thanhToan.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_thanhToan.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btn_thanhToan.IconSize = 25;
            this.btn_thanhToan.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.IdleBorderRadius = 20;
            this.btn_thanhToan.IdleBorderThickness = 1;
            this.btn_thanhToan.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.IdleIconLeftImage = null;
            this.btn_thanhToan.IdleIconRightImage = null;
            this.btn_thanhToan.IndicateFocus = false;
            this.btn_thanhToan.Location = new System.Drawing.Point(164, 300);
            this.btn_thanhToan.Margin = new System.Windows.Forms.Padding(2);
            this.btn_thanhToan.Name = "btn_thanhToan";
            this.btn_thanhToan.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btn_thanhToan.OnDisabledState.BorderRadius = 20;
            this.btn_thanhToan.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.OnDisabledState.BorderThickness = 1;
            this.btn_thanhToan.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn_thanhToan.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn_thanhToan.OnDisabledState.IconLeftImage = null;
            this.btn_thanhToan.OnDisabledState.IconRightImage = null;
            this.btn_thanhToan.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn_thanhToan.onHoverState.BorderRadius = 20;
            this.btn_thanhToan.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.onHoverState.BorderThickness = 1;
            this.btn_thanhToan.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn_thanhToan.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.onHoverState.IconLeftImage = null;
            this.btn_thanhToan.onHoverState.IconRightImage = null;
            this.btn_thanhToan.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.OnIdleState.BorderRadius = 20;
            this.btn_thanhToan.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.OnIdleState.BorderThickness = 1;
            this.btn_thanhToan.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btn_thanhToan.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.OnIdleState.IconLeftImage = null;
            this.btn_thanhToan.OnIdleState.IconRightImage = null;
            this.btn_thanhToan.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btn_thanhToan.OnPressedState.BorderRadius = 20;
            this.btn_thanhToan.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn_thanhToan.OnPressedState.BorderThickness = 1;
            this.btn_thanhToan.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btn_thanhToan.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btn_thanhToan.OnPressedState.IconLeftImage = null;
            this.btn_thanhToan.OnPressedState.IconRightImage = null;
            this.btn_thanhToan.Size = new System.Drawing.Size(92, 36);
            this.btn_thanhToan.TabIndex = 1;
            this.btn_thanhToan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_thanhToan.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_thanhToan.TextMarginLeft = 0;
            this.btn_thanhToan.TextPadding = new System.Windows.Forms.Padding(0);
            this.btn_thanhToan.UseDefaultRadiusAndThickness = true;
            this.btn_thanhToan.Click += new System.EventHandler(this.btn_thanhToan_Click);
            // 
            // txt_maKhach
            // 
            this.txt_maKhach.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_maKhach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_maKhach.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maKhach.Location = new System.Drawing.Point(82, 47);
            this.txt_maKhach.Multiline = true;
            this.txt_maKhach.Name = "txt_maKhach";
            this.txt_maKhach.Size = new System.Drawing.Size(78, 24);
            this.txt_maKhach.TabIndex = 45;
            this.txt_maKhach.UseSystemPasswordChar = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(82, 74);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(78, 1);
            this.panel2.TabIndex = 44;
            // 
            // txt_sdtKhach
            // 
            this.txt_sdtKhach.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_sdtKhach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_sdtKhach.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sdtKhach.Location = new System.Drawing.Point(102, 148);
            this.txt_sdtKhach.Multiline = true;
            this.txt_sdtKhach.Name = "txt_sdtKhach";
            this.txt_sdtKhach.Size = new System.Drawing.Size(153, 24);
            this.txt_sdtKhach.TabIndex = 42;
            this.txt_sdtKhach.UseSystemPasswordChar = true;
            // 
            // txt_addHoTenKH
            // 
            this.txt_addHoTenKH.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_addHoTenKH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_addHoTenKH.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addHoTenKH.Location = new System.Drawing.Point(102, 98);
            this.txt_addHoTenKH.Multiline = true;
            this.txt_addHoTenKH.Name = "txt_addHoTenKH";
            this.txt_addHoTenKH.Size = new System.Drawing.Size(153, 24);
            this.txt_addHoTenKH.TabIndex = 42;
            this.txt_addHoTenKH.UseSystemPasswordChar = true;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.Location = new System.Drawing.Point(46, 9);
            this.bunifuLabel3.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(143, 19);
            this.bunifuLabel3.TabIndex = 0;
            this.bunifuLabel3.Text = "Thông tin khách hàng";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(102, 124);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(153, 1);
            this.panel5.TabIndex = 41;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.Location = new System.Drawing.Point(2, 32);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(260, 1);
            this.panel3.TabIndex = 5;
            // 
            // bunifuShadowPanel3
            // 
            this.bunifuShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel3.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel3.BorderRadius = 8;
            this.bunifuShadowPanel3.BorderThickness = 1;
            this.bunifuShadowPanel3.Controls.Add(this.label14);
            this.bunifuShadowPanel3.Controls.Add(this.label13);
            this.bunifuShadowPanel3.Controls.Add(this.label12);
            this.bunifuShadowPanel3.Controls.Add(this.label15);
            this.bunifuShadowPanel3.Controls.Add(this.label11);
            this.bunifuShadowPanel3.Controls.Add(this.label10);
            this.bunifuShadowPanel3.Controls.Add(this.label9);
            this.bunifuShadowPanel3.Controls.Add(this.label8);
            this.bunifuShadowPanel3.Controls.Add(this.label7);
            this.bunifuShadowPanel3.Controls.Add(this.label6);
            this.bunifuShadowPanel3.Controls.Add(this.label1);
            this.bunifuShadowPanel3.Controls.Add(this.ve);
            this.bunifuShadowPanel3.Controls.Add(this.txt_TongTienThanhToan);
            this.bunifuShadowPanel3.Controls.Add(this.txt_tongtienDoAn);
            this.bunifuShadowPanel3.Controls.Add(this.txt_tongTienVe);
            this.bunifuShadowPanel3.Controls.Add(this.txt_giave);
            this.bunifuShadowPanel3.Controls.Add(this.txt_Ghe);
            this.bunifuShadowPanel3.Controls.Add(this.txt_phongchieu);
            this.bunifuShadowPanel3.Controls.Add(this.txt_MaVe);
            this.bunifuShadowPanel3.Controls.Add(this.txt_giochieu);
            this.bunifuShadowPanel3.Controls.Add(this.txt_ngaychieu);
            this.bunifuShadowPanel3.Controls.Add(this.txt_tenphim);
            this.bunifuShadowPanel3.Controls.Add(this.flowLayoutPanel1);
            this.bunifuShadowPanel3.Controls.Add(this.panel12);
            this.bunifuShadowPanel3.Controls.Add(this.panel11);
            this.bunifuShadowPanel3.Controls.Add(this.panel10);
            this.bunifuShadowPanel3.Controls.Add(this.panel9);
            this.bunifuShadowPanel3.Controls.Add(this.panel8);
            this.bunifuShadowPanel3.Controls.Add(this.panel7);
            this.bunifuShadowPanel3.Controls.Add(this.panel4);
            this.bunifuShadowPanel3.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel3.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel3.Location = new System.Drawing.Point(289, 86);
            this.bunifuShadowPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuShadowPanel3.Name = "bunifuShadowPanel3";
            this.bunifuShadowPanel3.PanelColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel3.PanelColor2 = System.Drawing.Color.WhiteSmoke;
            this.bunifuShadowPanel3.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel3.ShadowDept = 2;
            this.bunifuShadowPanel3.ShadowDepth = 5;
            this.bunifuShadowPanel3.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel3.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel3.Size = new System.Drawing.Size(613, 424);
            this.bunifuShadowPanel3.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel3.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(332, 388);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 54;
            this.label14.Text = "TỔNG TIỀN";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(332, 355);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 54;
            this.label13.Text = "TỔNG";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 348);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 54;
            this.label12.Text = "TỔNG";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(24, 299);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 13);
            this.label15.TabIndex = 54;
            this.label15.Text = "GIÁ VÉ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 255);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 54;
            this.label11.Text = "GHẾ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 222);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 13);
            this.label10.TabIndex = 54;
            this.label10.Text = "PHÒNG CHIẾU";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 186);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 54;
            this.label9.Text = "Ca chiếu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 148);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 54;
            this.label8.Text = "NGÀY CHIẾU";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 106);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 53;
            this.label7.Text = "PHIM";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 74);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "MÃ VÉ: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(405, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 26);
            this.label1.TabIndex = 51;
            this.label1.Text = "Đồ Ăn";
            // 
            // ve
            // 
            this.ve.AutoSize = true;
            this.ve.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ve.Location = new System.Drawing.Point(75, 13);
            this.ve.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ve.Name = "ve";
            this.ve.Size = new System.Drawing.Size(142, 26);
            this.ve.TabIndex = 51;
            this.ve.Text = "Thông tin vé";
            // 
            // txt_TongTienThanhToan
            // 
            this.txt_TongTienThanhToan.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_TongTienThanhToan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_TongTienThanhToan.Enabled = false;
            this.txt_TongTienThanhToan.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TongTienThanhToan.Location = new System.Drawing.Point(418, 377);
            this.txt_TongTienThanhToan.Multiline = true;
            this.txt_TongTienThanhToan.Name = "txt_TongTienThanhToan";
            this.txt_TongTienThanhToan.Size = new System.Drawing.Size(174, 24);
            this.txt_TongTienThanhToan.TabIndex = 49;
            this.txt_TongTienThanhToan.UseSystemPasswordChar = true;
            // 
            // txt_tongtienDoAn
            // 
            this.txt_tongtienDoAn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_tongtienDoAn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_tongtienDoAn.Enabled = false;
            this.txt_tongtienDoAn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tongtienDoAn.Location = new System.Drawing.Point(418, 344);
            this.txt_tongtienDoAn.Multiline = true;
            this.txt_tongtienDoAn.Name = "txt_tongtienDoAn";
            this.txt_tongtienDoAn.Size = new System.Drawing.Size(174, 24);
            this.txt_tongtienDoAn.TabIndex = 49;
            this.txt_tongtienDoAn.UseSystemPasswordChar = true;
            // 
            // txt_tongTienVe
            // 
            this.txt_tongTienVe.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_tongTienVe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_tongTienVe.Enabled = false;
            this.txt_tongTienVe.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tongTienVe.Location = new System.Drawing.Point(128, 344);
            this.txt_tongTienVe.Multiline = true;
            this.txt_tongTienVe.Name = "txt_tongTienVe";
            this.txt_tongTienVe.Size = new System.Drawing.Size(174, 24);
            this.txt_tongTienVe.TabIndex = 49;
            this.txt_tongTienVe.UseSystemPasswordChar = true;
            // 
            // txt_giave
            // 
            this.txt_giave.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_giave.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_giave.Enabled = false;
            this.txt_giave.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_giave.Location = new System.Drawing.Point(128, 288);
            this.txt_giave.Multiline = true;
            this.txt_giave.Name = "txt_giave";
            this.txt_giave.Size = new System.Drawing.Size(174, 24);
            this.txt_giave.TabIndex = 49;
            this.txt_giave.UseSystemPasswordChar = true;
            // 
            // txt_Ghe
            // 
            this.txt_Ghe.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Ghe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Ghe.Enabled = false;
            this.txt_Ghe.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Ghe.Location = new System.Drawing.Point(128, 244);
            this.txt_Ghe.Multiline = true;
            this.txt_Ghe.Name = "txt_Ghe";
            this.txt_Ghe.Size = new System.Drawing.Size(174, 24);
            this.txt_Ghe.TabIndex = 49;
            this.txt_Ghe.UseSystemPasswordChar = true;
            // 
            // txt_phongchieu
            // 
            this.txt_phongchieu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_phongchieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_phongchieu.Enabled = false;
            this.txt_phongchieu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phongchieu.Location = new System.Drawing.Point(128, 210);
            this.txt_phongchieu.Multiline = true;
            this.txt_phongchieu.Name = "txt_phongchieu";
            this.txt_phongchieu.Size = new System.Drawing.Size(174, 24);
            this.txt_phongchieu.TabIndex = 49;
            this.txt_phongchieu.UseSystemPasswordChar = true;
            // 
            // txt_MaVe
            // 
            this.txt_MaVe.BackColor = System.Drawing.Color.Gainsboro;
            this.txt_MaVe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_MaVe.Enabled = false;
            this.txt_MaVe.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaVe.Location = new System.Drawing.Point(128, 63);
            this.txt_MaVe.Multiline = true;
            this.txt_MaVe.Name = "txt_MaVe";
            this.txt_MaVe.Size = new System.Drawing.Size(78, 24);
            this.txt_MaVe.TabIndex = 45;
            this.txt_MaVe.UseSystemPasswordChar = true;
            // 
            // txt_giochieu
            // 
            this.txt_giochieu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_giochieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_giochieu.Enabled = false;
            this.txt_giochieu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_giochieu.Location = new System.Drawing.Point(128, 171);
            this.txt_giochieu.Multiline = true;
            this.txt_giochieu.Name = "txt_giochieu";
            this.txt_giochieu.Size = new System.Drawing.Size(174, 24);
            this.txt_giochieu.TabIndex = 49;
            this.txt_giochieu.UseSystemPasswordChar = true;
            // 
            // txt_ngaychieu
            // 
            this.txt_ngaychieu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_ngaychieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ngaychieu.Enabled = false;
            this.txt_ngaychieu.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ngaychieu.Location = new System.Drawing.Point(128, 136);
            this.txt_ngaychieu.Multiline = true;
            this.txt_ngaychieu.Name = "txt_ngaychieu";
            this.txt_ngaychieu.Size = new System.Drawing.Size(174, 24);
            this.txt_ngaychieu.TabIndex = 49;
            this.txt_ngaychieu.UseSystemPasswordChar = true;
            // 
            // txt_tenphim
            // 
            this.txt_tenphim.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_tenphim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_tenphim.Enabled = false;
            this.txt_tenphim.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tenphim.Location = new System.Drawing.Point(128, 95);
            this.txt_tenphim.Multiline = true;
            this.txt_tenphim.Name = "txt_tenphim";
            this.txt_tenphim.Size = new System.Drawing.Size(174, 24);
            this.txt_tenphim.TabIndex = 49;
            this.txt_tenphim.UseSystemPasswordChar = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(314, 63);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(288, 269);
            this.flowLayoutPanel1.TabIndex = 48;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.ForeColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(314, 374);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(288, 1);
            this.panel12.TabIndex = 47;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.ForeColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(314, 337);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(288, 1);
            this.panel11.TabIndex = 47;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.ForeColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(14, 374);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(288, 1);
            this.panel10.TabIndex = 46;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.ForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(14, 337);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(288, 1);
            this.panel9.TabIndex = 46;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(314, 45);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(288, 1);
            this.panel8.TabIndex = 43;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(14, 45);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(288, 1);
            this.panel7.TabIndex = 42;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(308, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 418);
            this.panel4.TabIndex = 41;
            // 
            // btn_back
            // 
            this.btn_back.FlatAppearance.BorderSize = 0;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Image = global::QL_RapChieuPhim.Properties.Resources.arrow_32px;
            this.btn_back.Location = new System.Drawing.Point(9, 38);
            this.btn_back.Margin = new System.Windows.Forms.Padding(2);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(46, 32);
            this.btn_back.TabIndex = 4;
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // ThanhToanVe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 520);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.bunifuShadowPanel3);
            this.Controls.Add(this.bunifuShadowPanel2);
            this.Controls.Add(this.bunifuShadowPanel1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ThanhToanVe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThanhToanVe";
            this.Load += new System.EventHandler(this.ThanhToanVe_Load);
            this.panel1.ResumeLayout(false);
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.bunifuShadowPanel2.ResumeLayout(false);
            this.bunifuShadowPanel2.PerformLayout();
            this.bunifuShadowPanel3.ResumeLayout(false);
            this.bunifuShadowPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_close;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel2;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel3;
        private System.Windows.Forms.Button btn_back;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txt_addHoTenKH;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txt_maKhach;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_sdtKhach;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_thanhToan;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_tenphim;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txt_giave;
        private System.Windows.Forms.TextBox txt_Ghe;
        private System.Windows.Forms.TextBox txt_phongchieu;
        private System.Windows.Forms.TextBox txt_MaVe;
        private System.Windows.Forms.TextBox txt_giochieu;
        private System.Windows.Forms.TextBox txt_ngaychieu;
        private System.Windows.Forms.TextBox txt_TongTienThanhToan;
        private System.Windows.Forms.TextBox txt_tongtienDoAn;
        private System.Windows.Forms.TextBox txt_tongTienVe;
        private System.Windows.Forms.Label ve;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtp_NgaySinh;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton rdo_Nu;
        private System.Windows.Forms.RadioButton rdo_Nam;
    }
}